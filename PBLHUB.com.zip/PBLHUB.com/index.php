<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 如果已登录则跳转
redirectIfLoggedIn();

// 处理AJAX请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ========== 账号密码登录 ==========
    if ($action === 'account_login') {
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']) ? 1 : 0;
        
        if (empty($username) || empty($password)) {
            jsonResponse(false, '请输入用户名和密码');
        }
        
        $sql = "SELECT id, username, email, phone, password_hash, role, real_name, school, subject, bio FROM users 
                WHERE username = '$username' OR email = '$username' OR phone = '$username'";
        $result = $conn->query($sql);
        $user = $result->fetch_assoc();
        
        if ($user && verifyPassword($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'] ?? 'student';
            $_SESSION['real_name'] = $user['real_name'] ?? $user['username'];
            $_SESSION['email'] = $user['email'] ?? '';
            $_SESSION['phone'] = $user['phone'] ?? '';
            $_SESSION['school'] = $user['school'] ?? '';
            $_SESSION['subject'] = $user['subject'] ?? '';
            $_SESSION['bio'] = $user['bio'] ?? '';
            
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                $expires = time() + 30 * 86400;
                setcookie('remember_token', $token, $expires, '/');
                $expires_date = date('Y-m-d H:i:s', $expires);
                $sql = "UPDATE users SET remember_token = '$token', token_expires = '$expires_date' WHERE id = {$user['id']}";
                $conn->query($sql);
            }
            
            $conn->query("UPDATE users SET last_login = NOW() WHERE id = {$user['id']}");
            logLogin($user['id'], 'account', 'success');
            
            // 根据角色跳转
            $role = $user['role'] ?? 'student';
            if ($role === 'admin') {
                jsonResponse(true, '登录成功', ['redirect' => 'admin.php']);
            } elseif ($role === 'expert') {
                jsonResponse(true, '登录成功', ['redirect' => 'expert_profile.php']);
            } else {
                jsonResponse(true, '登录成功', ['redirect' => 'home.php']);
            }
        } else {
            logLogin($user['id'] ?? 0, 'account', 'failed');
            jsonResponse(false, '用户名或密码错误');
        }
    }
    
    // ========== 发送短信验证码 ==========
    if ($action === 'send_sms_code') {
        $phone = sanitize($_POST['phone'] ?? '');
        
        if (empty($phone) || !preg_match('/^1[3-9]\d{9}$/', $phone)) {
            jsonResponse(false, '请输入正确的手机号');
        }
        
        // 检查60秒内是否重复发送
        $sql = "SELECT COUNT(*) as cnt FROM sms_codes 
                WHERE phone = '$phone' AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        
        if ($row['cnt'] > 0) {
            jsonResponse(false, '请等待60秒后再试');
        }
        
        $code = '123456';
        $expires = date('Y-m-d H:i:s', time() + 300);
        
        $sql = "INSERT INTO sms_codes (phone, code, expires_at) VALUES ('$phone', '$code', '$expires')";
        if ($conn->query($sql)) {
            jsonResponse(true, '验证码已发送', ['code' => $code]);
        } else {
            jsonResponse(false, '发送失败，请重试');
        }
    }
    
    // ========== 短信验证码登录 ==========
    if ($action === 'sms_login') {
        $phone = sanitize($_POST['phone'] ?? '');
        $code = sanitize($_POST['code'] ?? '');
        
        if (empty($phone) || empty($code)) {
            jsonResponse(false, '请输入手机号和验证码');
        }
        
        $sql = "SELECT * FROM sms_codes WHERE phone = '$phone' AND code = '$code' 
                AND expires_at > NOW() AND used = 0 ORDER BY id DESC LIMIT 1";
        $result = $conn->query($sql);
        $sms = $result->fetch_assoc();
        
        if (!$sms) {
            jsonResponse(false, '验证码无效或已过期');
        }
        
        $conn->query("UPDATE sms_codes SET used = 1 WHERE id = {$sms['id']}");
        
        $sql = "SELECT id, username, role, real_name FROM users WHERE phone = '$phone'";
        $result = $conn->query($sql);
        $user = $result->fetch_assoc();
        
        if (!$user) {
            $username = '用户_' . substr($phone, -4) . rand(10, 99);
            $sql = "INSERT INTO users (username, phone, role, created_at) VALUES ('$username', '$phone', 'student', NOW())";
            $conn->query($sql);
            $user_id = $conn->insert_id;
            $user = ['id' => $user_id, 'username' => $username, 'role' => 'student', 'real_name' => $username];
        }
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'] ?? 'student';
        $_SESSION['real_name'] = $user['real_name'] ?? $user['username'];
        
        $conn->query("UPDATE users SET last_login = NOW() WHERE id = {$user['id']}");
        logLogin($user['id'], 'sms', 'success');
        
        $role = $user['role'] ?? 'student';
        if ($role === 'admin' || $role === 'expert') {
            jsonResponse(true, '登录成功', ['redirect' => 'admin.php']);
        } else {
            jsonResponse(true, '登录成功', ['redirect' => 'home.php']);
        }
    }
    
    // ========== 微信登录 ==========
    if ($action === 'wechat_login') {
        $wechat_openid = sanitize($_POST['openid'] ?? 'mock_openid_' . rand(1000, 9999));
        
        $sql = "SELECT id, username, role, real_name FROM users WHERE wechat_openid = '$wechat_openid'";
        $result = $conn->query($sql);
        $user = $result->fetch_assoc();
        
        if (!$user) {
            $username = '微信用户_' . rand(1000, 9999);
            $sql = "INSERT INTO users (username, wechat_openid, role, created_at) 
                    VALUES ('$username', '$wechat_openid', 'student', NOW())";
            $conn->query($sql);
            $user_id = $conn->insert_id;
            $user = ['id' => $user_id, 'username' => $username, 'role' => 'student', 'real_name' => $username];
        }
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'] ?? 'student';
        $_SESSION['real_name'] = $user['real_name'] ?? $user['username'];
        
        $conn->query("UPDATE users SET last_login = NOW() WHERE id = {$user['id']}");
        logLogin($user['id'], 'wechat', 'success');
        
        $role = $user['role'] ?? 'student';
        if ($role === 'admin' || $role === 'expert') {
            jsonResponse(true, '登录成功', ['redirect' => 'admin.php']);
        } else {
            jsonResponse(true, '登录成功', ['redirect' => 'home.php']);
        }
    }
    
    // ========== 用户注册 ==========
    if ($action === 'register') {
        $username = sanitize($_POST['username'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm'] ?? '';
        
        $errors = [];
        if (strlen($username) < 2) $errors[] = '用户名至少2个字符';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = '邮箱格式不正确';
        if (strlen($password) < 6) $errors[] = '密码至少6位';
        if ($password !== $confirm) $errors[] = '两次密码不一致';
        
        if (!empty($errors)) {
            jsonResponse(false, implode('；', $errors));
        }
        
        $sql = "SELECT id FROM users WHERE username = '$username' OR email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            jsonResponse(false, '用户名或邮箱已被注册');
        }
        
        $hashed = hashPassword($password);
        $sql = "INSERT INTO users (username, email, password_hash, role, created_at) 
                VALUES ('$username', '$email', '$hashed', 'student', NOW())";
        
        if ($conn->query($sql)) {
            jsonResponse(true, '注册成功，请登录');
        } else {
            jsonResponse(false, '注册失败，请重试');
        }
    }
    
    jsonResponse(false, '无效的请求');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>PBL HUB · 项目式学习平台 | 登录/注册</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #eef5ff 0%, #cfe3ff 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1.5rem;
        }
        .main-container {
            width: 100%;
            max-width: 860px;
            background: rgba(255,255,255,0.92);
            backdrop-filter: blur(2px);
            border-radius: 2rem;
            box-shadow: 0 25px 45px -12px rgba(0,20,50,0.3), 0 10px 20px -8px rgba(0,0,0,0.08);
            overflow: hidden;
            display: flex;
            flex-wrap: wrap;
            transition: all 0.2s ease;
            margin: 0 auto;
        }
        .left-brand {
            flex: 1.2;
            background: linear-gradient(135deg, #0a2b4e 0%, #1a4c7a 100%);
            padding: 2rem 1.8rem;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            z-index: 1;
        }
        .left-brand::before { content: "✨"; font-size: 220px; position: absolute; bottom: -25px; right: -25px; opacity: 0.08; pointer-events: none; z-index: 0; }
        .brand-header h2 { font-size: 2rem; font-weight: 800; letter-spacing: -0.5px; background: linear-gradient(120deg, #fff, #b8dbff); background-clip: text; -webkit-background-clip: text; color: transparent; }
        .brand-header p { font-size: 0.85rem; opacity: 0.85; margin-top: 0.4rem; font-weight: 400; }
        .features { margin: 2rem 0 1.8rem; display: flex; flex-direction: column; gap: 1.5rem; }
        .feature-item { display: flex; gap: 0.9rem; align-items: flex-start; }
        .feature-icon { background: rgba(255,255,255,0.18); width: 44px; height: 44px; border-radius: 28px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; backdrop-filter: blur(4px); }
        .feature-text h4 { font-weight: 600; margin-bottom: 0.2rem; font-size: 1rem; }
        .feature-text p { font-size: 0.75rem; opacity: 0.8; line-height: 1.35; }
        .footer-links { font-size: 0.65rem; display: flex; flex-wrap: wrap; gap: 1.2rem; margin-top: 1.8rem; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 1.2rem; }
        .footer-links a { color: #cbe6fe; text-decoration: none; transition: 0.2s; }
        .footer-links a:hover { color: white; text-decoration: underline; }
        .copyright { font-size: 0.65rem; opacity: 0.7; margin-top: 0.8rem; }

        .right-form { flex: 1; background: white; padding: 1.8rem; display: flex; flex-direction: column; justify-content: center; }
        .form-card { width: 100%; max-width: 100%; margin: 0 auto; }
        .form-header { margin-bottom: 1.4rem; }
        .form-header h3 { font-size: 1.6rem; font-weight: 700; color: #0a2b4e; letter-spacing: -0.3px; }
        .form-header p { color: #4b6589; font-size: 0.8rem; margin-top: 0.2rem; }

        .login-tabs { display: flex; gap: 0.5rem; background: #eef3fc; padding: 0.25rem; border-radius: 3rem; margin-bottom: 1.3rem; }
        .login-tab { flex: 1; text-align: center; padding: 0.5rem 0; font-weight: 600; font-size: 0.8rem; border: none; background: transparent; border-radius: 2rem; cursor: pointer; transition: all 0.2s; color: #2c4b6e; font-family: 'Inter', sans-serif; }
        .login-tab.active { background: white; color: #1e5b9e; box-shadow: 0 2px 8px rgba(0,80,150,0.1); border: 1px solid #ccdeff; }
        .login-panel { display: none; }
        .login-panel.active-panel { display: block; }

        .input-group { margin-bottom: 1rem; }
        .input-group label { display: flex; align-items: center; gap: 0.5rem; font-size: 0.75rem; font-weight: 600; color: #1e3a5f; margin-bottom: 0.3rem; }
        .input-field { display: flex; align-items: center; background: #f9fafc; border: 1.5px solid #e2e8f0; border-radius: 1rem; padding: 0.6rem 0.9rem; transition: 0.2s; }
        .input-field:focus-within { border-color: #2c7be5; box-shadow: 0 0 0 3px rgba(44,123,229,0.12); background: white; }
        .input-field i { color: #7c9bc0; margin-right: 0.6rem; font-size: 0.9rem; }
        .input-field input { width: 100%; border: none; background: transparent; font-size: 0.85rem; outline: none; font-family: 'Inter', sans-serif; }

        .verification-row { display: flex; gap: 0.7rem; }
        .verification-row .input-field { flex: 1; }
        .get-code-btn { background: #eef2ff; border: none; padding: 0 1rem; border-radius: 2rem; font-weight: 600; font-size: 0.75rem; color: #1e5b9e; cursor: pointer; transition: 0.2s; white-space: nowrap; }
        .get-code-btn:hover { background: #dfe8fd; }
        .get-code-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .row-extra { display: flex; justify-content: space-between; align-items: center; margin: 0.6rem 0 1rem; font-size: 0.75rem; }
        .checkbox { display: flex; align-items: center; gap: 0.35rem; color: #2c4b6e; }
        .forgot-link { color: #1e5b9e; text-decoration: none; font-weight: 500; }

        .submit-btn {
            background: linear-gradient(95deg, #1e5b9e, #2c7be5);
            width: 100%; border: none; border-radius: 2rem; padding: 0.7rem;
            font-weight: 700; color: white; font-size: 0.9rem;
            cursor: pointer; transition: all 0.2s; margin-top: 0.3rem;
            box-shadow: 0 5px 12px rgba(30,91,158,0.2);
        }
        .submit-btn:hover { transform: translateY(-2px); background: linear-gradient(95deg, #164c84, #256fd9); box-shadow: 0 8px 18px rgba(30,91,158,0.25); }
        .submit-btn:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }

        .wechat-scan-area { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 0.8rem 0 1rem; }
        .qrcode-mock { background: #f0f7ff; width: 140px; height: 140px; border-radius: 24px; display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: 0 8px 18px rgba(0,0,0,0.05); border: 1px solid #cfe3ff; margin-bottom: 0.8rem; transition: 0.2s; }
        .qrcode-mock i { font-size: 3.5rem; color: #2c7be5; margin-bottom: 0.4rem; }
        .qrcode-mock span { font-size: 0.75rem; font-weight: 500; color: #1e5b9e; background: white; padding: 0.2rem 0.7rem; border-radius: 40px; }
        .wechat-tip { font-size: 0.7rem; color: #5b7a9a; text-align: center; margin-top: 0.3rem; }

        .other-logins { text-align: center; margin: 1.2rem 0 0.8rem; }
        .other-logins p { font-size: 0.7rem; color: #6c86a3; position: relative; }
        .social-icons { display: flex; justify-content: center; gap: 1.2rem; margin-top: 0.8rem; }
        .social-icon { background: #f8fafc; width: 36px; height: 36px; border-radius: 40px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; color: #2c3e50; transition: 0.2s; cursor: pointer; border: 1px solid #e2e8f0; }
        .social-icon:hover { background: #eef3ff; transform: scale(1.05); color: #1e5b9e; border-color: #bdd4ff; }

        .toggle-form-link { text-align: center; margin-top: 0.8rem; font-size: 0.8rem; }
        .toggle-form-link a { color: #1e5b9e; font-weight: 600; text-decoration: none; cursor: pointer; }
        .error-msg { font-size: 0.65rem; color: #d9534f; margin-top: 0.2rem; margin-left: 0.5rem; }
        .form-message { background: #f0f6ff; border-radius: 2rem; padding: 0.5rem; text-align: center; font-size: 0.75rem; margin-top: 0.9rem; }
        .form-message.success { background: #d9efff; color: #0f5c8c; }
        .form-message.error { background: #ffe0de; color: #b33c34; }

        .register-container { display: none; }
        .register-container.active { display: block; }
        .login-container { display: block; }
        .login-container.hide { display: none; }

        .spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff; border-radius: 50%; animation: spin 0.6s linear infinite; vertical-align: middle; margin-right: 6px; }
        @keyframes spin { to { transform: rotate(360deg); } }

        @media (max-width: 800px) {
            .main-container { max-width: 95%; border-radius: 1.8rem; }
            .left-brand { padding: 1.5rem; }
            .right-form { padding: 1.5rem; }
            .feature-item { gap: 0.7rem; }
            .feature-icon { width: 38px; height: 38px; font-size: 1.1rem; }
            .form-header h3 { font-size: 1.4rem; }
        }
        @media (max-width: 580px) {
            .left-brand .features { gap: 1.2rem; }
            .feature-text p { font-size: 0.7rem; }
            .submit-btn { padding: 0.6rem; }
            .qrcode-mock { width: 120px; height: 120px; }
        }
    </style>
</head>
<body>

<div class="main-container">
    <div class="left-brand">
        <div class="brand-header">
            <h2>PBL HUB</h2>
            <p>项目式学习 · 协作创未来</p>
        </div>
        <div class="features">
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-bullseye"></i></div>
                <div class="feature-text">
                    <h4>聚焦真实问题</h4>
                    <p>以真实世界问题为驱动，提升解决问题能力</p>
                </div>
            </div>
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-users"></i></div>
                <div class="feature-text">
                    <h4>协作共创成长</h4>
                    <p>团队协作，沟通分享，共同成长</p>
                </div>
            </div>
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-chart-line"></i></div>
                <div class="feature-text">
                    <h4>展示与反思</h4>
                    <p>记录过程，展示成果，持续反思与改进</p>
                </div>
            </div>
        </div>
        <div>
            <div class="footer-links">
                <a href="#">关于我们</a>
                <a href="#">帮助中心</a>
                <a href="#">隐私政策</a>
                <a href="#">服务条款</a>
            </div>
            <div class="copyright">© 2025 PBL HUB 项目式学习平台</div>
        </div>
    </div>

    <div class="right-form">
        <div class="form-card">
            <div id="loginContainer" class="login-container">
                <div class="form-header">
                    <h3>欢迎回来</h3>
                    <p>登录 PBL HUB，开启你的项目式学习之旅</p>
                </div>

                <div class="login-tabs" id="loginTabs">
                    <button class="login-tab active" data-login-type="account">账号登录</button>
                    <button class="login-tab" data-login-type="sms">手机验证码</button>
                    <button class="login-tab" data-login-type="wechat">微信扫码</button>
                </div>

                <div id="accountPanel" class="login-panel active-panel">
                    <div class="input-group">
                        <label><i class="fas fa-envelope"></i> 邮箱 / 用户名</label>
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="text" id="accUsername" placeholder="邮箱/手机号/用户名" autocomplete="username">
                        </div>
                        <div class="error-msg" id="accUserError"></div>
                    </div>
                    <div class="input-group">
                        <label><i class="fas fa-lock"></i> 密码</label>
                        <div class="input-field">
                            <i class="fas fa-key"></i>
                            <input type="password" id="accPassword" placeholder="请输入密码" autocomplete="current-password">
                        </div>
                        <div class="error-msg" id="accPwdError"></div>
                    </div>
                    <div class="row-extra">
                        <label class="checkbox"><input type="checkbox" id="rememberAccount"> 记住我</label>
                        <a href="#" class="forgot-link" id="forgotPwdLink">忘记密码？</a>
                    </div>
                    <button class="submit-btn" id="accountLoginBtn"><i class="fas fa-arrow-right-to-bracket"></i> 登录</button>
                </div>

                <div id="smsPanel" class="login-panel">
                    <div class="input-group">
                        <label><i class="fas fa-mobile-alt"></i> 手机号</label>
                        <div class="input-field">
                            <i class="fas fa-phone"></i>
                            <input type="tel" id="smsPhone" placeholder="请输入手机号码" autocomplete="tel">
                        </div>
                        <div class="error-msg" id="smsPhoneError"></div>
                    </div>
                    <div class="input-group">
                        <label><i class="fas fa-comment-dots"></i> 验证码</label>
                        <div class="verification-row">
                            <div class="input-field">
                                <i class="fas fa-shield-alt"></i>
                                <input type="text" id="smsCode" placeholder="验证码">
                            </div>
                            <button class="get-code-btn" id="getSmsCodeBtn">获取验证码</button>
                        </div>
                        <div class="error-msg" id="smsCodeError"></div>
                    </div>
                    <button class="submit-btn" id="smsLoginBtn"><i class="fas fa-mobile-alt"></i> 验证码登录</button>
                </div>

                <div id="wechatPanel" class="login-panel">
                    <div class="wechat-scan-area">
                        <div class="qrcode-mock" id="mockQrcode">
                            <i class="fab fa-weixin"></i>
                            <span>微信扫码</span>
                        </div>
                        <div class="wechat-tip">
                            <i class="fas fa-qrcode"></i> 打开微信扫一扫，快速登录
                        </div>
                        <p style="font-size: 0.65rem; color: #8ba3c2; margin-top: 8px;">演示模式 · 点击模拟登录</p>
                    </div>
                    <button class="submit-btn" id="wechatMockLoginBtn" style="background: linear-gradient(95deg, #1f8a4c, #2c9c5e);"><i class="fab fa-weixin"></i> 模拟微信登录</button>
                </div>

                <div class="other-logins">
                    <p>其他登录方式</p>
                    <div class="social-icons">
                        <div class="social-icon" title="Microsoft 登录"><i class="fab fa-microsoft"></i></div>
                        <div class="social-icon" title="SSO 单点登录"><i class="fas fa-shield-hooded"></i></div>
                        <div class="social-icon" title="GitHub"><i class="fab fa-github"></i></div>
                        <div class="social-icon" title="Google"><i class="fab fa-google"></i></div>
                    </div>
                </div>
                <div class="toggle-form-link">
                    还没有账号？<a id="showRegisterLink">立即注册</a>
                </div>
                <div id="globalLoginMsg" class="form-message"></div>
            </div>

            <div id="registerContainer" class="register-container">
                <div class="form-header">
                    <h3>用户注册</h3>
                    <p>加入PBL社区，开启项目式成长之旅</p>
                </div>
                <div class="input-group">
                    <label><i class="fas fa-user-circle"></i> 用户名</label>
                    <div class="input-field">
                        <i class="fas fa-user"></i>
                        <input type="text" id="regName" placeholder="昵称/真实姓名">
                    </div>
                    <div class="error-msg" id="regNameError"></div>
                </div>
                <div class="input-group">
                    <label><i class="fas fa-envelope"></i> 电子邮箱</label>
                    <div class="input-field">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="regEmail" placeholder="your@example.com">
                    </div>
                    <div class="error-msg" id="regEmailError"></div>
                </div>
                <div class="input-group">
                    <label><i class="fas fa-lock"></i> 设置密码</label>
                    <div class="input-field">
                        <i class="fas fa-key"></i>
                        <input type="password" id="regPwd" placeholder="至少6位字母/数字">
                    </div>
                    <div class="error-msg" id="regPwdError"></div>
                </div>
                <div class="input-group">
                    <label><i class="fas fa-check-circle"></i> 确认密码</label>
                    <div class="input-field">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="regConfirmPwd" placeholder="再次输入密码">
                    </div>
                    <div class="error-msg" id="regConfirmError"></div>
                </div>
                <div class="row-extra" style="justify-content: flex-start;">
                    <label class="checkbox">
                        <input type="checkbox" id="agreeTerms"> 我已阅读并同意《用户协议》和《隐私政策》
                    </label>
                </div>
                <button class="submit-btn" id="registerBtn"><i class="fas fa-user-plus"></i> 注册</button>
                <div class="toggle-form-link">
                    已有账号？<a id="showLoginLink">立即登录</a>
                </div>
                <div id="registerMsg" class="form-message"></div>
            </div>
        </div>
    </div>
</div>

<script>
(function() {
    const loginContainer = document.getElementById('loginContainer');
    const registerContainer = document.getElementById('registerContainer');
    const showRegisterLink = document.getElementById('showRegisterLink');
    const showLoginLink = document.getElementById('showLoginLink');
    
    const loginTabs = document.querySelectorAll('.login-tab');
    const panels = {
        account: document.getElementById('accountPanel'),
        sms: document.getElementById('smsPanel'),
        wechat: document.getElementById('wechatPanel')
    };
    
    const globalLoginMsg = document.getElementById('globalLoginMsg');
    const registerMsgDiv = document.getElementById('registerMsg');
    
    function showMsg(el, msg, type) {
        el.innerText = msg;
        el.className = 'form-message ' + (type || '');
    }
    
    function clearLoginMsg() {
        globalLoginMsg.innerText = '';
        globalLoginMsg.className = 'form-message';
    }
    
    function clearRegMsg() {
        registerMsgDiv.innerText = '';
        registerMsgDiv.className = 'form-message';
    }
    
    function setLoading(btn, loading) {
        if (loading) {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner"></span> 处理中...';
        } else {
            btn.disabled = false;
            btn.innerHTML = btn.getAttribute('data-original') || btn.innerHTML;
        }
    }
    
    document.querySelectorAll('.submit-btn, .get-code-btn').forEach(btn => {
        btn.setAttribute('data-original', btn.innerHTML);
    });
    
    function showLogin() {
        loginContainer.classList.remove('hide');
        registerContainer.classList.remove('active');
        clearLoginMsg();
        clearRegMsg();
    }
    
    function showRegister() {
        loginContainer.classList.add('hide');
        registerContainer.classList.add('active');
        clearLoginMsg();
        clearRegMsg();
    }
    
    showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        showRegister();
    });
    
    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        showLogin();
    });
    
    function switchLoginTab(type) {
        loginTabs.forEach(tab => {
            tab.classList.toggle('active', tab.getAttribute('data-login-type') === type);
        });
        Object.keys(panels).forEach(key => {
            panels[key].classList.toggle('active-panel', key === type);
        });
        clearLoginMsg();
    }
    
    loginTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const type = tab.getAttribute('data-login-type');
            if (type) switchLoginTab(type);
        });
    });
    
    function ajaxRequest(data, successCallback, errorCallback) {
        const formData = new FormData();
        Object.keys(data).forEach(key => {
            formData.append(key, data[key]);
        });
        
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (successCallback) successCallback(data);
            } else {
                if (errorCallback) errorCallback(data);
                else showMsg(globalLoginMsg, data.message || '操作失败', 'error');
            }
        })
        .catch(err => {
            showMsg(globalLoginMsg, '网络错误，请重试', 'error');
            console.error(err);
        });
    }
    
    document.getElementById('accountLoginBtn').addEventListener('click', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('accUsername').value.trim();
        const password = document.getElementById('accPassword').value.trim();
        const remember = document.getElementById('rememberAccount').checked ? 1 : 0;
        
        document.getElementById('accUserError').innerText = '';
        document.getElementById('accPwdError').innerText = '';
        clearLoginMsg();
        
        let valid = true;
        if (!username) {
            document.getElementById('accUserError').innerText = '请输入邮箱/用户名';
            valid = false;
        }
        if (!password) {
            document.getElementById('accPwdError').innerText = '请输入密码';
            valid = false;
        }
        if (!valid) return;
        
        setLoading(this, true);
        ajaxRequest({
            action: 'account_login',
            username: username,
            password: password,
            remember: remember
        }, function(data) {
            setLoading(document.getElementById('accountLoginBtn'), false);
            showMsg(globalLoginMsg, data.message, 'success');
            if (data.data && data.data.redirect) {
                setTimeout(function() {
                    window.location.href = data.data.redirect;
                }, 1000);
            }
        }, function(data) {
            setLoading(document.getElementById('accountLoginBtn'), false);
            showMsg(globalLoginMsg, data.message || '登录失败', 'error');
        });
    });
    
    let countdown = 0;
    const getCodeBtn = document.getElementById('getSmsCodeBtn');
    const smsPhoneInput = document.getElementById('smsPhone');
    
    function startCountdown(seconds) {
        if (countdown > 0) return;
        countdown = seconds;
        getCodeBtn.disabled = true;
        const originalText = getCodeBtn.getAttribute('data-original') || '获取验证码';
        const interval = setInterval(() => {
            if (countdown <= 1) {
                clearInterval(interval);
                getCodeBtn.disabled = false;
                getCodeBtn.innerHTML = originalText;
                countdown = 0;
            } else {
                countdown--;
                getCodeBtn.innerHTML = countdown + '秒后重试';
            }
        }, 1000);
    }
    
    getCodeBtn.addEventListener('click', function() {
        const phone = smsPhoneInput.value.trim();
        document.getElementById('smsPhoneError').innerText = '';
        clearLoginMsg();
        
        if (!phone) {
            document.getElementById('smsPhoneError').innerText = '手机号不能为空';
            return;
        }
        if (!/^1[3-9]\d{9}$/.test(phone)) {
            document.getElementById('smsPhoneError').innerText = '请输入11位有效手机号';
            return;
        }
        
        setLoading(this, true);
        ajaxRequest({
            action: 'send_sms_code',
            phone: phone
        }, function(data) {
            setLoading(getCodeBtn, false);
            showMsg(globalLoginMsg, data.message, 'success');
            if (data.data && data.data.code) {
                document.getElementById('smsCode').value = data.data.code;
                showMsg(globalLoginMsg, '验证码已自动填入（演示）', 'success');
            }
            startCountdown(60);
        }, function(data) {
            setLoading(getCodeBtn, false);
            showMsg(globalLoginMsg, data.message || '发送失败', 'error');
        });
    });
    
    document.getElementById('smsLoginBtn').addEventListener('click', function(e) {
        e.preventDefault();
        
        const phone = smsPhoneInput.value.trim();
        const code = document.getElementById('smsCode').value.trim();
        
        document.getElementById('smsPhoneError').innerText = '';
        document.getElementById('smsCodeError').innerText = '';
        clearLoginMsg();
        
        let valid = true;
        if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
            document.getElementById('smsPhoneError').innerText = '请填写正确的手机号';
            valid = false;
        }
        if (!code) {
            document.getElementById('smsCodeError').innerText = '验证码不能为空';
            valid = false;
        }
        if (!valid) return;
        
        setLoading(this, true);
        ajaxRequest({
            action: 'sms_login',
            phone: phone,
            code: code
        }, function(data) {
            setLoading(document.getElementById('smsLoginBtn'), false);
            showMsg(globalLoginMsg, data.message, 'success');
            if (data.data && data.data.redirect) {
                setTimeout(function() {
                    window.location.href = data.data.redirect;
                }, 1000);
            }
        }, function(data) {
            setLoading(document.getElementById('smsLoginBtn'), false);
            showMsg(globalLoginMsg, data.message || '登录失败', 'error');
        });
    });
    
    function wechatLoginDemo() {
        clearLoginMsg();
        setLoading(document.getElementById('wechatMockLoginBtn'), true);
        
        ajaxRequest({
            action: 'wechat_login',
            openid: 'mock_openid_' + Date.now()
        }, function(data) {
            setLoading(document.getElementById('wechatMockLoginBtn'), false);
            showMsg(globalLoginMsg, data.message, 'success');
            if (data.data && data.data.redirect) {
                setTimeout(function() {
                    window.location.href = data.data.redirect;
                }, 1000);
            }
        }, function(data) {
            setLoading(document.getElementById('wechatMockLoginBtn'), false);
            showMsg(globalLoginMsg, data.message || '微信登录失败', 'error');
        });
    }
    
    document.getElementById('wechatMockLoginBtn').addEventListener('click', function(e) {
        e.preventDefault();
        wechatLoginDemo();
    });
    
    document.getElementById('mockQrcode').addEventListener('click', function() {
        wechatLoginDemo();
    });
    
    document.getElementById('forgotPwdLink').addEventListener('click', function(e) {
        e.preventDefault();
        showMsg(globalLoginMsg, '🔐 请通过邮箱或联系管理员重置密码。', '');
        setTimeout(function() {
            if (globalLoginMsg.innerText.includes('重置密码')) {
                globalLoginMsg.innerText = '';
                globalLoginMsg.className = 'form-message';
            }
        }, 4000);
    });
    
    const regName = document.getElementById('regName');
    const regEmail = document.getElementById('regEmail');
    const regPwd = document.getElementById('regPwd');
    const regConfirm = document.getElementById('regConfirmPwd');
    const agreeTerms = document.getElementById('agreeTerms');
    
    function clearRegErrors() {
        document.getElementById('regNameError').innerText = '';
        document.getElementById('regEmailError').innerText = '';
        document.getElementById('regPwdError').innerText = '';
        document.getElementById('regConfirmError').innerText = '';
    }
    
    document.getElementById('registerBtn').addEventListener('click', function(e) {
        e.preventDefault();
        
        clearRegErrors();
        clearRegMsg();
        
        const username = regName.value.trim();
        const email = regEmail.value.trim();
        const password = regPwd.value.trim();
        const confirm = regConfirm.value.trim();
        
        let isValid = true;
        if (!username) {
            document.getElementById('regNameError').innerText = '请输入用户名';
            isValid = false;
        } else if (username.length < 2) {
            document.getElementById('regNameError').innerText = '用户名至少2个字符';
            isValid = false;
        }
        
        const emailRe = /^[^\s@]+@([^\s@.,]+\.)+[^\s@.,]{2,}$/;
        if (!email) {
            document.getElementById('regEmailError').innerText = '邮箱不能为空';
            isValid = false;
        } else if (!emailRe.test(email)) {
            document.getElementById('regEmailError').innerText = '邮箱格式不正确';
            isValid = false;
        }
        
        if (!password) {
            document.getElementById('regPwdError').innerText = '请设置密码';
            isValid = false;
        } else if (password.length < 6) {
            document.getElementById('regPwdError').innerText = '密码至少6位';
            isValid = false;
        }
        
        if (!confirm) {
            document.getElementById('regConfirmError').innerText = '请确认密码';
            isValid = false;
        } else if (password !== confirm) {
            document.getElementById('regConfirmError').innerText = '两次密码不一致';
            isValid = false;
        }
        
        if (!agreeTerms.checked) {
            showMsg(registerMsgDiv, '请阅读并同意用户协议和隐私政策', 'error');
            isValid = false;
        }
        
        if (!isValid) {
            if (!registerMsgDiv.innerText) {
                showMsg(registerMsgDiv, '注册信息有误，请修正', 'error');
            }
            return;
        }
        
        setLoading(this, true);
        ajaxRequest({
            action: 'register',
            username: username,
            email: email,
            password: password,
            confirm: confirm
        }, function(data) {
            setLoading(document.getElementById('registerBtn'), false);
            showMsg(registerMsgDiv, data.message, 'success');
            setTimeout(function() {
                showLogin();
                document.getElementById('accUsername').value = email;
                showMsg(globalLoginMsg, '注册成功，请使用邮箱登录', 'success');
                regName.value = '';
                regEmail.value = '';
                regPwd.value = '';
                regConfirm.value = '';
                agreeTerms.checked = false;
                clearRegMsg();
                setTimeout(function() {
                    if (globalLoginMsg.innerText.includes('注册成功')) {
                        globalLoginMsg.innerText = '';
                        globalLoginMsg.className = 'form-message';
                    }
                }, 4000);
            }, 1200);
        }, function(data) {
            setLoading(document.getElementById('registerBtn'), false);
            showMsg(registerMsgDiv, data.message || '注册失败', 'error');
        });
    });
    
    document.querySelectorAll('.social-icon').forEach(icon => {
        icon.addEventListener('click', function() {
            const provider = this.title || '第三方';
            showMsg(globalLoginMsg, '🔌 演示: 通过 ' + provider + ' 登录，实际将跳转认证。', '');
            setTimeout(function() {
                if (globalLoginMsg.innerText.includes('演示')) {
                    globalLoginMsg.innerText = '';
                    globalLoginMsg.className = 'form-message';
                }
            }, 3000);
        });
    });
    
    switchLoginTab('account');
    showLogin();
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const activePanel = document.querySelector('.login-panel.active-panel');
            if (activePanel) {
                const btn = activePanel.querySelector('.submit-btn');
                if (btn) btn.click();
            }
        }
    });
    
})();
</script>
</body>
</html>