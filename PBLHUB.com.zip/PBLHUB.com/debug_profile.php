<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 检查是否登录
requireLogin();

// 获取当前用户
$user = getCurrentUser();
if (!$user) {
    die("❌ 用户未登录");
}

echo "=== 调试 profile.php ===<br><br>";

echo "1. 用户信息:<br>";
echo "   ID: " . $user['id'] . "<br>";
echo "   用户名: " . $user['username'] . "<br>";
echo "   角色: " . ($user['role'] ?? '未设置') . "<br><br>";

echo "2. 检查各表是否存在:<br>";

$tables = ['user_profile_extend', 'course_progress', 'course_favorites', 'activities', 'private_messages'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "   ✅ $table 表存在<br>";
    } else {
        echo "   ❌ $table 表不存在<br>";
    }
}

echo "<br>3. 查询统计:<br>";

// 查询课程进度数量
$result = $conn->query("SELECT COUNT(*) as total FROM course_progress WHERE user_id = {$user['id']}");
if ($result) {
    $row = $result->fetch_assoc();
    echo "   课程进度数量: " . $row['total'] . "<br>";
} else {
    echo "   ❌ 查询 course_progress 失败: " . $conn->error . "<br>";
}

// 查询收藏数量
$result = $conn->query("SELECT COUNT(*) as total FROM course_favorites WHERE user_id = {$user['id']}");
if ($result) {
    $row = $result->fetch_assoc();
    echo "   收藏数量: " . $row['total'] . "<br>";
} else {
    echo "   ❌ 查询 course_favorites 失败: " . $conn->error . "<br>";
}

// 查询项目数量
$result = $conn->query("SELECT COUNT(*) as total FROM projects WHERE author_id = {$user['id']}");
if ($result) {
    $row = $result->fetch_assoc();
    echo "   项目数量: " . $row['total'] . "<br>";
} else {
    echo "   ❌ 查询 projects 失败: " . $conn->error . "<br>";
}

// 查询动态数量
$result = $conn->query("SELECT COUNT(*) as total FROM activities WHERE user_id = {$user['id']}");
if ($result) {
    $row = $result->fetch_assoc();
    echo "   动态数量: " . $row['total'] . "<br>";
} else {
    echo "   ❌ 查询 activities 失败: " . $conn->error . "<br>";
}

echo "<br>4. 查询用户信息:<br>";
$sql = "SELECT u.* FROM users u WHERE u.id = {$user['id']}";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "   ✅ 用户信息查询成功<br>";
    echo "   姓名: " . ($row['real_name'] ?? '未设置') . "<br>";
    echo "   学校: " . ($row['school'] ?? '未设置') . "<br>";
    echo "   学科: " . ($row['subject'] ?? '未设置') . "<br>";
} else {
    echo "   ❌ 用户信息查询失败: " . $conn->error . "<br>";
}

echo "<br><br>✅ 调试完成";
?>