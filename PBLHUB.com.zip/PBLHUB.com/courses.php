<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 获取当前用户
$user = null;
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}

function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

function getStatusLabel($status) {
    $map = ['0' => '待审核', '1' => '进行中', '2' => '未开始', '3' => '已完结'];
    return $map[$status] ?? '未知';
}

function getStatusClass($status) {
    $map = ['0' => 'pending', '1' => 'ongoing', '2' => 'upcoming', '3' => 'finished'];
    return $map[$status] ?? '';
}

// ============================================================
// 处理 AJAX 请求
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 获取课程列表 ----------
    if ($action === 'get_courses') {
        $status = $_POST['status'] ?? 'all';
        $keyword = sanitize($_POST['keyword'] ?? '');
        $page = intval($_POST['page'] ?? 1);
        $limit = 8;
        $offset = ($page - 1) * $limit;
        
        $where = "WHERE 1=1";
        if ($status !== 'all' && $status !== '') {
            $where .= " AND status = $status";
        }
        if ($keyword) {
            $keyword = $conn->real_escape_string($keyword);
            $where .= " AND (cTitle LIKE '%$keyword%' OR description LIKE '%$keyword%' OR instructor LIKE '%$keyword%')";
        }
        
        // 查询总数
        $countSql = "SELECT COUNT(*) as total FROM courses $where";
        $countResult = $conn->query($countSql);
        $total = $countResult ? $countResult->fetch_assoc()['total'] : 0;
        
        // 查询数据
        $sql = "SELECT c.*, u.username, u.real_name 
                FROM courses c 
                LEFT JOIN users u ON c.uploader_id = u.id 
                $where 
                ORDER BY c.created_at DESC 
                LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);
        $courses = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $courses[] = $row;
            }
        }
        
        jsonResponse(true, '获取成功', [
            'courses' => $courses,
            'total' => intval($total),
            'page' => $page,
            'total_pages' => $total > 0 ? ceil($total / $limit) : 1
        ]);
    }
    
    // ---------- 切换收藏 ----------
    if ($action === 'toggle_favorite') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '课程ID不能为空');
        
        $sql = "SELECT is_favorite FROM courses WHERE cID = $id";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $current = $row['is_favorite'] ?? 0;
        $new = $current ? 0 : 1;
        
        $sql = "UPDATE courses SET is_favorite = $new WHERE cID = $id";
        if ($conn->query($sql)) {
            jsonResponse(true, $new ? '已收藏' : '已取消收藏', ['is_favorite' => $new]);
        } else {
            jsonResponse(false, '操作失败');
        }
    }
    
    jsonResponse(false, '无效操作');
    exit;
}

// 获取统计数据
function getCourseStats() {
    global $conn;
    $stats = [];
    
    $result = $conn->query("SELECT COUNT(*) as total FROM courses");
    $stats['total'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM courses WHERE status = 1");
    $stats['ongoing'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM courses WHERE status = 2");
    $stats['upcoming'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM courses WHERE status = 3");
    $stats['finished'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM courses WHERE is_favorite = 1");
    $stats['favorites'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    return $stats;
}

$stats = getCourseStats();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 课程中心</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --primary-light: #dbeafe;
            --primary-bg: #f0f7ff;
            --bg: #f6f9fc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-mid: #475569;
            --text-light: #94a3b8;
            --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 12px 32px rgba(0, 0, 0, 0.08);
            --radius: 20px;
            --radius-sm: 12px;
            --transition: 0.25s ease;
        }

        body {
            background: var(--bg);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1360px;
            margin: 0 auto;
            padding: 0 1.8rem;
        }

        /* ===== 导航栏 ===== */
        .navbar {
            background: rgba(255, 255, 255, 0.90);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            padding: 0.6rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid var(--border);
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.6rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }
        .logo i { font-size: 2rem; }
        .logo span {
            font-weight: 300;
            color: var(--text-light);
            font-size: 0.85rem;
            margin-left: 0.1rem;
        }

        .nav-links {
            display: flex;
            gap: 1.8rem;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-mid);
            font-weight: 500;
            font-size: 1rem;
            padding: 0.3rem 0;
            border-bottom: 2.5px solid transparent;
            transition: var(--transition);
            cursor: pointer;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .avatar {
            width: 36px;
            height: 36px;
            background: var(--primary-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-info .name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .user-info .role {
            font-size: 0.65rem;
            color: var(--text-light);
        }
        .logout-link {
            color: var(--text-light);
            font-size: 0.8rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.2rem;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }
        .login-link {
            color: var(--primary);
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            padding: 0.4rem 1.2rem;
            border: 2px solid var(--primary);
            border-radius: 30px;
            transition: var(--transition);
        }
        .login-link:hover { background: var(--primary); color: #fff; }

        /* ===== 课程中心 ===== */
        .page-section {
            padding: 1.5rem 0 2.5rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .page-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .page-header h1 i { color: var(--primary); }
        .page-header .stats {
            font-size: 0.9rem;
            color: var(--text-light);
            background: var(--card-bg);
            padding: 0.3rem 1.2rem;
            border-radius: 30px;
            border: 1px solid var(--border);
        }

        .category-tabs {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            margin-bottom: 1.5rem;
            background: var(--card-bg);
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }
        .category-tabs span {
            padding: 0.4rem 1.4rem;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 500;
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
            background: transparent;
        }
        .category-tabs span:hover {
            background: var(--primary-light);
            color: var(--primary);
        }
        .category-tabs span.active {
            background: var(--primary);
            color: #fff;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
        }
        .category-tabs span .count {
            font-weight: 400;
            font-size: 0.7rem;
            opacity: 0.7;
            margin-left: 0.2rem;
        }
        .category-tabs .search-wrapper {
            margin-left: auto;
            display: flex;
            align-items: center;
            background: var(--bg);
            border-radius: 30px;
            padding: 0.2rem 1rem 0.2rem 1.2rem;
            border: 1px solid var(--border);
            transition: var(--transition);
            min-width: 180px;
        }
        .category-tabs .search-wrapper:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.10);
            background: var(--card-bg);
        }
        .category-tabs .search-wrapper input {
            border: none;
            background: transparent;
            padding: 0.3rem 0.5rem;
            width: 100%;
            font-size: 0.85rem;
            outline: none;
            color: var(--text-dark);
        }
        .category-tabs .search-wrapper input::placeholder { color: var(--text-light); }
        .category-tabs .search-wrapper i { color: var(--text-light); font-size: 0.85rem; }

        .course-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .course-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
            cursor: pointer;
        }
        .course-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
            border-color: #bfdbfe;
        }

        .course-card .cover {
            height: 130px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: var(--primary);
            position: relative;
            flex-shrink: 0;
        }
        .course-card .cover .cover-tag {
            position: absolute;
            top: 0.8rem;
            right: 0.8rem;
            color: #fff;
            font-size: 0.6rem;
            font-weight: 600;
            padding: 0.15rem 0.7rem;
            border-radius: 30px;
            letter-spacing: 0.3px;
        }
        .cover-tag.ongoing { background: #22c55e; }
        .cover-tag.upcoming { background: #f59e0b; }
        .cover-tag.finished { background: #94a3b8; }
        .cover-tag.pending { background: #ef4444; }

        .course-card .body {
            padding: 1.2rem 1.3rem 1.3rem;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .course-card .body .top-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.2rem;
        }
        .course-card .body .top-row h4 {
            font-weight: 600;
            font-size: 1.05rem;
            color: var(--text-dark);
            line-height: 1.3;
        }
        .course-card .body .top-row .fav-btn {
            color: var(--text-light);
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
            padding: 0.2rem 0.3rem;
            border-radius: 6px;
            flex-shrink: 0;
            margin-left: 0.5rem;
        }
        .course-card .body .top-row .fav-btn:hover {
            color: #f59e0b;
            background: #fef3c7;
        }
        .course-card .body .top-row .fav-btn.active { color: #f59e0b; }

        .course-card .body .instructor {
            font-size: 0.8rem;
            color: var(--text-mid);
            margin-bottom: 0.3rem;
        }
        .course-card .body .instructor i {
            color: var(--primary);
            margin-right: 0.2rem;
        }

        .course-card .body .meta-row {
            display: flex;
            gap: 1rem;
            font-size: 0.78rem;
            color: var(--text-light);
            margin-bottom: 0.6rem;
        }
        .course-card .body .meta-row span i { margin-right: 0.2rem; }

        .course-card .body .progress-area {
            margin-top: auto;
            padding-top: 0.6rem;
            border-top: 1px solid var(--border);
        }
        .course-card .body .progress-area .progress-header {
            display: flex;
            justify-content: space-between;
            font-size: 0.75rem;
            color: var(--text-light);
            margin-bottom: 0.2rem;
        }
        .course-card .body .progress-area .progress-header .pct {
            font-weight: 600;
            color: var(--primary);
        }
        .course-card .body .progress-area .track {
            height: 5px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
        }
        .course-card .body .progress-area .track .fill {
            height: 100%;
            background: var(--primary);
            border-radius: 10px;
            transition: width 0.6s ease;
        }

        .course-card .body .action-row {
            display: flex;
            gap: 0.8rem;
            margin-top: 0.6rem;
            padding-top: 0.5rem;
            border-top: 1px solid var(--border);
        }
        .course-card .body .action-row span {
            font-size: 0.78rem;
            color: var(--text-light);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }
        .course-card .body .action-row span:hover { color: var(--primary); }
        .course-card .body .action-row span i { font-size: 0.8rem; }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.4rem;
            margin-top: 1.5rem;
        }
        .pagination span {
            padding: 0.4rem 0.9rem;
            border-radius: 8px;
            background: var(--card-bg);
            border: 1px solid var(--border);
            color: var(--text-mid);
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
        }
        .pagination span.active {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }
        .pagination span:hover:not(.active) {
            border-color: var(--primary);
            color: var(--primary);
        }
        .pagination span.disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        /* ===== Toast ===== */
        .toast-container {
            position: fixed;
            top: 5rem;
            right: 2rem;
            z-index: 300;
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg);
            padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
            border-left: 4px solid var(--primary);
            display: flex;
            align-items: center;
            gap: 0.8rem;
            animation: slideIn 0.35s ease;
            min-width: 260px;
            font-size: 0.9rem;
            color: var(--text-dark);
            border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast.error { border-left-color: #ef4444; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast.error .toast-icon { color: #ef4444; }
        .toast .toast-close {
            margin-left: auto;
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1.1rem;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 3rem 0;
            color: var(--text-light);
        }
        .empty-state i {
            font-size: 3rem;
            display: block;
            margin-bottom: 0.8rem;
            color: var(--primary-light);
        }

        /* ===== 底部 ===== */
        .footer {
            background: var(--card-bg);
            border-top: 1px solid var(--border);
            padding: 2rem 0;
            margin-top: 2rem;
        }
        .footer .container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1.5rem;
        }
        .footer .col {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
            font-size: 0.9rem;
            color: var(--text-mid);
        }
        .footer .col strong { color: var(--text-dark); font-weight: 600; }
        .footer .col i {
            margin-right: 0.4rem;
            color: var(--primary);
            width: 1.2rem;
            text-align: center;
        }
        .footer .col a {
            color: var(--text-mid);
            text-decoration: none;
            transition: var(--transition);
        }
        .footer .col a:hover { color: var(--primary); }
        .footer .bottom {
            text-align: center;
            margin-top: 1.2rem;
            font-size: 0.8rem;
            color: var(--text-light);
            border-top: 1px solid var(--border);
            padding-top: 1rem;
        }

        /* ===== 响应式 ===== */
        @media (max-width: 1024px) {
            .navbar .container { flex-direction: column; gap: 0.5rem; }
            .nav-links { justify-content: center; }
            .category-tabs .search-wrapper { min-width: 140px; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .nav-right { width: 100%; justify-content: center; flex-wrap: wrap; }
            .page-header h1 { font-size: 1.4rem; }
            .page-header .stats { font-size: 0.75rem; padding: 0.2rem 0.8rem; }
            .category-tabs { flex-wrap: wrap; padding: 0.5rem 0.8rem; gap: 0.4rem; }
            .category-tabs span { font-size: 0.78rem; padding: 0.3rem 0.9rem; }
            .category-tabs .search-wrapper { min-width: auto; width: 100%; margin-left: 0; margin-top: 0.3rem; }
            .course-grid { grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; }
            .course-card .cover { height: 100px; font-size: 2.2rem; }
            .course-card .body { padding: 0.8rem 1rem 1rem; }
            .course-card .body .top-row h4 { font-size: 0.95rem; }
            .course-card .body .meta-row { font-size: 0.7rem; gap: 0.6rem; }
        }
        @media (max-width: 480px) {
            .nav-links { gap: 1rem; }
            .nav-links a { font-size: 0.85rem; }
            .course-grid { grid-template-columns: 1fr 1fr; gap: 0.8rem; }
            .course-card .cover { height: 80px; font-size: 1.8rem; }
            .course-card .cover .cover-tag { font-size: 0.5rem; padding: 0.1rem 0.5rem; top: 0.5rem; right: 0.5rem; }
            .course-card .body { padding: 0.6rem 0.7rem 0.8rem; }
            .course-card .body .top-row h4 { font-size: 0.8rem; }
            .course-card .body .instructor { font-size: 0.7rem; }
            .course-card .body .meta-row { font-size: 0.65rem; flex-wrap: wrap; gap: 0.3rem 0.6rem; }
            .course-card .body .progress-area .progress-header { font-size: 0.65rem; }
            .course-card .body .action-row span { font-size: 0.65rem; }
            .avatar { width: 30px; height: 30px; font-size: 0.75rem; }
            .user-info .name { font-size: 0.8rem; }
            .user-info .role { font-size: 0.55rem; }
            .page-header h1 { font-size: 1.1rem; }
            .page-header .stats { font-size: 0.65rem; padding: 0.15rem 0.6rem; }
            .pagination span { padding: 0.2rem 0.6rem; font-size: 0.8rem; }
            .category-tabs span { font-size: 0.7rem; padding: 0.2rem 0.7rem; }
        }
    </style>
</head>
<body>

    <!-- ===== 导航栏 ===== -->
    <nav class="navbar">
        <div class="container">
            <a href="home.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· 项目式学习中心</span>
            </a>
            <div class="nav-links">
                <a href="home.php">首页</a>
                <a href="resources.php">PBL资源库</a>
                <a href="courses.php" class="active">课程中心</a>
                <a href="community.php">教师社区</a>
                <a href="profile.php">个人中心</a>
            </div>
            <div class="nav-right">
                <?php if ($isLoggedIn && $user): ?>
                    <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                    <div class="user-info">
                        <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                        <span class="role"><?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                    </div>
                    <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="index.php" class="login-link"><i class="fas fa-sign-in-alt"></i> 登录</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- ===== 主容器 ===== -->
    <main class="container">

        <section class="page-section">

            <!-- ---- 页面标题 ---- -->
            <div class="page-header">
                <h1><i class="fas fa-graduation-cap"></i> 课程中心</h1>
                <div class="stats">
                    <i class="far fa-file-alt"></i> 共 <span id="totalCount">0</span> 门课程
                </div>
            </div>

            <!-- ---- 分类标签 + 搜索 ---- -->
            <div class="category-tabs">
                <span class="active" data-status="all">全部 <span class="count" id="countAll">(0)</span></span>
                <span data-status="1">进行中 <span class="count" id="countOngoing">(0)</span></span>
                <span data-status="2">未开始 <span class="count" id="countUpcoming">(0)</span></span>
                <span data-status="3">已完结 <span class="count" id="countFinished">(0)</span></span>
                <span data-status="favorite">我收藏的 <span class="count" id="countFavorites">(0)</span></span>
                <div class="search-wrapper">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchKeyword" placeholder="搜索课程名称..." onkeydown="if(event.key==='Enter') loadCourses(1)">
                </div>
            </div>

            <!-- ---- 课程卡片网格 ---- -->
            <div class="course-grid" id="courseGrid">
                <div class="empty-state">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>加载中...</p>
                </div>
            </div>

            <!-- ---- 分页 ---- -->
            <div class="pagination" id="pagination"></div>

        </section>

    </main>

    <!-- ===== 底部 ===== -->
    <footer class="footer">
        <div class="container">
            <div class="col">
                <strong>PBL HUB</strong>
                <span>项目式学习教师研修社区</span>
                <span><i class="fas fa-map-marker-alt"></i> 兰州市 · 教育创新中心</span>
            </div>
            <div class="col">
                <strong>关于我们</strong>
                <span><i class="fas fa-envelope"></i> contact@pblhub.edu</span>
                <span><i class="fas fa-users"></i> 成员：张老师、李老师、王老师</span>
                <span><i class="fas fa-info-circle"></i> 赋能教师PBL设计</span>
            </div>
            <div class="col">
                <strong>快速链接</strong>
                <a href="home.php"><i class="fas fa-home"></i> 首页</a>
                <a href="profile.php"><i class="fas fa-user"></i> 个人中心</a>
                <a href="#"><i class="fas fa-info-circle"></i> 关于我们</a>
            </div>
        </div>
        <div class="bottom">
            © <?php echo date('Y'); ?> PBL HUB · 项目式学习中心
        </div>
    </footer>

    <!-- ===== Toast 容器 ===== -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- ============================================================ -->
    <!-- ======================== JavaScript =========================== -->
    <!-- ============================================================ -->
    <script>
document.addEventListener('DOMContentLoaded', function() {
    var currentPage = 1;
    var totalPages = 1;
    var currentStatus = 'all';

    // ============================================================
    // Toast 通知
    // ============================================================
    function showToast(message, type) {
        type = type || 'success';
        var container = document.getElementById('toastContainer');
        var icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
        var toast = document.createElement('div');
        toast.className = 'toast ' + type;
        toast.innerHTML =
            '<span class="toast-icon"><i class="fas ' + (icons[type] || icons.success) + '"></i></span>' +
            '<span>' + message + '</span>' +
            '<button class="toast-close">&times;</button>';
        container.appendChild(toast);
        toast.querySelector('.toast-close').addEventListener('click', function() { toast.remove(); });
        setTimeout(function() {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(40px)';
            setTimeout(function() { toast.remove(); }, 300);
        }, 4000);
    }

    // ============================================================
    // 跳转到课程播放页面
    // ============================================================
    function goToCourse(courseId) {
        console.log('跳转到课程: ' + courseId);
        window.location.href = 'course_play.php?cid=' + courseId;
    }

    // ============================================================
    // 加载课程
    // ============================================================
    function loadCourses(page) {
        page = page || currentPage;
        var keyword = document.getElementById('searchKeyword').value.trim();
        var status = currentStatus === 'favorite' ? '' : currentStatus;

        var data = new FormData();
        data.append('action', 'get_courses');
        data.append('status', status);
        data.append('keyword', keyword);
        data.append('page', page);

        var grid = document.getElementById('courseGrid');
        grid.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';

        fetch(window.location.href, { method: 'POST', body: data })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.success) {
                    renderCourses(data.data.courses);
                    renderPagination(data.data.page, data.data.total_pages);
                    document.getElementById('totalCount').textContent = data.data.total;
                    currentPage = data.data.page;
                    totalPages = data.data.total_pages;
                } else {
                    showToast(data.message || '加载失败', 'error');
                }
            })
            .catch(function(err) {
                showToast('网络错误，请重试', 'error');
                console.error(err);
            });
    }

    // ============================================================
    // 渲染课程卡片
    // ============================================================
    function renderCourses(courses) {
        var grid = document.getElementById('courseGrid');

        if (!courses || courses.length === 0) {
            grid.innerHTML = '<div class="empty-state"><i class="fas fa-inbox"></i><p>暂无课程</p></div>';
            return;
        }

        var coverColors = [
            'linear-gradient(135deg, #dbeafe, #93c5fd)',
            'linear-gradient(135deg, #fef3c7, #fcd34d)',
            'linear-gradient(135deg, #d1fae5, #6ee7b7)',
            'linear-gradient(135deg, #e0e7ff, #a5b4fc)',
            'linear-gradient(135deg, #fce7f3, #f9a8d4)',
            'linear-gradient(135deg, #dbeafe, #60a5fa)',
            'linear-gradient(135deg, #e0e7ff, #818cf8)',
            'linear-gradient(135deg, #fef3c7, #fbbf24)'
        ];

        var statusClassMap = {
            '1': 'ongoing',
            '2': 'upcoming',
            '3': 'finished',
            '0': 'pending'
        };

        var statusLabelMap = {
            '1': '进行中',
            '2': '未开始',
            '3': '已完结',
            '0': '待审核'
        };

        var html = '';
        for (var i = 0; i < courses.length; i++) {
            var course = courses[i];
            var color = coverColors[i % coverColors.length];
            var statusClass = statusClassMap[course.status] || 'pending';
            var statusLabel = statusLabelMap[course.status] || '未知';
            var favClass = course.is_favorite ? 'active' : '';
            var favIcon = course.is_favorite ? 'fas fa-star' : 'far fa-star';
            var progress = parseInt(course.progress) || 0;

            // 解决 onclick 和 onmouseover 冲突，直接用 onclick
            var cardId = 'card_' + course.cID;

            var actionHtml = '';
            if (course.status == 1 || course.status == 0) {
                actionHtml = '<span onclick="event.cancelBubble=true; goToCourse(' + course.cID + ')"><i class="fas fa-play-circle"></i> 继续学习</span>';
            } else if (course.status == 2) {
                actionHtml = '<span onclick="event.cancelBubble=true; goToCourse(' + course.cID + ')"><i class="fas fa-play-circle"></i> 开始学习</span>';
            } else if (course.status == 3) {
                actionHtml = '<span onclick="event.cancelBubble=true; goToCourse(' + course.cID + ')"><i class="fas fa-redo"></i> 复习</span><span><i class="fas fa-certificate"></i> 已结业</span>';
            }

            html +=
                '<div class="course-card" id="' + cardId + '" data-id="' + course.cID + '" style="cursor:pointer;">' +
                '  <div class="cover" style="background: ' + color + ';" onclick="goToCourse(' + course.cID + ')">' +
                '    <i class="fas ' + (course.icon || 'fa-graduation-cap') + '"></i>' +
                '    <span class="cover-tag ' + statusClass + '">' + statusLabel + '</span>' +
                '  </div>' +
                '  <div class="body" onclick="goToCourse(' + course.cID + ')">' +
                '    <div class="top-row">' +
                '      <h4>' + escapeHtml(course.cTitle) + '</h4>' +
                '      <span class="fav-btn ' + favClass + '" onclick="event.cancelBubble=true; toggleFavorite(' + course.cID + ')" title="' + (course.is_favorite ? '已收藏' : '收藏') + '">' +
                '        <i class="' + favIcon + '"></i>' +
                '      </span>' +
                '    </div>' +
                '    <div class="instructor"><i class="fas fa-user"></i> ' + escapeHtml(course.instructor || '未知') + '</div>' +
                '    <div class="meta-row">' +
                '      <span><i class="far fa-clock"></i> ' + (course.lessons || 0) + ' 课时</span>' +
                '      <span><i class="far fa-user"></i> ' + (course.level || '不限') + ' · ' + (course.subject || '') + '</span>' +
                '    </div>' +
                '    <div class="progress-area">' +
                '      <div class="progress-header"><span>学习进度</span><span class="pct">' + progress + '%</span></div>' +
                '      <div class="track"><div class="fill" style="width:' + progress + '%;"></div></div>' +
                '    </div>' +
                '    <div class="action-row">' + actionHtml + '</div>' +
                '  </div>' +
                '</div>';
        }
        grid.innerHTML = html;

        // 为每个卡片单独绑定点击事件（备用方案）
        var cards = document.querySelectorAll('.course-card');
        for (var i = 0; i < cards.length; i++) {
            (function(card) {
                var id = parseInt(card.dataset.id);
                card.addEventListener('click', function(e) {
                    // 如果点击的是收藏按钮或操作按钮，不跳转
                    if (e.target.closest('.fav-btn') || e.target.closest('.action-row span')) {
                        return;
                    }
                    goToCourse(id);
                });
            })(cards[i]);
        }
    }

    // ============================================================
    // 渲染分页
    // ============================================================
    function renderPagination(page, total) {
        var container = document.getElementById('pagination');
        if (total <= 1) {
            container.innerHTML = '';
            return;
        }
        var html = '';
        html += '<span class="' + (page <= 1 ? 'disabled' : '') + '" onclick="loadCourses(' + (page - 1) + ')"><i class="fas fa-chevron-left"></i></span>';
        for (var i = 1; i <= total; i++) {
            html += '<span class="' + (i === page ? 'active' : '') + '" onclick="loadCourses(' + i + ')">' + i + '</span>';
        }
        html += '<span class="' + (page >= total ? 'disabled' : '') + '" onclick="loadCourses(' + (page + 1) + ')"><i class="fas fa-chevron-right"></i></span>';
        container.innerHTML = html;
    }

    // ============================================================
    // 工具函数
    // ============================================================
    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // ============================================================
    // 分类标签切换
    // ============================================================
    var tabs = document.querySelectorAll('.category-tabs span[data-status]');
    for (var i = 0; i < tabs.length; i++) {
        (function(tab) {
            tab.addEventListener('click', function() {
                var allTabs = document.querySelectorAll('.category-tabs span[data-status]');
                for (var j = 0; j < allTabs.length; j++) {
                    allTabs[j].classList.remove('active');
                }
                this.classList.add('active');
                currentStatus = this.dataset.status;
                loadCourses(1);
            });
        })(tabs[i]);
    }

    // ============================================================
    // 收藏切换
    // ============================================================
    function toggleFavorite(id) {
        <?php if (!$isLoggedIn): ?>
            showToast('请先登录', 'warning');
            return;
        <?php endif; ?>

        var data = new FormData();
        data.append('action', 'toggle_favorite');
        data.append('id', id);

        fetch(window.location.href, { method: 'POST', body: data })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.success) {
                    showToast(data.message, 'success');
                    loadCourses(currentPage);
                } else {
                    showToast(data.message || '操作失败', 'error');
                }
            })
            .catch(function(err) { showToast('操作失败', 'error'); });
    }

    // ============================================================
    // 统计更新
    // ============================================================
    function updateStats() {
        var counts = <?php echo json_encode($stats); ?>;
        document.getElementById('countAll').textContent = '(' + counts.total + ')';
        document.getElementById('countOngoing').textContent = '(' + counts.ongoing + ')';
        document.getElementById('countUpcoming').textContent = '(' + counts.upcoming + ')';
        document.getElementById('countFinished').textContent = '(' + counts.finished + ')';
        document.getElementById('countFavorites').textContent = '(' + counts.favorites + ')';
        document.getElementById('totalCount').textContent = counts.total;
    }

    // ============================================================
    // 初始化
    // ============================================================
    updateStats();
    loadCourses(1);

    // 暴露 goToCourse 到全局，供 HTML onclick 调用
    window.goToCourse = goToCourse;
    window.toggleFavorite = toggleFavorite;
    window.loadCourses = loadCourses;
    window.showToast = showToast;
});
</script>

</body>
</html>