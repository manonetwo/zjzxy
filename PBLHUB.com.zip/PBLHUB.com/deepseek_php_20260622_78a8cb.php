<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

// 测试 admin2026 账号
$username = 'admin2026';
$password = '123456';

echo "=== 测试登录 ===<br>";

// 查询用户
$sql = "SELECT id, username, real_name, email, password_hash, role FROM users WHERE username = '$username' OR email = '$username'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "✅ 找到用户: " . $user['username'] . "<br>";
    echo "📌 角色: " . $user['role'] . "<br>";
    echo "📌 密码哈希: " . $user['password_hash'] . "<br>";
    
    // 验证密码
    if (verifyPassword($password, $user['password_hash'])) {
        echo "✅ 密码验证成功！<br>";
        echo "🎉 可以登录！";
    } else {
        echo "❌ 密码验证失败！";
    }
} else {
    echo "❌ 用户不存在";
}
?>