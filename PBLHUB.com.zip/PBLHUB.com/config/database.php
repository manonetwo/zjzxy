<?php
// 数据库配置 - 适配你的 Phpstudy
define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // Phpstudy默认用户名
define('DB_PASS', 'root');          // Phpstudy默认密码（如果是空密码就改 ''）
define('DB_NAME', 'pblhub');       // 数据库名称

// 创建数据库连接
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// 检查连接
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 设置字符集
$conn->set_charset("utf8mb4");
?>