<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 检查是否登录
requireLogin();

// 获取当前用户
$user = getCurrentUser();
if (!$user) {
    header('Location: index.php');
    exit;
}

// 检查角色：只有 admin 和 expert 可以访问
$allowedRoles = ['admin', 'expert'];
if (!in_array($user['role'] ?? '', $allowedRoles)) {
    header('Location: home.php');
    exit;
}

function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// ============================================================
// 处理 AJAX 请求
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 获取统计数据 ----------
    if ($action === 'get_stats') {
        $stats = [];
        
        // 待批改作业（模拟数据，后续可对接真实表）
        $stats['pending_homework'] = 12;
        $stats['completed_homework'] = 48;
        $stats['pending_review'] = 5;
        $stats['expert_points'] = 1284;
        
        jsonResponse(true, '获取成功', ['stats' => $stats]);
        exit;
    }
    
    // ---------- 获取待办任务 ----------
    if ($action === 'get_tasks') {
        // 从 projects 表获取待审核的项目作为任务
        $sql = "SELECT p.*, u.username, u.real_name 
                FROM projects p 
                LEFT JOIN users u ON p.author_id = u.id 
                WHERE p.status = 0 
                ORDER BY p.created_at DESC 
                LIMIT 10";
        $result = $conn->query($sql);
        $tasks = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $tasks[] = $row;
            }
        }
        jsonResponse(true, '获取成功', ['tasks' => $tasks]);
        exit;
    }
    
    // ---------- 处理任务（通过审核） ----------
    if ($action === 'approve_task') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '项目ID不能为空');
        
        $sql = "UPDATE projects SET status = 1, updated_at = NOW() WHERE pID = $id";
        if ($conn->query($sql)) {
            jsonResponse(true, '审核通过');
        } else {
            jsonResponse(false, '操作失败：' . $conn->error);
        }
        exit;
    }
    
    // ---------- 获取评审项目 ----------
    if ($action === 'get_review_projects') {
        $sql = "SELECT p.*, u.username, u.real_name 
                FROM projects p 
                LEFT JOIN users u ON p.author_id = u.id 
                WHERE p.status IN (0, 1) 
                ORDER BY p.created_at DESC 
                LIMIT 10";
        $result = $conn->query($sql);
        $projects = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $projects[] = $row;
            }
        }
        jsonResponse(true, '获取成功', ['projects' => $projects]);
        exit;
    }
    
    // ---------- 获取学习动态 ----------
    if ($action === 'get_activities') {
        $tableCheck = $conn->query("SHOW TABLES LIKE 'activities'");
        if (!$tableCheck || $tableCheck->num_rows === 0) {
            jsonResponse(true, '获取成功', ['activities' => []]);
            exit;
        }
        
        $sql = "SELECT * FROM activities 
                WHERE user_id = {$user['id']} 
                ORDER BY created_at DESC 
                LIMIT 10";
        $result = $conn->query($sql);
        $activities = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $activities[] = $row;
            }
        }
        jsonResponse(true, '获取成功', ['activities' => $activities]);
        exit;
    }
    
    jsonResponse(false, '无效操作');
    exit;
}

// ============================================================
// 获取用户完整信息
// ============================================================
function getUserFullInfo($user_id) {
    global $conn;
    $sql = "SELECT u.*, e.nickname, e.birthday, e.province, e.city, e.education, 
                   e.teaching_years, e.research_direction, e.personal_intro
            FROM users u
            LEFT JOIN user_profile_extend e ON u.id = e.user_id
            WHERE u.id = $user_id";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

$userInfo = getUserFullInfo($user['id']);
if (!$userInfo) {
    $userInfo = $user;
}

// ============================================================
// 获取消息通知
// ============================================================
function getMessages($user_id) {
    global $conn;
    $tableCheck = $conn->query("SHOW TABLES LIKE 'private_messages'");
    if (!$tableCheck || $tableCheck->num_rows === 0) return ['messages' => [], 'unread' => 0];
    $sql = "SELECT pm.*, u.username, u.real_name 
            FROM private_messages pm 
            LEFT JOIN users u ON pm.sender_id = u.id
            WHERE pm.receiver_id = $user_id 
            ORDER BY pm.created_at DESC 
            LIMIT 10";
    $result = $conn->query($sql);
    $messages = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
    }
    $unreadResult = $conn->query("SELECT COUNT(*) as unread FROM private_messages WHERE receiver_id = $user_id AND is_read = 0");
    $unread = $unreadResult ? intval($unreadResult->fetch_assoc()['unread'] ?? 0) : 0;
    return ['messages' => $messages, 'unread' => $unread];
}
$msgResult = getMessages($user['id']);
$messages = $msgResult['messages'];
$unreadCount = $msgResult['unread'];

function formatTime($dateStr) {
    if (!$dateStr) return '未知';
    $now = new DateTime();
    $past = new DateTime($dateStr);
    $diff = $now->diff($past);
    if ($diff->y > 0) return $diff->y . '年前';
    if ($diff->m > 0) return $diff->m . '个月前';
    if ($diff->d > 0) return $diff->d . '天前';
    if ($diff->h > 0) return $diff->h . '小时前';
    if ($diff->i > 0) return $diff->i . '分钟前';
    return '刚刚';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 专家工作台</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --primary-light: #dbeafe;
            --primary-bg: #f0f7ff;
            --bg: #f6f9fc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-mid: #475569;
            --text-light: #94a3b8;
            --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 12px 32px rgba(0, 0, 0, 0.08);
            --radius: 20px;
            --radius-sm: 12px;
            --transition: 0.25s ease;
            --expert-accent: #7c3aed;
            --expert-accent-light: #ede9fe;
        }

        body {
            background: var(--bg);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1360px;
            margin: 0 auto;
            padding: 0 1.8rem;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.90);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            padding: 0.6rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 2px solid var(--expert-accent);
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.6rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }
        .logo i { font-size: 2rem; }
        .logo span {
            font-weight: 300;
            color: var(--text-light);
            font-size: 0.85rem;
            margin-left: 0.1rem;
        }

        .nav-links {
            display: flex;
            gap: 1.8rem;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-mid);
            font-weight: 500;
            font-size: 1rem;
            padding: 0.3rem 0;
            border-bottom: 2.5px solid transparent;
            transition: var(--transition);
            cursor: pointer;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }
        .nav-links a.expert-badge {
            background: var(--expert-accent-light);
            color: var(--expert-accent);
            border-radius: 30px;
            padding: 0.2rem 1rem 0.2rem 0.8rem;
            border-bottom: none;
            font-weight: 600;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }
        .nav-links a.expert-badge i { font-size: 0.7rem; }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .avatar {
            width: 36px;
            height: 36px;
            background: var(--expert-accent-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--expert-accent);
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-info .name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .user-info .role {
            font-size: 0.65rem;
            color: var(--expert-accent);
            font-weight: 500;
        }
        .logout-link {
            color: var(--text-light);
            font-size: 0.8rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.2rem;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }

        .notification-wrapper { position: relative; }
        .notification-btn {
            background: none;
            border: none;
            font-size: 1.2rem;
            color: var(--text-mid);
            cursor: pointer;
            position: relative;
            padding: 0.2rem 0.5rem;
            border-radius: 30px;
            transition: var(--transition);
        }
        .notification-btn:hover {
            background: var(--bg);
            color: var(--primary);
        }
        .notification-btn .badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: #ef4444;
            color: #fff;
            font-size: 0.6rem;
            font-weight: 700;
            padding: 0.1rem 0.4rem;
            border-radius: 50%;
            min-width: 18px;
            text-align: center;
            line-height: 1.2;
        }
        .notification-dropdown {
            display: none;
            position: absolute;
            top: 45px;
            right: 0;
            width: 360px;
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow-hover);
            border: 1px solid var(--border);
            z-index: 1000;
            padding: 0.5rem 0;
        }
        .notification-dropdown.show { display: block; animation: fadeIn 0.25s ease; }
        .notification-header {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 1rem;
            border-bottom: 1px solid var(--border);
            font-weight: 600;
            color: var(--text-dark);
        }
        .notification-header .mark-read {
            font-size: 0.75rem;
            font-weight: 400;
            color: var(--primary);
            cursor: pointer;
        }
        .notification-header .mark-read:hover { text-decoration: underline; }
        .notification-list { max-height: 320px; overflow-y: auto; }
        .notification-item {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.6rem 1rem;
            border-bottom: 1px solid var(--border);
            transition: var(--transition);
        }
        .notification-item:last-child { border-bottom: none; }
        .notification-item:hover { background: var(--bg); }
        .notification-item .notif-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary-light);
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.8rem;
        }
        .notification-item .notif-content { flex: 1; display: flex; flex-direction: column; }
        .notification-item .notif-text { font-size: 0.85rem; color: var(--text-mid); }
        .notification-item .notif-text strong { color: var(--text-dark); }
        .notification-item .notif-time { font-size: 0.65rem; color: var(--text-light); }

        .page-section { padding: 1.5rem 0 2.5rem; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .expert-layout {
            display: grid;
            grid-template-columns: 260px 1fr;
            gap: 1.8rem;
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            overflow: hidden;
            box-shadow: var(--shadow);
            min-height: 600px;
        }

        .expert-sidebar {
            background: var(--bg);
            padding: 1.8rem 1.2rem 1.5rem;
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }

        .expert-sidebar .user-avatar {
            text-align: center;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 0.6rem;
        }
        .expert-sidebar .user-avatar .avatar-big {
            width: 80px;
            height: 80px;
            background: var(--expert-accent-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.6rem;
            color: var(--expert-accent);
            margin: 0 auto 0.5rem;
            border: 3px solid #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
        }
        .expert-sidebar .user-avatar .uname {
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--text-dark);
        }
        .expert-sidebar .user-avatar .urole {
            font-size: 0.8rem;
            color: var(--expert-accent);
            font-weight: 500;
        }

        .expert-sidebar .menu-item {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            padding: 0.6rem 0.9rem;
            border-radius: var(--radius-sm);
            color: var(--text-mid);
            font-weight: 500;
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
            border: none;
            background: transparent;
            width: 100%;
            text-align: left;
        }
        .expert-sidebar .menu-item i {
            width: 1.4rem;
            font-size: 1rem;
            color: var(--text-light);
            transition: var(--transition);
        }
        .expert-sidebar .menu-item:hover {
            background: var(--expert-accent-light);
            color: var(--expert-accent);
        }
        .expert-sidebar .menu-item:hover i { color: var(--expert-accent); }
        .expert-sidebar .menu-item.active {
            background: var(--expert-accent-light);
            color: var(--expert-accent);
            font-weight: 600;
        }
        .expert-sidebar .menu-item.active i { color: var(--expert-accent); }
        .expert-sidebar .menu-divider {
            height: 1px;
            background: var(--border);
            margin: 0.3rem 0;
        }
        .expert-sidebar .menu-item.danger { color: #dc2626; }
        .expert-sidebar .menu-item.danger i { color: #dc2626; }
        .expert-sidebar .menu-item.danger:hover {
            background: #fee2e2;
            color: #b91c1c;
        }
        .expert-sidebar .menu-item.danger:hover i { color: #b91c1c; }

        .expert-content {
            padding: 1.8rem 2rem 2rem;
            overflow-y: auto;
        }
        .expert-content .panel {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        .expert-content .panel.active { display: block; }
        .expert-content .panel-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .expert-content .panel-title i { color: var(--expert-accent); }
        .expert-content .panel-title .badge-count {
            background: var(--expert-accent-light);
            color: var(--expert-accent);
            font-size: 0.7rem;
            font-weight: 600;
            padding: 0.1rem 0.7rem;
            border-radius: 30px;
            margin-left: 0.3rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 1rem;
            margin-bottom: 1.8rem;
        }
        .stat-card {
            background: var(--bg);
            border-radius: var(--radius-sm);
            padding: 1rem 1.2rem;
            border: 1px solid var(--border);
            transition: var(--transition);
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
        }
        .stat-card .stat-label {
            font-size: 0.8rem;
            color: var(--text-light);
            font-weight: 500;
        }
        .stat-card .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-dark);
            line-height: 1.2;
        }
        .stat-card .stat-icon {
            float: right;
            font-size: 1.6rem;
            color: var(--expert-accent-light);
            opacity: 0.7;
        }
        .stat-card .stat-sub {
            font-size: 0.7rem;
            color: var(--text-light);
        }

        .task-list {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
        }
        .task-item {
            background: var(--bg);
            border-radius: var(--radius-sm);
            padding: 0.8rem 1.2rem;
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            transition: var(--transition);
            border-left: 4px solid var(--expert-accent);
        }
        .task-item:hover {
            border-color: var(--expert-accent-light);
        }
        .task-item .info {
            flex: 1;
            min-width: 150px;
        }
        .task-item .info .title {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-dark);
        }
        .task-item .info .meta {
            font-size: 0.8rem;
            color: var(--text-light);
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
        }
        .task-item .task-status {
            font-size: 0.7rem;
            font-weight: 500;
            padding: 0.1rem 0.8rem;
            border-radius: 30px;
        }
        .task-status.urgent {
            background: #fee2e2;
            color: #dc2626;
        }
        .task-status.normal {
            background: #fef3c7;
            color: #d97706;
        }
        .task-status.done {
            background: #d1fae5;
            color: #059669;
        }
        .task-item .task-action {
            background: var(--expert-accent);
            color: #fff;
            border: none;
            padding: 0.2rem 1.2rem;
            border-radius: 30px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: var(--transition);
        }
        .task-item .task-action:hover {
            background: var(--primary-hover);
        }
        .task-item .task-action.secondary {
            background: var(--bg);
            color: var(--text-mid);
            border: 1px solid var(--border);
        }
        .task-item .task-action.secondary:hover {
            border-color: var(--text-mid);
        }

        .project-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 1rem;
        }
        .project-item {
            background: var(--bg);
            border-radius: var(--radius-sm);
            padding: 0.8rem 1rem;
            border: 1px solid var(--border);
            transition: var(--transition);
        }
        .project-item:hover {
            border-color: var(--expert-accent-light);
            transform: translateY(-2px);
        }
        .project-item .proj-title {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-dark);
        }
        .project-item .proj-meta {
            font-size: 0.8rem;
            color: var(--text-light);
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
        }
        .project-item .proj-status {
            font-size: 0.7rem;
            font-weight: 500;
            padding: 0.05rem 0.7rem;
            border-radius: 30px;
            display: inline-block;
            margin-top: 0.2rem;
        }
        .project-item .proj-status.pending {
            background: #fef3c7;
            color: #d97706;
        }
        .project-item .proj-status.reviewing {
            background: var(--expert-accent-light);
            color: var(--expert-accent);
        }
        .project-item .proj-status.approved {
            background: #d1fae5;
            color: #059669;
        }
        .project-item .proj-status.rejected {
            background: #fee2e2;
            color: #dc2626;
        }
        .project-item .proj-actions {
            display: flex;
            gap: 0.6rem;
            margin-top: 0.3rem;
        }
        .project-item .proj-actions button {
            background: transparent;
            border: none;
            font-size: 0.75rem;
            color: var(--text-light);
            cursor: pointer;
            transition: var(--transition);
            padding: 0.1rem 0.4rem;
        }
        .project-item .proj-actions button:hover {
            color: var(--expert-accent);
        }
        .project-item .proj-actions button.danger:hover { color: #dc2626; }

        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }
        .activity-item {
            background: var(--bg);
            border-radius: var(--radius-sm);
            padding: 0.7rem 1.2rem;
            border-left: 4px solid var(--expert-accent);
            border: 1px solid var(--border);
            border-left-width: 4px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.8rem;
            flex-wrap: wrap;
        }
        .activity-item:hover {
            border-color: var(--expert-accent-light);
        }
        .activity-item .act-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--expert-accent-light);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--expert-accent);
            flex-shrink: 0;
        }
        .activity-item .act-content {
            flex: 1;
            min-width: 160px;
        }
        .activity-item .act-content .act-text {
            font-size: 0.92rem;
            color: var(--text-dark);
        }
        .activity-item .act-content .act-text strong {
            color: var(--expert-accent);
        }
        .activity-item .act-content .act-meta {
            font-size: 0.75rem;
            color: var(--text-light);
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
            margin-top: 0.1rem;
        }
        .activity-item .act-time {
            font-size: 0.75rem;
            color: var(--text-light);
            white-space: nowrap;
        }

        .empty-state-sm {
            text-align: center;
            padding: 2rem 0;
            color: var(--text-light);
        }
        .empty-state-sm i {
            font-size: 2.5rem;
            display: block;
            margin-bottom: 0.4rem;
            color: var(--border);
        }
        .empty-state-sm h4 {
            font-weight: 500;
            color: var(--text-mid);
        }

        .account-section {
            background: var(--bg);
            border-radius: var(--radius-sm);
            padding: 1.5rem 1.8rem;
            border: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }
        .account-section .row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.6rem;
            padding-bottom: 0.8rem;
            border-bottom: 1px solid var(--border);
        }
        .account-section .row:last-child { border-bottom: none; padding-bottom: 0; }
        .account-section .row .label {
            font-weight: 500;
            color: var(--text-dark);
        }
        .account-section .row .label i {
            margin-right: 0.5rem;
            color: var(--text-light);
        }
        .account-section .row .value {
            color: var(--text-mid);
            font-size: 0.95rem;
        }
        .account-section .row .action-btn {
            background: var(--primary-light);
            color: var(--primary);
            border: none;
            padding: 0.2rem 1.2rem;
            border-radius: 30px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: var(--transition);
        }
        .account-section .row .action-btn:hover {
            background: var(--primary);
            color: #fff;
        }
        .account-section .row .action-btn.danger {
            background: #fee2e2;
            color: #dc2626;
        }
        .account-section .row .action-btn.danger:hover {
            background: #dc2626;
            color: #fff;
        }

        .footer {
            background: var(--card-bg);
            border-top: 1px solid var(--border);
            padding: 2rem 0;
            margin-top: 2rem;
        }
        .footer .container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1.5rem;
        }
        .footer .col {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
            font-size: 0.9rem;
            color: var(--text-mid);
        }
        .footer .col strong { color: var(--text-dark); font-weight: 600; }
        .footer .col i {
            margin-right: 0.4rem;
            color: var(--primary);
            width: 1.2rem;
            text-align: center;
        }
        .footer .col a {
            color: var(--text-mid);
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
        }
        .footer .col a:hover { color: var(--primary); }
        .footer .bottom {
            text-align: center;
            margin-top: 1.2rem;
            font-size: 0.8rem;
            color: var(--text-light);
            border-top: 1px solid var(--border);
            padding-top: 1rem;
        }

        .toast-container {
            position: fixed;
            top: 5rem;
            right: 2rem;
            z-index: 300;
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg);
            padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
            border-left: 4px solid var(--primary);
            display: flex;
            align-items: center;
            gap: 0.8rem;
            animation: slideIn 0.35s ease;
            min-width: 260px;
            font-size: 0.9rem;
            color: var(--text-dark);
            border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast.error { border-left-color: #ef4444; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast.error .toast-icon { color: #ef4444; }
        .toast .toast-close {
            margin-left: auto;
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1.1rem;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 1024px) {
            .navbar .container { flex-direction: column; gap: 0.5rem; }
            .nav-links { justify-content: center; }
            .expert-layout { grid-template-columns: 1fr; grid-template-rows: auto 1fr; }
            .expert-sidebar {
                border-right: none;
                border-bottom: 1px solid var(--border);
                flex-direction: row;
                flex-wrap: wrap;
                padding: 1rem 1.2rem;
                gap: 0.3rem;
            }
            .expert-sidebar .user-avatar { display: none; }
            .expert-sidebar .menu-item { padding: 0.4rem 0.8rem; font-size: 0.85rem; width: auto; }
            .expert-sidebar .menu-divider { display: none; }
            .expert-content { padding: 1.2rem; }
            .stats-grid { grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); }
            .notification-dropdown { width: 320px; right: -20px; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .nav-right { width: 100%; justify-content: center; flex-wrap: wrap; }
            .expert-sidebar .menu-item { font-size: 0.8rem; padding: 0.3rem 0.6rem; }
            .expert-sidebar .menu-item i { font-size: 0.85rem; }
            .project-grid { grid-template-columns: 1fr 1fr; gap: 0.8rem; }
            .task-item { flex-direction: column; align-items: stretch; gap: 0.4rem; }
            .notification-dropdown { width: 300px; right: -10px; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 0.6rem; }
            .stat-card .stat-number { font-size: 1.6rem; }
        }
        @media (max-width: 480px) {
            .nav-links { gap: 1rem; }
            .nav-links a { font-size: 0.85rem; }
            .project-grid { grid-template-columns: 1fr; gap: 0.8rem; }
            .expert-content { padding: 0.8rem; }
            .expert-sidebar { padding: 0.6rem 0.8rem; gap: 0.2rem; }
            .expert-sidebar .menu-item { font-size: 0.75rem; padding: 0.25rem 0.5rem; }
            .expert-sidebar .menu-item i { font-size: 0.75rem; width: 1rem; }
            .user-info .name { font-size: 0.8rem; }
            .avatar { width: 30px; height: 30px; font-size: 0.75rem; }
            .notification-dropdown { width: 280px; right: 0; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 0.5rem; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="container">
            <a href="home.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· <?php echo $user['role'] === 'admin' ? '管理员' : '专家'; ?>端</span>
            </a>
            <div class="nav-links">
                <a href="home.php">首页</a>
                <a href="resources.php">PBL资源库</a>
                <a href="courses.php">课程中心</a>
                <a href="community.php">教师社区</a>
                <a class="active expert-badge"><i class="fas fa-user-graduate"></i> <?php echo $user['role'] === 'admin' ? '管理 · 一级' : '专家工作台'; ?></a>
            </div>
            <div class="nav-right">
                <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                <div class="user-info">
                    <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                    <span class="role"><i class="fas fa-<?php echo $user['role'] === 'admin' ? 'crown' : 'star'; ?>"></i> <?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                </div>
                <div class="notification-wrapper">
                    <button class="notification-btn" id="notificationBtn">
                        <i class="fas fa-bell"></i>
                        <span class="badge" id="unreadBadge"><?php echo $unreadCount; ?></span>
                    </button>
                    <div class="notification-dropdown" id="notificationDropdown">
                        <div class="notification-header">
                            <span>消息通知</span>
                            <span class="mark-read" id="markReadBtn">全部已读</span>
                        </div>
                        <div class="notification-list" id="messageList">
                            <?php if (empty($messages)): ?>
                                <div style="text-align:center;padding:1rem;color:var(--text-light);">暂无消息</div>
                            <?php else: ?>
                                <?php foreach ($messages as $m): ?>
                                <div class="notification-item" style="<?php echo !$m['is_read'] ? 'background:#f0f7ff;' : ''; ?>">
                                    <div class="notif-avatar"><?php echo htmlspecialchars($m['real_name'] ? mb_substr($m['real_name'], 0, 1) : ($m['username'] ? mb_substr($m['username'], 0, 1) : 'U')); ?></div>
                                    <div class="notif-content">
                                        <span class="notif-text"><strong><?php echo htmlspecialchars($m['real_name'] ?? $m['username'] ?? '未知用户'); ?></strong> <?php echo htmlspecialchars($m['content']); ?></span>
                                        <span class="notif-time"><?php echo formatTime($m['created_at']); ?></span>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
            </div>
        </div>
    </nav>

    <main class="container">
        <section class="page-section">
            <div class="expert-layout">

                <aside class="expert-sidebar">
                    <div class="user-avatar">
                        <div class="avatar-big"><i class="fas fa-user-graduate"></i></div>
                        <div class="uname"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></div>
                        <div class="urole"><i class="fas fa-star" style="color:#f59e0b;"></i> <?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></div>
                    </div>
                    <button class="menu-item active" data-panel="dashboard"><i class="fas fa-gauge-high"></i> 工作总览</button>
                    <button class="menu-item" data-panel="tasks"><i class="fas fa-clipboard-list"></i> 待办任务 <span class="badge-count" id="taskBadge">0</span></button>
                    <button class="menu-item" data-panel="projects"><i class="fas fa-folder-open"></i> 评审项目</button>
                    <button class="menu-item" data-panel="activity"><i class="fas fa-rss"></i> 学习动态</button>
                    <div class="menu-divider"></div>
                    <button class="menu-item" data-panel="account"><i class="fas fa-cog"></i> 账号管理</button>
                    <button class="menu-item danger" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> 退出登录</button>
                </aside>

                <div class="expert-content">

                    <div class="panel active" id="panel-dashboard">
                        <div class="panel-title"><i class="fas fa-gauge-high"></i> 工作总览</div>
                        <div class="stats-grid" id="statsGrid">
                            <div class="stat-card">
                                <div class="stat-icon"><i class="fas fa-clock-rotate-left"></i></div>
                                <div class="stat-label">待批改作业</div>
                                <div class="stat-number" id="statPendingHomework">0</div>
                                <div class="stat-sub">较昨日 +3</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                                <div class="stat-label">已批改</div>
                                <div class="stat-number" id="statCompletedHomework">0</div>
                                <div class="stat-sub">本月累计</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-icon"><i class="fas fa-project-diagram"></i></div>
                                <div class="stat-label">待评审项目</div>
                                <div class="stat-number" id="statPendingReview">0</div>
                                <div class="stat-sub">2 项待反馈</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-icon"><i class="fas fa-star"></i></div>
                                <div class="stat-label">专家积分</div>
                                <div class="stat-number" id="statExpertPoints">0</div>
                                <div class="stat-sub">排名 Top 8%</div>
                            </div>
                        </div>
                        <div style="margin-top:0.5rem;">
                            <h4 style="font-weight:600;font-size:0.95rem;color:var(--text-dark);margin-bottom:0.6rem;display:flex;align-items:center;gap:0.4rem;">
                                <i class="fas fa-clock" style="color:var(--expert-accent);"></i> 最近待办
                            </h4>
                            <div class="task-list" id="dashboardTaskList"></div>
                        </div>
                    </div>

                    <div class="panel" id="panel-tasks">
                        <div class="panel-title"><i class="fas fa-clipboard-list"></i> 待办任务 <span class="badge-count" id="taskCount">0</span></div>
                        <div class="task-list" id="taskList"></div>
                    </div>

                    <div class="panel" id="panel-projects">
                        <div class="panel-title"><i class="fas fa-folder-open"></i> 评审项目 <span class="badge-count" id="projectCount">0</span></div>
                        <div class="project-grid" id="projectGrid"></div>
                    </div>

                    <div class="panel" id="panel-activity">
                        <div class="panel-title"><i class="fas fa-rss"></i> 学习动态 <span class="badge-count" id="activityCount">0</span></div>
                        <div class="activity-list" id="activityList"></div>
                    </div>

                    <div class="panel" id="panel-account">
                        <div class="panel-title"><i class="fas fa-cog"></i> 账号管理</div>
                        <div class="account-section">
                            <div class="row">
                                <span class="label"><i class="fas fa-user"></i> 账号</span>
                                <span class="value"><?php echo htmlspecialchars($user['username']); ?></span>
                            </div>
                            <div class="row">
                                <span class="label"><i class="fas fa-envelope"></i> 邮箱</span>
                                <span class="value"><?php echo htmlspecialchars($user['email'] ?? '未绑定'); ?></span>
                                <button class="action-btn" onclick="showToast('修改邮箱功能开发中', 'warning')">修改邮箱</button>
                            </div>
                            <div class="row">
                                <span class="label"><i class="fas fa-lock"></i> 密码</span>
                                <span class="value">••••••••</span>
                                <button class="action-btn" id="changePwdBtn">修改密码</button>
                            </div>
                            <div class="row" style="border-bottom:none;padding-bottom:0;">
                                <span class="label"><i class="fas fa-sign-out-alt"></i> 退出登录</span>
                                <span class="value" style="color:var(--text-light);font-size:0.85rem;">退出后需重新登录</span>
                                <button class="action-btn danger" id="logoutBtn2">立即退出</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="col">
                <strong>PBL HUB</strong>
                <span>项目式学习教师研修社区</span>
                <span><i class="fas fa-map-marker-alt"></i> 兰州市 · 教育创新中心</span>
            </div>
            <div class="col">
                <strong>关于我们</strong>
                <span><i class="fas fa-envelope"></i> contact@pblhub.edu</span>
                <span><i class="fas fa-users"></i> 成员：张老师、李老师、王老师</span>
                <span><i class="fas fa-info-circle"></i> 赋能教师PBL设计</span>
            </div>
            <div class="col">
                <strong>快速链接</strong>
                <a href="home.php"><i class="fas fa-home"></i> 首页</a>
                <a href="profile.php"><i class="fas fa-user"></i> 个人中心</a>
            </div>
        </div>
        <div class="bottom">© <?php echo date('Y'); ?> PBL HUB · 项目式学习中心</div>
    </footer>

    <!-- ===== 修改密码弹窗 ===== -->
    <div class="modal-overlay" id="changePwdModal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,0.5);backdrop-filter:blur(6px);z-index:200;align-items:center;justify-content:center;padding:1.5rem;">
        <div class="modal" style="background:var(--card-bg);border-radius:var(--radius);max-width:600px;width:92%;padding:2rem 2.2rem;box-shadow:0 24px 64px rgba(0,0,0,0.16);max-height:90vh;overflow-y:auto;animation:slideUp 0.3s ease;">
            <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.2rem;">
                <h2 style="font-size:1.3rem;font-weight:700;color:var(--text-dark);display:flex;align-items:center;gap:0.6rem;"><i class="fas fa-lock" style="color:var(--primary);"></i> 修改密码</h2>
                <button class="close-btn" id="closePwdModal" style="background:none;border:none;font-size:1.6rem;color:var(--text-light);cursor:pointer;">&times;</button>
            </div>
            <form id="changePwdForm" onsubmit="return false;">
                <div class="form-group" style="margin-bottom:1rem;">
                    <label style="display:block;font-weight:600;font-size:0.9rem;color:var(--text-dark);margin-bottom:0.3rem;">当前密码 <span style="color:#ef4444;margin-left:0.2rem;">*</span></label>
                    <input type="password" id="oldPassword" placeholder="请输入当前密码" style="width:100%;padding:0.6rem 1rem;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:0.95rem;background:var(--bg);color:var(--text-dark);outline:none;">
                </div>
                <div class="form-group" style="margin-bottom:1rem;">
                    <label style="display:block;font-weight:600;font-size:0.9rem;color:var(--text-dark);margin-bottom:0.3rem;">新密码 <span style="color:#ef4444;margin-left:0.2rem;">*</span></label>
                    <input type="password" id="newPassword" placeholder="请输入新密码（至少6位）" style="width:100%;padding:0.6rem 1rem;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:0.95rem;background:var(--bg);color:var(--text-dark);outline:none;">
                </div>
                <div class="form-group" style="margin-bottom:1rem;">
                    <label style="display:block;font-weight:600;font-size:0.9rem;color:var(--text-dark);margin-bottom:0.3rem;">确认新密码 <span style="color:#ef4444;margin-left:0.2rem;">*</span></label>
                    <input type="password" id="confirmPassword" placeholder="请再次输入新密码" style="width:100%;padding:0.6rem 1rem;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:0.95rem;background:var(--bg);color:var(--text-dark);outline:none;">
                </div>
                <div class="submit-row" style="display:flex;gap:1rem;margin-top:1.2rem;padding-top:1rem;border-top:1px solid var(--border);">
                    <button type="submit" class="btn-submit" id="savePwdBtn" style="background:var(--primary);color:#fff;border:none;padding:0.6rem 2.4rem;border-radius:40px;font-weight:600;font-size:0.95rem;cursor:pointer;transition:var(--transition);flex:1;">确认修改</button>
                    <button type="button" class="btn-cancel" id="cancelPwdBtn" style="background:transparent;color:var(--text-mid);border:1.5px solid var(--border);padding:0.6rem 2rem;border-radius:40px;font-weight:500;font-size:0.95rem;cursor:pointer;">取消</button>
                </div>
            </form>
        </div>
    </div>

    <div id="toastContainer"></div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {

        // ============================================================
        // Toast 通知
        // ============================================================
        function showToast(message, type) {
            type = type || 'success';
            var container = document.getElementById('toastContainer');
            var icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
            var toast = document.createElement('div');
            toast.className = 'toast ' + type;
            toast.style.cssText = 'background:#fff;padding:0.8rem 1.6rem 0.8rem 1.2rem;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,0.12);border-left:4px solid ' + (type === 'success' ? '#22c55e' : type === 'warning' ? '#f59e0b' : '#ef4444') + ';display:flex;align-items:center;gap:0.8rem;animation:slideIn 0.35s ease;min-width:260px;font-size:0.9rem;color:#0f172a;border:1px solid #e9edf4;';
            toast.innerHTML =
                '<span style="font-size:1.2rem;color:' + (type === 'success' ? '#22c55e' : type === 'warning' ? '#f59e0b' : '#ef4444') + ';"><i class="fas ' + (icons[type] || icons.success) + '"></i></span>' +
                '<span>' + message + '</span>' +
                '<button style="margin-left:auto;background:none;border:none;color:#94a3b8;cursor:pointer;font-size:1.1rem;">&times;</button>';
            container.appendChild(toast);
            toast.querySelector('button').addEventListener('click', function() { toast.remove(); });
            setTimeout(function() { toast.style.opacity = '0'; toast.style.transform = 'translateX(40px)'; setTimeout(function() { toast.remove(); }, 300); }, 4000);
        }

        // ============================================================
        // 侧边栏切换
        // ============================================================
        var menuItems = document.querySelectorAll('.expert-sidebar .menu-item[data-panel]');
        for (var i = 0; i < menuItems.length; i++) {
            (function(item) {
                item.addEventListener('click', function() {
                    var target = this.dataset.panel;
                    var allMenus = document.querySelectorAll('.expert-sidebar .menu-item[data-panel]');
                    for (var j = 0; j < allMenus.length; j++) {
                        allMenus[j].classList.remove('active');
                    }
                    this.classList.add('active');
                    var panels = document.querySelectorAll('.expert-content .panel');
                    for (var k = 0; k < panels.length; k++) {
                        panels[k].classList.remove('active');
                    }
                    var panel = document.getElementById('panel-' + target);
                    if (panel) panel.classList.add('active');
                });
            })(menuItems[i]);
        }

        // ============================================================
        // 加载统计数据
        // ============================================================
        function loadStats() {
            var data = new FormData();
            data.append('action', 'get_stats');

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var s = data.data.stats;
                        document.getElementById('statPendingHomework').textContent = s.pending_homework || 0;
                        document.getElementById('statCompletedHomework').textContent = s.completed_homework || 0;
                        document.getElementById('statPendingReview').textContent = s.pending_review || 0;
                        document.getElementById('statExpertPoints').textContent = s.expert_points || 0;
                    }
                })
                .catch(function(err) { console.error(err); });
        }

        // ============================================================
        // 加载待办任务
        // ============================================================
        function loadTasks() {
            var data = new FormData();
            data.append('action', 'get_tasks');

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var tasks = data.data.tasks;
                        document.getElementById('taskBadge').textContent = tasks.length;
                        document.getElementById('taskCount').textContent = tasks.length;
                        renderTasks(tasks);
                        renderDashboardTasks(tasks.slice(0, 3));
                    }
                })
                .catch(function(err) { console.error(err); });
        }

        function renderDashboardTasks(tasks) {
            var container = document.getElementById('dashboardTaskList');
            if (!container) return;
            if (!tasks || tasks.length === 0) {
                container.innerHTML = '<div class="empty-state-sm"><i class="fas fa-check-circle"></i><h4>暂无待办任务</h4><p>所有任务已完成，太棒了！</p></div>';
                return;
            }
            var html = '';
            for (var i = 0; i < tasks.length; i++) {
                var t = tasks[i];
                var author = t.real_name || t.username || '未知用户';
                html +=
                    '<div class="task-item">' +
                    '  <div class="info">' +
                    '    <div class="title">' + escapeHtml(t.title) + '</div>' +
                    '    <div class="meta">' + escapeHtml(author) + ' · <span class="task-status urgent">待审核</span></div>' +
                    '  </div>' +
                    '  <button class="task-action" onclick="approveTask(' + t.pID + ')">审核通过</button>' +
                    '</div>';
            }
            container.innerHTML = html;
        }

        function renderTasks(tasks) {
            var container = document.getElementById('taskList');
            if (!container) return;
            if (!tasks || tasks.length === 0) {
                container.innerHTML = '<div class="empty-state-sm"><i class="fas fa-check-circle"></i><h4>暂无待办任务</h4><p>所有任务已完成，太棒了！</p></div>';
                return;
            }
            var html = '';
            for (var i = 0; i < tasks.length; i++) {
                var t = tasks[i];
                var author = t.real_name || t.username || '未知用户';
                html +=
                    '<div class="task-item">' +
                    '  <div class="info">' +
                    '    <div class="title">' + escapeHtml(t.title) + '</div>' +
                    '    <div class="meta">' + escapeHtml(author) + ' · <span class="task-status urgent">待审核</span></div>' +
                    '  </div>' +
                    '  <button class="task-action" onclick="approveTask(' + t.pID + ')"><i class="fas fa-check"></i> 通过</button>' +
                    '  <button class="task-action secondary" onclick="showToast(\'已标记稍后处理\', \'warning\')">稍后</button>' +
                    '</div>';
            }
            container.innerHTML = html;
        }

        // ============================================================
        // 审核通过
        // ============================================================
        function approveTask(id) {
            if (!confirm('确定要审核通过这个项目吗？')) return;

            var data = new FormData();
            data.append('action', 'approve_task');
            data.append('id', id);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        showToast('✅ 审核通过', 'success');
                        loadTasks();
                        loadReviewProjects();
                    } else {
                        showToast(data.message || '操作失败', 'error');
                    }
                })
                .catch(function(err) { showToast('操作失败', 'error'); });
        }

        // ============================================================
        // 加载评审项目
        // ============================================================
        function loadReviewProjects() {
            var data = new FormData();
            data.append('action', 'get_review_projects');

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        renderReviewProjects(data.data.projects);
                    }
                })
                .catch(function(err) { console.error(err); });
        }

        function renderReviewProjects(projects) {
            var container = document.getElementById('projectGrid');
            var countBadge = document.getElementById('projectCount');
            if (!container) return;
            if (!projects || projects.length === 0) {
                container.innerHTML = '<div class="empty-state-sm" style="grid-column:1/-1;"><i class="fas fa-folder-open"></i><h4>暂无评审项目</h4></div>';
                if (countBadge) countBadge.textContent = '0';
                return;
            }
            if (countBadge) countBadge.textContent = projects.length;

            var statusMap = {
                0: { label: '待评审', cls: 'pending' },
                1: { label: '已通过', cls: 'approved' },
                2: { label: '已下架', cls: 'rejected' }
            };

            var html = '';
            for (var i = 0; i < projects.length; i++) {
                var p = projects[i];
                var st = statusMap[p.status] || { label: '未知', cls: 'pending' };
                var author = p.real_name || p.username || '未知';
                var dateStr = p.created_at ? formatDate(p.created_at) : '未知';
                html +=
                    '<div class="project-item">' +
                    '  <div class="proj-title">' + escapeHtml(p.title) + '</div>' +
                    '  <div class="proj-meta">' +
                    '    <span><i class="fas fa-user"></i> ' + escapeHtml(author) + '</span>' +
                    '    <span><i class="far fa-calendar-alt"></i> ' + dateStr + '</span>' +
                    '    <span class="proj-status ' + st.cls + '">' + st.label + '</span>' +
                    '  </div>' +
                    '  <div class="proj-actions">' +
                    '    <button onclick="showToast(\'评审项目：' + escapeHtml(p.title) + '\', \'warning\')"><i class="fas fa-pen"></i> 评审</button>' +
                    '    <button onclick="showToast(\'查看项目：' + escapeHtml(p.title) + '\', \'warning\')"><i class="fas fa-eye"></i> 查看</button>' +
                    '  </div>' +
                    '</div>';
            }
            container.innerHTML = html;
        }

        // ============================================================
        // 加载学习动态
        // ============================================================
        function loadActivities() {
            var data = new FormData();
            data.append('action', 'get_activities');

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        renderActivities(data.data.activities);
                    }
                })
                .catch(function(err) { console.error(err); });
        }

        function renderActivities(activities) {
            var container = document.getElementById('activityList');
            var countBadge = document.getElementById('activityCount');
            if (!container) return;
            if (!activities || activities.length === 0) {
                container.innerHTML = '<div class="empty-state-sm"><i class="fas fa-rss"></i><h4>暂无动态</h4></div>';
                if (countBadge) countBadge.textContent = '0';
                return;
            }
            if (countBadge) countBadge.textContent = activities.length;

            var iconMap = { learn: 'fa-play-circle', course_complete: 'fa-check-circle', collect: 'fa-heart', post: 'fa-pen', comment: 'fa-comment', like: 'fa-thumbs-up', badge: 'fa-award' };
            var colorMap = { learn: '#2563eb', course_complete: '#22c55e', collect: '#dc2626', post: '#f59e0b', comment: '#8b5cf6', like: '#ec4899', badge: '#f59e0b' };
            var labelMap = { learn: '学习了', course_complete: '完成了', collect: '收藏了', post: '发布了', comment: '评论了', like: '赞了', badge: '获得了' };

            var html = '';
            for (var i = 0; i < activities.length; i++) {
                var a = activities[i];
                var icon = iconMap[a.action_type] || 'fa-circle';
                var color = colorMap[a.action_type] || '#2563eb';
                var label = labelMap[a.action_type] || '操作了';
                html +=
                    '<div class="activity-item">' +
                    '  <div class="act-icon" style="color:' + color + '; background:' + color + '22;"><i class="fas ' + icon + '"></i></div>' +
                    '  <div class="act-content">' +
                    '    <div class="act-text">' + label + ' <strong>' + escapeHtml(a.target_title || '未知内容') + '</strong></div>' +
                    '    <div class="act-meta"><span>类型：' + escapeHtml(a.target_type) + '</span></div>' +
                    '  </div>' +
                    '  <span class="act-time">' + formatTime(a.created_at) + '</span>' +
                    '</div>';
            }
            container.innerHTML = html;
        }

        // ============================================================
        // 工具函数
        // ============================================================
        function escapeHtml(str) {
            if (!str) return '';
            var div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        function formatTime(dateStr) {
            if (!dateStr) return '未知';
            var now = new Date();
            var past = new Date(dateStr);
            var diffMs = now - past;
            var diffMins = Math.floor(diffMs / 60000);
            var diffHours = Math.floor(diffMs / 3600000);
            var diffDays = Math.floor(diffMs / 86400000);
            if (diffMins < 1) return '刚刚';
            if (diffMins < 60) return diffMins + '分钟前';
            if (diffHours < 24) return diffHours + '小时前';
            if (diffDays < 7) return diffDays + '天前';
            return past.toLocaleDateString('zh-CN');
        }

        function formatDate(dateStr) {
            if (!dateStr) return '未知';
            var d = new Date(dateStr);
            return d.toLocaleDateString('zh-CN');
        }

        // ============================================================
        // 通知下拉
        // ============================================================
        var notificationBtn = document.getElementById('notificationBtn');
        var notificationDropdown = document.getElementById('notificationDropdown');
        var markReadBtn = document.getElementById('markReadBtn');

        notificationBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            notificationDropdown.classList.toggle('show');
        });

        document.addEventListener('click', function(e) {
            if (!notificationDropdown.contains(e.target) && e.target !== notificationBtn && !notificationBtn.contains(e.target)) {
                notificationDropdown.classList.remove('show');
            }
        });

        markReadBtn.addEventListener('click', function() {
            var data = new FormData();
            data.append('action', 'mark_read');
            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        document.getElementById('unreadBadge').textContent = '0';
                        showToast('全部已读', 'success');
                        // 重新加载消息
                        location.reload();
                    }
                });
        });

        // ============================================================
        // 修改密码
        // ============================================================
        var changePwdModal = document.getElementById('changePwdModal');

        document.getElementById('changePwdBtn').addEventListener('click', function() {
            changePwdModal.style.display = 'flex';
            document.getElementById('oldPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        });

        function closePwdModal() {
            changePwdModal.style.display = 'none';
        }

        document.getElementById('closePwdModal').addEventListener('click', closePwdModal);
        document.getElementById('cancelPwdBtn').addEventListener('click', closePwdModal);
        changePwdModal.addEventListener('click', function(e) {
            if (e.target === this) closePwdModal();
        });

        document.getElementById('savePwdBtn').addEventListener('click', function() {
            var oldPwd = document.getElementById('oldPassword').value.trim();
            var newPwd = document.getElementById('newPassword').value.trim();
            var confirmPwd = document.getElementById('confirmPassword').value.trim();

            if (!oldPwd || !newPwd || !confirmPwd) {
                showToast('请填写完整信息', 'warning');
                return;
            }
            if (newPwd.length < 6) {
                showToast('新密码至少6位', 'warning');
                return;
            }
            if (newPwd !== confirmPwd) {
                showToast('两次密码不一致', 'warning');
                return;
            }

            var data = new FormData();
            data.append('action', 'change_password');
            data.append('old_password', oldPwd);
            data.append('new_password', newPwd);
            data.append('confirm_password', confirmPwd);

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 修改中...';

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    document.getElementById('savePwdBtn').disabled = false;
                    document.getElementById('savePwdBtn').innerHTML = '确认修改';
                    if (data.success) {
                        showToast('密码修改成功', 'success');
                        closePwdModal();
                    } else {
                        showToast(data.message || '修改失败', 'error');
                    }
                })
                .catch(function(err) { showToast('修改失败', 'error'); });
        });

        // ============================================================
        // 退出登录
        // ============================================================
        function handleLogout() {
            if (confirm('确定要退出登录吗？')) {
                window.location.href = 'logout.php';
            }
        }

        document.getElementById('logoutBtn').addEventListener('click', handleLogout);
        document.getElementById('logoutBtn2').addEventListener('click', handleLogout);

        // ============================================================
        // 暴露全局函数
        // ============================================================
        window.showToast = showToast;
        window.approveTask = approveTask;

        // ============================================================
        // 初始化加载
        // ============================================================
        loadStats();
        loadTasks();
        loadReviewProjects();
        loadActivities();

        console.log('✅ 专家工作台加载完成');

    });
    </script>

</body>
</html>