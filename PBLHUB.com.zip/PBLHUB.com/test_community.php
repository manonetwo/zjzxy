<?php
require_once __DIR__ . '/config/database.php';

echo "=== 调试社区数据 ===<br><br>";

// 1. 检查 posts 表是否存在
$result = $conn->query("SHOW TABLES LIKE 'posts'");
if ($result->num_rows == 0) {
    die("❌ posts 表不存在！请先创建");
}
echo "✅ posts 表存在<br>";

// 2. 查询帖子数量
$result = $conn->query("SELECT COUNT(*) as total FROM posts");
$row = $result->fetch_assoc();
echo "📊 帖子总数: " . $row['total'] . "<br>";

// 3. 查询帖子数据
$sql = "SELECT p.*, u.username, u.real_name 
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        WHERE status = 1 
        ORDER BY is_pinned DESC, created_at DESC 
        LIMIT 10";
$result = $conn->query($sql);

if ($result === false) {
    die("❌ 查询失败: " . $conn->error);
}

echo "<br>📋 帖子列表:<br>";
if ($result->num_rows == 0) {
    echo "⚠️ 没有找到 status=1 的帖子<br>";
} else {
    while ($row = $result->fetch_assoc()) {
        echo "- ID: " . $row['post_id'] . " | 标题: " . $row['title'] . " | 作者: " . ($row['real_name'] ?? $row['username'] ?? '未知') . " | status: " . $row['status'] . "<br>";
    }
}

// 4. 检查前端 AJAX 请求是否正常
echo "<br><br>=== 测试 AJAX 接口 ===<br>";
?>
<form id="testForm">
    <button type="button" onclick="testAjax()">点击测试 AJAX 请求</button>
</form>
<div id="ajaxResult" style="margin-top:10px;padding:10px;background:#f0f0f0;border-radius:8px;white-space:pre-wrap;"></div>

<script>
function testAjax() {
    const data = new FormData();
    data.append('action', 'get_posts');
    data.append('filter', 'all');
    data.append('page', 1);

    document.getElementById('ajaxResult').innerHTML = '⏳ 请求中...';

    fetch('community.php', {
        method: 'POST',
        body: data
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('ajaxResult').innerHTML = JSON.stringify(data, null, 2);
    })
    .catch(err => {
        document.getElementById('ajaxResult').innerHTML = '❌ 错误: ' + err.message;
    });
}
</script>