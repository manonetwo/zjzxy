<?php
// 防止SQL注入
function sanitize($input) {
    global $conn;
    if ($input === null) return '';
    return $conn->real_escape_string(trim($input));
}

// 密码哈希
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// 验证密码
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// 生成随机验证码
function generateCode($length = 6) {
    return str_pad(random_int(100000, 999999), $length, '0', STR_PAD_LEFT);
}

// JSON响应
function jsonResponse($success, $message, $data = null) {
    header('Content-Type: application/json');
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

// 获取用户IP
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// 记录登录日志
function logLogin($user_id, $type, $status) {
    global $conn;
    $ip = getClientIP();
    $user_agent = sanitize($_SERVER['HTTP_USER_AGENT'] ?? '');
    $sql = "INSERT INTO login_logs (user_id, login_type, status, ip_address, user_agent) 
            VALUES ($user_id, '$type', '$status', '$ip', '$user_agent')";
    $conn->query($sql);
}
?>