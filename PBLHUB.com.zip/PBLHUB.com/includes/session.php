<?php
// 启动会话
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 检查是否已登录
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// 未登录则跳转到登录页
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

// 已登录则根据角色跳转
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        $role = $_SESSION['role'] ?? 'student';
        if ($role === 'admin' || $role === 'expert') {
            header('Location: admin.php');
        } else {
            header('Location: home.php');
        }
        exit;
    }
}

// 获取当前用户信息（完整版）
function getCurrentUser() {
    global $conn;
    if (!isLoggedIn()) return null;
    
    $user_id = intval($_SESSION['user_id']);
    $sql = "SELECT id, username, real_name, email, phone, avatar, role, school, subject, bio, created_at FROM users WHERE id = $user_id";
    $result = $conn->query($sql);
    return $result->fetch_assoc();
}
?>