<?php
require_once __DIR__ . '/includes/session.php';

// 清除session
$_SESSION = array();
session_destroy();

// 清除cookie
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/');
}

// 跳转到首页
header('Location: index.php');
exit;
?>