<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 检查是否登录
requireLogin();

// 获取当前用户
$user = getCurrentUser();

// 检查角色：只有 admin 和 expert 可以访问
$allowedRoles = ['admin', 'expert'];
if (!in_array($user['role'] ?? '', $allowedRoles)) {
    header('Location: home.php');
    exit;
}

function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// ============================================================
// 处理 AJAX 请求
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 获取内容列表 ----------
    if ($action === 'get_contents') {
        $type = $_POST['type'] ?? 'all';
        $keyword = sanitize($_POST['keyword'] ?? '');
        $page = intval($_POST['page'] ?? 1);
        $limit = 10;
        $offset = ($page - 1) * $limit;
        
        $where = "WHERE 1=1";
        if ($type === 'project') {
            $where .= " AND type = 'project'";
        } elseif ($type === 'course') {
            $where .= " AND type = 'course'";
        }
        if ($keyword) {
            $keyword = $conn->real_escape_string($keyword);
            $where .= " AND (title LIKE '%$keyword%' OR description LIKE '%$keyword%')";
        }
        
        $sql = "(SELECT p.pID as id, p.title, p.description, p.status, p.created_at, 'project' as type, u.username, u.real_name, p.level, p.subject 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id 
                 $where)
                 UNION
                 (SELECT c.id, c.title, c.description, c.status, c.created_at, 'course' as type, u.username, u.real_name, '' as level, '' as subject 
                 FROM courses c 
                 LEFT JOIN users u ON c.author_id = u.id 
                 WHERE 1=1)
                 ORDER BY created_at DESC 
                 LIMIT $limit OFFSET $offset";
        
        $result = $conn->query($sql);
        $contents = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $contents[] = $row;
            }
        }
        
        $countSql = "SELECT COUNT(*) as total FROM (
            SELECT p.pID as id FROM projects p WHERE 1=1
            UNION ALL
            SELECT c.id FROM courses c WHERE 1=1
        ) as combined";
        $countResult = $conn->query($countSql);
        $total = $countResult ? $countResult->fetch_assoc()['total'] : 0;
        
        jsonResponse(true, '获取成功', [
            'contents' => $contents,
            'total' => intval($total),
            'page' => $page,
            'total_pages' => $total > 0 ? ceil($total / $limit) : 1
        ]);
    }
    
    // ---------- 删除内容 ----------
    if ($action === 'delete_content') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        $id = intval($_POST['id'] ?? 0);
        $type = sanitize($_POST['type'] ?? '');
        
        if (!$id) jsonResponse(false, '内容ID不能为空');
        if (!$type) jsonResponse(false, '内容类型不能为空');
        
        if ($type === 'project') {
            $sql = "DELETE FROM projects WHERE pID = $id";
        } elseif ($type === 'course') {
            $sql = "DELETE FROM courses WHERE id = $id";
        } else {
            jsonResponse(false, '不支持的内容类型');
        }
        
        if ($conn->query($sql)) {
            jsonResponse(true, '删除成功');
        } else {
            jsonResponse(false, '删除失败：' . $conn->error);
        }
    }
    
    // ---------- 更新内容状态 ----------
    if ($action === 'update_status') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        $id = intval($_POST['id'] ?? 0);
        $type = sanitize($_POST['type'] ?? '');
        $status = intval($_POST['status'] ?? 0);
        
        if (!$id) jsonResponse(false, '内容ID不能为空');
        if (!$type) jsonResponse(false, '内容类型不能为空');
        
        if ($type === 'project') {
            $sql = "UPDATE projects SET status = $status WHERE pID = $id";
        } elseif ($type === 'course') {
            $sql = "UPDATE courses SET status = $status WHERE id = $id";
        } else {
            jsonResponse(false, '不支持的内容类型');
        }
        
        if ($conn->query($sql)) {
            jsonResponse(true, '状态更新成功');
        } else {
            jsonResponse(false, '更新失败：' . $conn->error);
        }
    }
    
    jsonResponse(false, '无效操作');
    exit;
}

// 获取内容统计
function getContentStats() {
    global $conn;
    $stats = [];
    
    $result = $conn->query("SELECT COUNT(*) as total FROM projects");
    $stats['projects'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status = 0");
    $stats['pending_projects'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status = 1");
    $stats['published_projects'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $stats['courses'] = 0;
    
    return $stats;
}

$stats = getContentStats();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 内容管理</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --primary-light: #dbeafe;
            --primary-bg: #f0f7ff;
            --bg: #f6f9fc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-mid: #475569;
            --text-light: #94a3b8;
            --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 12px 32px rgba(0, 0, 0, 0.08);
            --radius: 20px;
            --radius-sm: 12px;
            --transition: 0.25s ease;
            --admin-accent: #7c3aed;
            --admin-accent-light: #ede9fe;
        }

        body {
            background: var(--bg);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1440px;
            margin: 0 auto;
            padding: 0 1.8rem;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            padding: 0.6rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 2px solid var(--admin-accent);
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.6rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            flex-shrink: 0;
        }
        .logo i { font-size: 2rem; }
        .logo span {
            font-weight: 300;
            color: var(--text-light);
            font-size: 0.85rem;
            margin-left: 0.1rem;
        }

        .nav-links {
            display: flex;
            gap: 0.8rem;
            align-items: center;
            flex-wrap: wrap;
            justify-content: center;
            flex: 1;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-mid);
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.3rem 0.8rem;
            border-bottom: 2.5px solid transparent;
            transition: var(--transition);
            cursor: pointer;
            white-space: nowrap;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }
        .nav-links a.admin-badge {
            background: var(--admin-accent-light);
            color: var(--admin-accent);
            border-radius: 30px;
            padding: 0.2rem 1rem 0.2rem 0.8rem;
            border-bottom: none;
            font-weight: 600;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }
        .nav-links a.admin-badge i { font-size: 0.7rem; }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            flex-shrink: 0;
        }

        .avatar {
            width: 36px;
            height: 36px;
            background: var(--admin-accent-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--admin-accent);
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-info .name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .user-info .role {
            font-size: 0.65rem;
            color: var(--admin-accent);
            font-weight: 500;
        }
        .logout-link {
            color: var(--text-light);
            font-size: 0.8rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.2rem;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }

        .admin-layout {
            display: grid;
            grid-template-columns: 240px 1fr;
            gap: 2rem;
            padding: 1.5rem 0 2.5rem;
            min-height: 70vh;
        }

        .admin-sidebar {
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            padding: 1.2rem 0.6rem;
            height: fit-content;
            position: sticky;
            top: 5.5rem;
        }
        .admin-sidebar .sidebar-title {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-light);
            padding: 0.4rem 1rem 0.6rem;
            font-weight: 600;
        }
        .admin-sidebar .menu-item {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.6rem 1rem;
            border-radius: var(--radius-sm);
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            font-size: 0.9rem;
            margin: 0.1rem 0;
        }
        .admin-sidebar .menu-item i {
            width: 1.4rem;
            text-align: center;
            font-size: 1rem;
            color: var(--text-light);
        }
        .admin-sidebar .menu-item:hover {
            background: var(--primary-bg);
            color: var(--primary);
        }
        .admin-sidebar .menu-item:hover i { color: var(--primary); }
        .admin-sidebar .menu-item.active {
            background: var(--primary-light);
            color: var(--primary);
            font-weight: 600;
        }
        .admin-sidebar .menu-item.active i { color: var(--primary); }
        .admin-sidebar .menu-item .badge {
            margin-left: auto;
            background: #fee2e2;
            color: #dc2626;
            font-size: 0.6rem;
            padding: 0.1rem 0.6rem;
            border-radius: 30px;
            font-weight: 600;
        }
        .admin-sidebar .menu-item .badge.success {
            background: #d1fae5;
            color: #059669;
        }
        .admin-sidebar .menu-item .badge.warning {
            background: #fef3c7;
            color: #d97706;
        }
        .admin-sidebar .divider {
            height: 1px;
            background: var(--border);
            margin: 0.6rem 1rem;
        }

        .admin-main {
            display: flex;
            flex-direction: column;
            gap: 1.8rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 1rem;
        }
        .stat-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.2rem 1.4rem;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
        }
        .stat-card .stat-label {
            font-size: 0.8rem;
            color: var(--text-light);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }
        .stat-card .stat-number {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--text-dark);
            line-height: 1.2;
            margin-top: 0.2rem;
        }
        .stat-card .stat-change {
            font-size: 0.7rem;
            color: #22c55e;
            background: #d1fae5;
            padding: 0.05rem 0.6rem;
            border-radius: 30px;
            display: inline-block;
            margin-top: 0.2rem;
        }
        .stat-card .stat-change.down {
            color: #ef4444;
            background: #fee2e2;
        }
        .stat-card .stat-icon {
            float: right;
            font-size: 2rem;
            color: var(--primary-light);
            opacity: 0.6;
        }
        .stat-card .stat-icon.purple {
            color: var(--admin-accent-light);
        }

        .admin-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        .admin-card .card-header {
            padding: 1.2rem 1.8rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.6rem;
        }
        .admin-card .card-header h3 {
            font-size: 1.05rem;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .admin-card .card-header h3 i { color: var(--primary); }
        .admin-card .card-header .actions {
            display: flex;
            gap: 0.6rem;
            align-items: center;
            flex-wrap: wrap;
        }
        .admin-card .card-header .actions .btn-sm {
            padding: 0.25rem 1rem;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 500;
            border: 1px solid var(--border);
            background: var(--bg);
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
        }
        .admin-card .card-header .actions .btn-sm:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--primary-light);
        }
        .admin-card .card-header .actions .btn-sm.primary {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }
        .admin-card .card-header .actions .btn-sm.primary:hover {
            background: var(--primary-hover);
        }
        .admin-card .card-body {
            padding: 1.2rem 1.8rem 1.8rem;
        }

        .search-bar {
            display: flex;
            gap: 0.8rem;
            align-items: center;
            margin-bottom: 1.2rem;
            flex-wrap: wrap;
        }
        .search-bar .search-input {
            display: flex;
            align-items: center;
            background: var(--bg);
            border-radius: 30px;
            padding: 0.2rem 1rem 0.2rem 1.2rem;
            border: 1px solid var(--border);
            transition: var(--transition);
            flex: 1;
            min-width: 180px;
        }
        .search-bar .search-input:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37,99,235,0.10);
            background: var(--card-bg);
        }
        .search-bar .search-input input {
            border: none;
            background: transparent;
            padding: 0.4rem 0.5rem;
            width: 100%;
            font-size: 0.9rem;
            outline: none;
            color: var(--text-dark);
        }
        .search-bar .search-input input::placeholder { color: var(--text-light); }
        .search-bar .search-input i { color: var(--text-light); font-size: 0.9rem; }
        .search-bar .btn-search {
            background: var(--primary);
            color: #fff;
            border: none;
            padding: 0.4rem 1.2rem;
            border-radius: 30px;
            font-weight: 500;
            font-size: 0.85rem;
            cursor: pointer;
            transition: var(--transition);
        }
        .search-bar .btn-search:hover {
            background: var(--primary-hover);
        }

        .content-list {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
        }
        .content-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.6rem 0.8rem;
            border-radius: var(--radius-sm);
            background: var(--bg);
            border: 1px solid var(--border);
            transition: var(--transition);
            flex-wrap: wrap;
        }
        .content-item:hover {
            border-color: var(--primary-light);
            background: var(--primary-bg);
        }
        .content-item .info {
            flex: 1;
            min-width: 150px;
        }
        .content-item .info .title {
            font-weight: 600;
            font-size: 0.92rem;
            color: var(--text-dark);
        }
        .content-item .info .meta {
            font-size: 0.78rem;
            color: var(--text-light);
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .content-item .info .meta i { margin-right: 0.2rem; }
        .content-item .badge-type {
            font-size: 0.6rem;
            padding: 0.1rem 0.6rem;
            border-radius: 30px;
            font-weight: 600;
            flex-shrink: 0;
        }
        .badge-project {
            background: #dbeafe;
            color: var(--primary);
        }
        .badge-course {
            background: #ede9fe;
            color: var(--admin-accent);
        }
        .status-badge {
            font-size: 0.6rem;
            padding: 0.1rem 0.6rem;
            border-radius: 30px;
            font-weight: 500;
        }
        .status-badge.published {
            background: #d1fae5;
            color: #059669;
        }
        .status-badge.pending {
            background: #fef3c7;
            color: #d97706;
        }
        .status-badge.draft {
            background: #e2e8f0;
            color: #64748b;
        }
        .content-item .actions {
            display: flex;
            gap: 0.4rem;
            flex-wrap: wrap;
        }
        .content-item .actions button {
            padding: 0.15rem 0.8rem;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: var(--transition);
        }
        .content-item .actions .btn-edit {
            background: var(--primary-light);
            color: var(--primary);
        }
        .content-item .actions .btn-edit:hover {
            background: var(--primary);
            color: #fff;
        }
        .content-item .actions .btn-delete {
            background: #fee2e2;
            color: #dc2626;
        }
        .content-item .actions .btn-delete:hover {
            background: #dc2626;
            color: #fff;
        }
        .content-item .actions .btn-publish {
            background: #d1fae5;
            color: #059669;
        }
        .content-item .actions .btn-publish:hover {
            background: #059669;
            color: #fff;
        }
        .content-item .actions .btn-unpublish {
            background: #fef3c7;
            color: #d97706;
        }
        .content-item .actions .btn-unpublish:hover {
            background: #d97706;
            color: #fff;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.4rem;
            margin-top: 1.5rem;
            flex-wrap: wrap;
        }
        .pagination span {
            padding: 0.3rem 0.8rem;
            border-radius: 8px;
            background: var(--card-bg);
            border: 1px solid var(--border);
            color: var(--text-mid);
            font-size: 0.85rem;
            cursor: pointer;
            transition: var(--transition);
            min-width: 32px;
            text-align: center;
        }
        .pagination span.active {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }
        .pagination span:hover:not(.active) {
            border-color: var(--primary);
            color: var(--primary);
        }
        .pagination span.disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        .toast-container {
            position: fixed;
            top: 5rem;
            right: 2rem;
            z-index: 300;
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg);
            padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
            border-left: 4px solid var(--primary);
            display: flex;
            align-items: center;
            gap: 0.8rem;
            animation: slideIn 0.35s ease;
            min-width: 260px;
            font-size: 0.9rem;
            color: var(--text-dark);
            border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast.error { border-left-color: #ef4444; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast.error .toast-icon { color: #ef4444; }
        .toast .toast-close {
            margin-left: auto;
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1.1rem;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .empty-state {
            text-align: center;
            padding: 3rem 0;
            color: var(--text-light);
        }
        .empty-state i {
            font-size: 3rem;
            display: block;
            margin-bottom: 0.5rem;
            color: var(--primary-light);
        }

        @media (max-width: 1024px) {
            .admin-layout { grid-template-columns: 1fr; }
            .admin-sidebar { position: static; display: flex; flex-wrap: wrap; gap: 0.2rem; padding: 0.8rem; }
            .admin-sidebar .sidebar-title { display: none; }
            .admin-sidebar .menu-item { padding: 0.4rem 0.8rem; font-size: 0.8rem; }
            .admin-sidebar .divider { display: none; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 0.6rem; }
            .stat-card .stat-number { font-size: 1.6rem; }
            .content-item { flex-direction: column; align-items: stretch; }
            .content-item .actions { justify-content: flex-end; }
            .search-bar { flex-direction: column; align-items: stretch; }
            .nav-links a { font-size: 0.8rem; padding: 0.2rem 0.5rem; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .stat-card .stat-number { font-size: 1.2rem; }
            .admin-card .card-header { flex-direction: column; align-items: stretch; }
            .admin-card .card-header .actions { justify-content: flex-start; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="container">
            <a href="admin.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· <?php echo $user['role'] === 'admin' ? '管理员' : '专家'; ?></span>
            </a>
            <div class="nav-links">
                <a href="admin.php">总控台</a>
                <a href="admin_pending.php">待审核</a>
                <a href="admin_content.php" class="active">内容管理</a>
                <a href="resources.php">资源库</a>
                <a class="admin-badge"><i class="fas fa-shield-alt"></i> <?php echo $user['role'] === 'admin' ? '管理 · 一级' : '专家'; ?></a>
            </div>
            <div class="nav-right">
                <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                <div class="user-info">
                    <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                    <span class="role"><i class="fas fa-<?php echo $user['role'] === 'admin' ? 'crown' : 'user-tie'; ?>"></i> <?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                </div>
                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
            </div>
        </div>
    </nav>

    <main class="container">
        <div class="admin-layout">

            <aside class="admin-sidebar">
                <div class="sidebar-title">导航</div>
                <div class="menu-item" onclick="location.href='admin.php'">
                    <i class="fas fa-gauge-high"></i> 总览
                </div>
                <div class="menu-item" onclick="location.href='admin_pending.php'">
                    <i class="fas fa-clock-rotate-left"></i> 待审核 
                    <span class="badge"><?php echo $stats['pending_projects']; ?></span>
                </div>
                <div class="menu-item active" onclick="location.href='admin_content.php'">
                    <i class="fas fa-box-archive"></i> 内容管理
                </div>
                <div class="menu-item" onclick="location.href='admin_users.php'">
                    <i class="fas fa-users"></i> 用户管理 <span class="badge success">+23</span>
                </div>
                <div class="divider"></div>
                <div class="menu-item" onclick="location.href='admin_reports.php'">
                    <i class="fas fa-chart-simple"></i> 数据报表
                </div>
                <div class="menu-item" onclick="location.href='admin_settings.php'">
                    <i class="fas fa-gear"></i> 系统设置
                </div>
                <div class="menu-item" onclick="location.href='admin_notifications.php'">
                    <i class="fas fa-bell"></i> 通知 <span class="badge warning">3</span>
                </div>
                <div class="divider"></div>
                <div class="menu-item" onclick="location.href='home.php'">
                    <i class="fas fa-arrow-left"></i> 返回前台
                </div>
            </aside>

            <div class="admin-main">

                <section class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-file-alt"></i></div>
                        <div class="stat-label"><i class="far fa-file"></i> 全部内容</div>
                        <div class="stat-number"><?php echo number_format($stats['projects'] + $stats['courses']); ?></div>
                        <span class="stat-change"><i class="fas fa-arrow-up"></i> +<?php echo $stats['projects']; ?></span>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon purple"><i class="fas fa-folder-open"></i></div>
                        <div class="stat-label"><i class="far fa-copy"></i> 项目</div>
                        <div class="stat-number"><?php echo number_format($stats['projects']); ?></div>
                        <span class="stat-change"><i class="fas fa-arrow-up"></i> +<?php echo $stats['published_projects']; ?></span>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-graduation-cap"></i></div>
                        <div class="stat-label"><i class="far fa-file-alt"></i> 课程</div>
                        <div class="stat-number"><?php echo number_format($stats['courses']); ?></div>
                        <span class="stat-change"><i class="fas fa-arrow-up"></i> +0</span>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon purple"><i class="fas fa-clock"></i></div>
                        <div class="stat-label"><i class="far fa-hourglass"></i> 待审核</div>
                        <div class="stat-number" style="color:#dc2626;"><?php echo number_format($stats['pending_projects']); ?></div>
                        <span class="stat-change down"><i class="fas fa-exclamation-triangle"></i> 需处理</span>
                    </div>
                </section>

                <div class="admin-card">
                    <div class="card-header">
                        <h3><i class="fas fa-list"></i> 内容列表</h3>
                        <div class="actions">
                            <button class="btn-sm active" data-type="all" onclick="filterType('all')">全部</button>
                            <button class="btn-sm" data-type="project" onclick="filterType('project')">项目</button>
                            <button class="btn-sm" data-type="course" onclick="filterType('course')">课程</button>
                            <button class="btn-sm primary" onclick="loadContents(1)"><i class="fas fa-sync"></i> 刷新</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="search-bar">
                            <div class="search-input">
                                <i class="fas fa-search"></i>
                                <input type="text" id="searchKeyword" placeholder="搜索标题、描述..." onkeydown="if(event.key==='Enter') loadContents(1)">
                            </div>
                            <button class="btn-search" onclick="loadContents(1)">搜索</button>
                        </div>

                        <div class="content-list" id="contentList">
                            <div class="empty-state">
                                <i class="fas fa-spinner fa-spin"></i>
                                <p>加载中...</p>
                            </div>
                        </div>

                        <div class="pagination" id="pagination"></div>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <div class="toast-container" id="toastContainer"></div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        let currentPage = 1;
        let totalPages = 1;
        let currentType = 'all';
        let currentKeyword = '';

        function showToast(message, type) {
            type = type || 'success';
            const container = document.getElementById('toastContainer');
            const icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
            const toast = document.createElement('div');
            toast.className = 'toast ' + type;
            toast.innerHTML =
                `<span class="toast-icon"><i class="fas ${icons[type] || icons.success}"></i></span>
                <span>${message}</span>
                <button class="toast-close">&times;</button>`;
            container.appendChild(toast);
            toast.querySelector('.toast-close').addEventListener('click', () => { toast.remove(); });
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(40px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        function loadContents(page) {
            page = page || currentPage;
            const keyword = document.getElementById('searchKeyword').value.trim();
            currentKeyword = keyword;

            const data = new FormData();
            data.append('action', 'get_contents');
            data.append('type', currentType);
            data.append('keyword', keyword);
            data.append('page', page);

            const list = document.getElementById('contentList');
            list.innerHTML = `<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>`;

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        renderContents(data.data.contents);
                        renderPagination(data.data.page, data.data.total_pages);
                        currentPage = data.data.page;
                        totalPages = data.data.total_pages;
                    } else {
                        showToast(data.message || '加载失败', 'error');
                    }
                })
                .catch(err => {
                    showToast('网络错误，请重试', 'error');
                    console.error(err);
                });
        }

        function renderContents(contents) {
            const list = document.getElementById('contentList');

            if (!contents || contents.length === 0) {
                list.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>暂无内容</p>
                    </div>
                `;
                return;
            }

            const typeMap = {
                'project': { label: '项目', cls: 'badge-project' },
                'course': { label: '课程', cls: 'badge-course' }
            };

            const statusMap = {
                '0': { label: '待审核', cls: 'status-badge pending' },
                '1': { label: '已发布', cls: 'status-badge published' },
                '2': { label: '已下架', cls: 'status-badge draft' }
            };

            list.innerHTML = contents.map(item => {
                const typeInfo = typeMap[item.type] || { label: item.type, cls: 'badge-project' };
                const statusInfo = statusMap[item.status] || { label: '未知', cls: 'status-badge draft' };
                const author = item.real_name || item.username || '未知';

                return `
                    <div class="content-item" data-id="${item.id}" data-type="${item.type}">
                        <span class="badge-type ${typeInfo.cls}">${typeInfo.label}</span>
                        <div class="info">
                            <div class="title">${escapeHtml(item.title)}</div>
                            <div class="meta">
                                <span><i class="far fa-user"></i> ${escapeHtml(author)}</span>
                                <span><i class="far fa-clock"></i> ${formatDate(item.created_at)}</span>
                                ${item.level ? `<span><i class="fas fa-tag"></i> ${escapeHtml(item.level)} · ${escapeHtml(item.subject || '')}</span>` : ''}
                                <span class="${statusInfo.cls}">${statusInfo.label}</span>
                            </div>
                        </div>
                        <div class="actions">
                            <button class="btn-edit" onclick="editContent(${item.id}, '${item.type}')"><i class="fas fa-edit"></i> 编辑</button>
                            ${item.status == 0 ? `<button class="btn-publish" onclick="publishContent(${item.id}, '${item.type}')"><i class="fas fa-check"></i> 发布</button>` : ''}
                            ${item.status == 1 ? `<button class="btn-unpublish" onclick="unpublishContent(${item.id}, '${item.type}')"><i class="fas fa-eye-slash"></i> 下架</button>` : ''}
                            <button class="btn-delete" onclick="deleteContent(${item.id}, '${item.type}')"><i class="fas fa-trash"></i> 删除</button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function renderPagination(page, total) {
            const container = document.getElementById('pagination');
            if (total <= 1) {
                container.innerHTML = '';
                return;
            }
            let html = '';
            html += `<span class="${page <= 1 ? 'disabled' : ''}" onclick="loadContents(${page - 1})"><i class="fas fa-chevron-left"></i></span>`;
            for (let i = 1; i <= total; i++) {
                html += `<span class="${i === page ? 'active' : ''}" onclick="loadContents(${i})">${i}</span>`;
            }
            html += `<span class="${page >= total ? 'disabled' : ''}" onclick="loadContents(${page + 1})"><i class="fas fa-chevron-right"></i></span>`;
            container.innerHTML = html;
        }

        function escapeHtml(str) {
            if (!str) return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        function formatDate(dateStr) {
            if (!dateStr) return '';
            const d = new Date(dateStr);
            return d.toLocaleDateString('zh-CN') + ' ' + d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
        }

        window.filterType = function(type) {
            currentType = type;
            document.querySelectorAll('.card-header .actions .btn-sm').forEach(btn => {
                btn.classList.remove('active');
                if (btn.dataset.type === type) {
                    btn.classList.add('active');
                }
            });
            loadContents(1);
        };

        window.publishContent = function(id, type) {
            if (!confirm('确定要发布这个内容吗？')) return;
            updateContentStatus(id, type, 1, '发布成功');
        };

        window.unpublishContent = function(id, type) {
            if (!confirm('确定要下架这个内容吗？')) return;
            updateContentStatus(id, type, 2, '已下架');
        };

        function updateContentStatus(id, type, status, successMsg) {
            const data = new FormData();
            data.append('action', 'update_status');
            data.append('id', id);
            data.append('type', type);
            data.append('status', status);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast('✅ ' + successMsg, 'success');
                        loadContents(currentPage);
                    } else {
                        showToast(data.message || '操作失败', 'error');
                    }
                })
                .catch(err => showToast('操作失败', 'error'));
        }

        window.editContent = function(id, type) {
            if (type === 'project') {
                window.location.href = 'resources.php?edit=' + id;
            } else {
                showToast('✏️ 编辑功能开发中...', 'warning');
            }
        };

        window.deleteContent = function(id, type) {
            if (!confirm('确定要删除这个内容吗？此操作不可恢复！')) return;

            const data = new FormData();
            data.append('action', 'delete_content');
            data.append('id', id);
            data.append('type', type);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast('✅ 删除成功', 'success');
                        loadContents(currentPage);
                    } else {
                        showToast(data.message || '删除失败', 'error');
                    }
                })
                .catch(err => showToast('删除失败', 'error'));
        };

        // ===== 侧栏菜单点击 =====
        document.querySelectorAll('.admin-sidebar .menu-item').forEach(item => {
            item.addEventListener('click', function() {
                const text = this.textContent.trim();
                if (text.includes('返回前台')) {
                    window.location.href = 'home.php';
                } else if (text.includes('总览')) {
                    window.location.href = 'admin.php';
                } else if (text.includes('待审核')) {
                    window.location.href = 'admin_pending.php';
                } else if (text.includes('内容管理')) {
                    window.location.href = 'admin_content.php';
                } else if (text.includes('资源库')) {
                    window.location.href = 'resources.php';
                }
            });
        });

        document.querySelector('.logout-link')?.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'logout.php';
        });

        loadContents(1);
    });
    </script>

</body>
</html>