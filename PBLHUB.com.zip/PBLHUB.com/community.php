<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 获取当前用户
$user = null;
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}

function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// ============================================================
// 处理 AJAX 请求
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 获取帖子列表 ----------
    if ($action === 'get_posts') {
        $filter = $_POST['filter'] ?? 'all';
        $keyword = sanitize($_POST['keyword'] ?? '');
        $page = intval($_POST['page'] ?? 1);
        $limit = 10;
        $offset = ($page - 1) * $limit;
        
        $where = "WHERE p.status = 1";
        if ($filter === 'hot') {
            $where .= " AND likes_count >= 10";
        } elseif ($filter === 'subject') {
            $where .= " AND subject != '' AND subject IS NOT NULL";
        } elseif ($filter === 'level') {
            $where .= " AND grade != '' AND grade IS NOT NULL";
        }
        if ($keyword) {
            $keyword = $conn->real_escape_string($keyword);
            $where .= " AND (title LIKE '%$keyword%' OR content LIKE '%$keyword%' OR summary LIKE '%$keyword%')";
        }
        
        $order = ($filter === 'latest') ? "ORDER BY created_at DESC" : "ORDER BY is_pinned DESC, likes_count DESC, created_at DESC";
        
        // 查询总数
        $countSql = "SELECT COUNT(*) as total FROM posts $where";
        $countResult = $conn->query($countSql);
        $total = $countResult ? $countResult->fetch_assoc()['total'] : 0;
        
        // 查询数据
        $sql = "SELECT p.*, u.username, u.real_name, u.avatar 
                FROM posts p 
                LEFT JOIN users u ON p.user_id = u.id 
                $where 
                $order 
                LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);
        $posts = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
            }
        }
        
        jsonResponse(true, '获取成功', [
            'posts' => $posts,
            'total' => intval($total),
            'page' => $page,
            'total_pages' => $total > 0 ? ceil($total / $limit) : 1
        ]);
    }
    
    // ---------- 获取单个帖子 ----------
    if ($action === 'get_post') {
        $post_id = intval($_POST['post_id'] ?? 0);
        if (!$post_id) jsonResponse(false, '帖子ID不能为空');
        
        $sql = "SELECT p.*, u.username, u.real_name, u.avatar 
                FROM posts p 
                LEFT JOIN users u ON p.user_id = u.id 
                WHERE p.post_id = $post_id";
        $result = $conn->query($sql);
        $post = $result ? $result->fetch_assoc() : null;
        
        if (!$post) jsonResponse(false, '帖子不存在');
        jsonResponse(true, '获取成功', ['post' => $post]);
    }
    
    // ---------- 获取评论列表 ----------
    if ($action === 'get_comments') {
        $post_id = intval($_POST['post_id'] ?? 0);
        if (!$post_id) jsonResponse(false, '帖子ID不能为空');
        
        $sql = "SELECT c.*, u.username, u.real_name, u.avatar 
                FROM comments c 
                LEFT JOIN users u ON c.user_id = u.id 
                WHERE c.target_type = 'post' AND c.target_id = $post_id AND c.parent_id IS NULL
                ORDER BY c.created_at ASC";
        $result = $conn->query($sql);
        $comments = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $comments[] = $row;
            }
        }
        jsonResponse(true, '获取成功', ['comments' => $comments]);
    }
    
    // ---------- 添加评论 ----------
    if ($action === 'add_comment') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $post_id = intval($_POST['post_id'] ?? 0);
        $content = sanitize($_POST['content'] ?? '');
        $parent_id = intval($_POST['parent_id'] ?? 0);
        
        if (!$post_id) jsonResponse(false, '帖子ID不能为空');
        if (empty($content)) jsonResponse(false, '请输入评论内容');
        
        $sql = "INSERT INTO comments (user_id, target_type, target_id, parent_id, content) 
                VALUES ({$user['id']}, 'post', $post_id, " . ($parent_id ? $parent_id : 'NULL') . ", '$content')";
        
        if ($conn->query($sql)) {
            $conn->query("UPDATE posts SET comments_count = comments_count + 1 WHERE post_id = $post_id");
            jsonResponse(true, '评论发布成功');
        } else {
            jsonResponse(false, '发布失败：' . $conn->error);
        }
    }
    
    // ---------- 点赞/取消点赞帖子 ----------
    if ($action === 'toggle_like') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $post_id = intval($_POST['post_id'] ?? 0);
        if (!$post_id) jsonResponse(false, '帖子ID不能为空');
        
        $checkSql = "SELECT id FROM likes WHERE user_id = {$user['id']} AND target_type = 'post' AND target_id = $post_id";
        $checkResult = $conn->query($checkSql);
        
        if ($checkResult && $checkResult->num_rows > 0) {
            $conn->query("DELETE FROM likes WHERE user_id = {$user['id']} AND target_type = 'post' AND target_id = $post_id");
            $conn->query("UPDATE posts SET likes_count = likes_count - 1 WHERE post_id = $post_id");
            jsonResponse(true, '已取消点赞', ['liked' => false]);
        } else {
            $conn->query("INSERT INTO likes (user_id, target_type, target_id) VALUES ({$user['id']}, 'post', $post_id)");
            $conn->query("UPDATE posts SET likes_count = likes_count + 1 WHERE post_id = $post_id");
            jsonResponse(true, '点赞成功', ['liked' => true]);
        }
    }
    
    // ---------- 点赞评论 ----------
    if ($action === 'like_comment') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $comment_id = intval($_POST['comment_id'] ?? 0);
        if (!$comment_id) jsonResponse(false, '评论ID不能为空');
        
        $checkSql = "SELECT id FROM likes WHERE user_id = {$user['id']} AND target_type = 'comment' AND target_id = $comment_id";
        $checkResult = $conn->query($checkSql);
        
        if ($checkResult && $checkResult->num_rows > 0) {
            $conn->query("DELETE FROM likes WHERE user_id = {$user['id']} AND target_type = 'comment' AND target_id = $comment_id");
            $conn->query("UPDATE comments SET likes_count = likes_count - 1 WHERE id = $comment_id");
            jsonResponse(true, '已取消点赞', ['likes_count' => 'decreased']);
        } else {
            $conn->query("INSERT INTO likes (user_id, target_type, target_id) VALUES ({$user['id']}, 'comment', $comment_id)");
            $conn->query("UPDATE comments SET likes_count = likes_count + 1 WHERE id = $comment_id");
            jsonResponse(true, '点赞成功', ['likes_count' => 'increased']);
        }
    }
    
    // ---------- 新增帖子 ----------
    if ($action === 'add_post') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $title = sanitize($_POST['title'] ?? '');
        $content = sanitize($_POST['content'] ?? '');
        $summary = mb_substr($content, 0, 120) . (mb_strlen($content) > 120 ? '...' : '');
        $subject = sanitize($_POST['subject'] ?? '');
        $grade = sanitize($_POST['grade'] ?? '');
        $tags = sanitize($_POST['tags'] ?? '');
        
        if (empty($title)) jsonResponse(false, '请输入标题');
        if (empty($content)) jsonResponse(false, '请输入内容');
        
        $sql = "INSERT INTO posts (user_id, title, content, summary, subject, grade, tags, created_at) 
                VALUES ({$user['id']}, '$title', '$content', '$summary', '$subject', '$grade', '$tags', NOW())";
        
        if ($conn->query($sql)) {
            jsonResponse(true, '帖子发布成功', ['id' => $conn->insert_id]);
        } else {
            jsonResponse(false, '发布失败：' . $conn->error);
        }
    }
    
    // ---------- 获取统计 ----------
    if ($action === 'get_stats') {
        $today = date('Y-m-d');
        $todayPosts = 0;
        $onlineCount = rand(800, 1500);
        
        $result = $conn->query("SELECT COUNT(*) as total FROM posts WHERE DATE(created_at) = '$today'");
        if ($result) {
            $row = $result->fetch_assoc();
            $todayPosts = intval($row['total'] ?? 0);
        }
        
        jsonResponse(true, '获取成功', [
            'today_posts' => $todayPosts,
            'online' => $onlineCount
        ]);
    }
    
    jsonResponse(false, '无效操作');
    exit;
}

// 获取统计数据
function getCommunityStats() {
    global $conn;
    $stats = [];
    
    $result = $conn->query("SELECT COUNT(*) as total FROM posts WHERE status = 1");
    $stats['total'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM posts WHERE likes_count >= 10 AND status = 1");
    $stats['hot'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM posts WHERE subject != '' AND subject IS NOT NULL AND status = 1");
    $stats['subject'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM posts WHERE grade != '' AND grade IS NOT NULL AND status = 1");
    $stats['level'] = $result ? $result->fetch_assoc()['total'] : 0;
    
    return $stats;
}

$stats = getCommunityStats();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 教师社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --primary-light: #dbeafe;
            --primary-bg: #f0f7ff;
            --bg: #f6f9fc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-mid: #475569;
            --text-light: #94a3b8;
            --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 12px 32px rgba(0, 0, 0, 0.08);
            --radius: 20px;
            --radius-sm: 12px;
            --transition: 0.25s ease;
        }

        body {
            background: var(--bg);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1360px;
            margin: 0 auto;
            padding: 0 1.8rem;
        }

        /* ===== 导航栏 ===== */
        .navbar {
            background: rgba(255, 255, 255, 0.90);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            padding: 0.6rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid var(--border);
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.6rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }
        .logo i { font-size: 2rem; }
        .logo span {
            font-weight: 300;
            color: var(--text-light);
            font-size: 0.85rem;
            margin-left: 0.1rem;
        }

        .nav-links {
            display: flex;
            gap: 1.8rem;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-mid);
            font-weight: 500;
            font-size: 1rem;
            padding: 0.3rem 0;
            border-bottom: 2.5px solid transparent;
            transition: var(--transition);
            cursor: pointer;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .avatar {
            width: 36px;
            height: 36px;
            background: var(--primary-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-info .name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .user-info .role {
            font-size: 0.65rem;
            color: var(--text-light);
        }
        .logout-link {
            color: var(--text-light);
            font-size: 0.8rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.2rem;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }
        .login-link {
            color: var(--primary);
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            padding: 0.4rem 1.2rem;
            border: 2px solid var(--primary);
            border-radius: 30px;
            transition: var(--transition);
        }
        .login-link:hover { background: var(--primary); color: #fff; }

        /* ===== 页面标题 ===== */
        .page-section {
            padding: 1.5rem 0 2.5rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .page-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .page-header h1 i { color: var(--primary); }
        .page-header .stats {
            font-size: 0.9rem;
            color: var(--text-light);
            background: var(--card-bg);
            padding: 0.3rem 1.2rem;
            border-radius: 30px;
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .page-header .stats span i { margin-right: 0.2rem; }

        /* ===== 社区布局 ===== */
        .community-layout {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 2rem;
        }

        /* ===== 分类标签 ===== */
        .community-tabs {
            display: flex;
            gap: 0.4rem;
            flex-wrap: wrap;
            margin-bottom: 1.2rem;
            background: var(--card-bg);
            padding: 0.4rem 0.8rem;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            align-items: center;
        }
        .community-tabs span {
            padding: 0.35rem 1.2rem;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 500;
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
            background: transparent;
        }
        .community-tabs span:hover {
            background: var(--primary-light);
            color: var(--primary);
        }
        .community-tabs span.active {
            background: var(--primary);
            color: #fff;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
        }
        .community-tabs span .count {
            font-weight: 400;
            font-size: 0.7rem;
            opacity: 0.7;
            margin-left: 0.2rem;
        }
        .community-tabs .search-wrapper {
            margin-left: auto;
            display: flex;
            align-items: center;
            background: var(--bg);
            border-radius: 30px;
            padding: 0.2rem 1rem 0.2rem 1.2rem;
            border: 1px solid var(--border);
            transition: var(--transition);
            min-width: 160px;
        }
        .community-tabs .search-wrapper:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.10);
            background: var(--card-bg);
        }
        .community-tabs .search-wrapper input {
            border: none;
            background: transparent;
            padding: 0.3rem 0.5rem;
            width: 100%;
            font-size: 0.85rem;
            outline: none;
            color: var(--text-dark);
        }
        .community-tabs .search-wrapper input::placeholder { color: var(--text-light); }
        .community-tabs .search-wrapper i { color: var(--text-light); font-size: 0.85rem; }

        /* ===== 帖子列表 ===== */
        .post-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .post-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.4rem 1.6rem;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }
        .post-card:hover {
            box-shadow: var(--shadow-hover);
            border-color: #bfdbfe;
        }

        .post-card .post-header {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-bottom: 0.4rem;
        }
        .post-card .post-header .post-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-light);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .post-card .post-header .post-author {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-dark);
        }
        .post-card .post-header .post-meta {
            font-size: 0.78rem;
            color: var(--text-light);
            display: flex;
            gap: 0.6rem;
            align-items: center;
        }
        .post-card .post-header .post-meta .dot { color: var(--text-light); }
        .post-card .post-header .post-badge {
            margin-left: auto;
            font-size: 0.6rem;
            font-weight: 600;
            padding: 0.1rem 0.7rem;
            border-radius: 30px;
        }
        .post-badge.hot { background: #fee2e2; color: #dc2626; }
        .post-badge.pick { background: #dbeafe; color: var(--primary); }
        .post-badge.new { background: #d1fae5; color: #059669; }
        .post-badge.pinned { background: #fef3c7; color: #d97706; }

        .post-card .post-title {
            font-size: 1.15rem;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 0.3rem;
            line-height: 1.4;
        }
        .post-card .post-title a {
            color: var(--text-dark);
            text-decoration: none;
            transition: var(--transition);
        }
        .post-card .post-title a:hover { color: var(--primary); }

        .post-card .post-summary {
            font-size: 0.9rem;
            color: var(--text-mid);
            margin-bottom: 0.6rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            line-height: 1.6;
        }

        .post-card .post-tags {
            display: flex;
            gap: 0.4rem;
            flex-wrap: wrap;
            margin-bottom: 0.6rem;
        }
        .post-card .post-tags span {
            background: var(--bg);
            color: var(--text-mid);
            font-size: 0.7rem;
            padding: 0.05rem 0.7rem;
            border-radius: 30px;
            border: 1px solid var(--border);
        }

        .post-card .post-footer {
            display: flex;
            gap: 1.5rem;
            align-items: center;
            padding-top: 0.5rem;
            border-top: 1px solid var(--border);
            font-size: 0.82rem;
            color: var(--text-light);
        }
        .post-card .post-footer span {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            cursor: pointer;
            transition: var(--transition);
            padding: 0.2rem 0.4rem;
            border-radius: 6px;
        }
        .post-card .post-footer span:hover {
            color: var(--primary);
            background: var(--primary-light);
        }
        .post-card .post-footer span .count { font-weight: 500; }
        .post-card .post-footer span.liked { color: #ef4444; }
        .post-card .post-footer span.liked i { font-weight: 900; }

        /* ===== 加载更多 ===== */
        .load-more {
            text-align: center;
            margin-top: 1.5rem;
            padding: 0.8rem;
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.9rem;
        }
        .load-more:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--primary-light);
        }

        /* ===== 侧边栏 ===== */
        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        .create-post-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.2rem 1.4rem;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            text-align: center;
        }
        .create-post-card .create-btn {
            width: 100%;
            background: var(--primary);
            color: #fff;
            border: none;
            padding: 0.7rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.95rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.2);
        }
        .create-post-card .create-btn:hover {
            background: var(--primary-hover);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.35);
            transform: translateY(-2px);
        }
        .create-post-card .hint {
            font-size: 0.78rem;
            color: var(--text-light);
            margin-top: 0.4rem;
        }

        .group-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.2rem 1.4rem;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }
        .group-card .group-title {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.4rem;
            margin-bottom: 0.6rem;
        }
        .group-card .group-title i { color: var(--primary); }
        .group-card .group-list {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
        }
        .group-card .group-item {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            padding: 0.4rem 0.6rem;
            border-radius: 8px;
            transition: var(--transition);
            cursor: pointer;
            font-size: 0.88rem;
            color: var(--text-mid);
        }
        .group-card .group-item:hover {
            background: var(--primary-light);
            color: var(--primary);
        }
        .group-card .group-item i {
            color: var(--primary);
            width: 1.2rem;
            text-align: center;
            font-size: 0.9rem;
        }
        .group-card .group-item .group-count {
            margin-left: auto;
            font-size: 0.7rem;
            color: var(--text-light);
            background: var(--bg);
            padding: 0.05rem 0.6rem;
            border-radius: 30px;
        }

        /* ===== 评论弹窗 ===== */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(6px);
            z-index: 200;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.25s ease;
        }
        .modal-overlay.show { display: flex; }

        .modal {
            background: var(--card-bg);
            border-radius: var(--radius);
            max-width: 700px;
            width: 92%;
            padding: 2rem 2.2rem 2.2rem;
            box-shadow: 0 24px 64px rgba(0, 0, 0, 0.16);
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px) scale(0.96); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        .modal .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.2rem;
        }
        .modal .modal-header h2 {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .modal .modal-header h2 i { color: var(--primary); }
        .modal .modal-header .close-btn {
            background: none;
            border: none;
            font-size: 1.6rem;
            color: var(--text-light);
            cursor: pointer;
            transition: var(--transition);
            padding: 0.2rem 0.5rem;
            border-radius: 8px;
        }
        .modal .modal-header .close-btn:hover {
            background: #f1f5f9;
            color: var(--text-dark);
        }

        .modal .form-group {
            margin-bottom: 1rem;
        }
        .modal .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
            margin-bottom: 0.3rem;
        }
        .modal .form-group label .required { color: #ef4444; margin-left: 0.2rem; }
        .modal .form-group input,
        .modal .form-group select,
        .modal .form-group textarea {
            width: 100%;
            padding: 0.6rem 1rem;
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: 0.95rem;
            transition: var(--transition);
            background: var(--bg);
            color: var(--text-dark);
            outline: none;
        }
        .modal .form-group input:focus,
        .modal .form-group select:focus,
        .modal .form-group textarea:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.10);
            background: var(--card-bg);
        }
        .modal .form-group textarea {
            resize: vertical;
            min-height: 60px;
        }

        .modal .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .modal .submit-row {
            display: flex;
            gap: 1rem;
            margin-top: 1.2rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border);
        }
        .modal .submit-row .btn-submit {
            background: var(--primary);
            color: #fff;
            border: none;
            padding: 0.6rem 2.4rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.95rem;
            cursor: pointer;
            transition: var(--transition);
            flex: 1;
        }
        .modal .submit-row .btn-submit:hover {
            background: var(--primary-hover);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.3);
        }
        .modal .submit-row .btn-cancel {
            background: transparent;
            color: var(--text-mid);
            border: 1.5px solid var(--border);
            padding: 0.6rem 2rem;
            border-radius: 40px;
            font-weight: 500;
            font-size: 0.95rem;
            cursor: pointer;
            transition: var(--transition);
        }
        .modal .submit-row .btn-cancel:hover {
            background: #f1f5f9;
            border-color: var(--text-light);
        }

        .comment-item {
            display: flex;
            gap: 0.8rem;
            padding: 0.8rem 0;
            border-bottom: 1px solid var(--border);
        }
        .comment-item:last-child {
            border-bottom: none;
        }
        .comment-item .c-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary-light);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.8rem;
            flex-shrink: 0;
        }
        .comment-item .c-body {
            flex: 1;
        }
        .comment-item .c-body .c-author {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .comment-item .c-body .c-time {
            font-size: 0.7rem;
            color: var(--text-light);
            margin-left: 0.6rem;
        }
        .comment-item .c-body .c-content {
            font-size: 0.92rem;
            color: var(--text-mid);
            margin-top: 0.2rem;
            line-height: 1.6;
        }
        .comment-item .c-body .c-actions {
            display: flex;
            gap: 0.8rem;
            margin-top: 0.3rem;
            font-size: 0.75rem;
            color: var(--text-light);
        }
        .comment-item .c-body .c-actions span {
            cursor: pointer;
            transition: var(--transition);
        }
        .comment-item .c-body .c-actions span:hover {
            color: var(--primary);
        }
        .comment-item .c-body .c-actions .liked {
            color: #ef4444;
        }

        /* ===== Toast ===== */
        .toast-container {
            position: fixed;
            top: 5rem;
            right: 2rem;
            z-index: 300;
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg);
            padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
            border-left: 4px solid var(--primary);
            display: flex;
            align-items: center;
            gap: 0.8rem;
            animation: slideIn 0.35s ease;
            min-width: 260px;
            font-size: 0.9rem;
            color: var(--text-dark);
            border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast .toast-close {
            margin-left: auto;
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1.1rem;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* ===== 底部 ===== */
        .footer {
            background: var(--card-bg);
            border-top: 1px solid var(--border);
            padding: 2rem 0;
            margin-top: 2rem;
        }
        .footer .container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1.5rem;
        }
        .footer .col {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
            font-size: 0.9rem;
            color: var(--text-mid);
        }
        .footer .col strong { color: var(--text-dark); font-weight: 600; }
        .footer .col i {
            margin-right: 0.4rem;
            color: var(--primary);
            width: 1.2rem;
            text-align: center;
        }
        .footer .col a {
            color: var(--text-mid);
            text-decoration: none;
            transition: var(--transition);
        }
        .footer .col a:hover { color: var(--primary); }
        .footer .bottom {
            text-align: center;
            margin-top: 1.2rem;
            font-size: 0.8rem;
            color: var(--text-light);
            border-top: 1px solid var(--border);
            padding-top: 1rem;
        }

        /* ===== 响应式 ===== */
        @media (max-width: 1024px) {
            .navbar .container { flex-direction: column; gap: 0.5rem; }
            .nav-links { justify-content: center; }
            .community-layout { grid-template-columns: 1fr; }
            .sidebar { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        }

        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .nav-right { width: 100%; justify-content: center; flex-wrap: wrap; }
            .page-header { flex-direction: column; align-items: stretch; gap: 0.6rem; }
            .page-header h1 { font-size: 1.4rem; }
            .page-header .stats { font-size: 0.75rem; padding: 0.3rem 0.8rem; flex-wrap: wrap; gap: 0.4rem; }
            .community-tabs { flex-wrap: wrap; padding: 0.4rem 0.6rem; gap: 0.3rem; }
            .community-tabs span { font-size: 0.75rem; padding: 0.25rem 0.8rem; }
            .community-tabs .search-wrapper { min-width: auto; width: 100%; margin-left: 0; margin-top: 0.3rem; }
            .sidebar { grid-template-columns: 1fr; }
            .post-card { padding: 1rem 1.2rem; }
            .post-card .post-title { font-size: 1rem; }
            .post-card .post-footer { gap: 1rem; font-size: 0.75rem; flex-wrap: wrap; }
            .modal { padding: 1.5rem; }
            .modal .form-row { grid-template-columns: 1fr; }
            .modal .submit-row { flex-direction: column; }
            .modal .submit-row .btn-submit,
            .modal .submit-row .btn-cancel { width: 100%; text-align: center; justify-content: center; }
            .toast-container { right: 1rem; left: 1rem; }
            .toast { min-width: auto; width: 100%; }
        }

        @media (max-width: 480px) {
            .nav-links { gap: 1rem; }
            .nav-links a { font-size: 0.85rem; }
            .avatar { width: 30px; height: 30px; font-size: 0.75rem; }
            .user-info .name { font-size: 0.8rem; }
            .user-info .role { font-size: 0.55rem; }
            .post-card .post-header .post-avatar { width: 32px; height: 32px; font-size: 0.75rem; }
            .post-card .post-footer span { padding: 0.1rem 0.3rem; }
        }
    </style>
</head>
<body>

    <!-- ===== 导航栏 ===== -->
    <nav class="navbar">
        <div class="container">
            <a href="home.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· 项目式学习中心</span>
            </a>
            <div class="nav-links">
                <a href="home.php">首页</a>
                <a href="resources.php">PBL资源库</a>
                <a href="courses.php">课程中心</a>
                <a href="community.php" class="active">教师社区</a>
                <a href="profile.php">个人中心</a>
            </div>
            <div class="nav-right">
                <?php if ($isLoggedIn && $user): ?>
                    <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                    <div class="user-info">
                        <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                        <span class="role"><?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                    </div>
                    <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="index.php" class="login-link"><i class="fas fa-sign-in-alt"></i> 登录</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- ===== 主容器 ===== -->
    <main class="container">

        <section class="page-section">

            <!-- ---- 页面标题 ---- -->
            <div class="page-header">
                <h1><i class="fas fa-comments"></i> 教师社区</h1>
                <div class="stats">
                    <span id="todayPosts"><i class="far fa-file-alt"></i> 今日 0 帖</span>
                    <span id="onlineUsers"><i class="far fa-user"></i> 0 在线</span>
                    <span><i class="far fa-clock"></i> 活跃</span>
                </div>
            </div>

            <!-- ---- 社区布局 ---- -->
            <div class="community-layout">

                <!-- ===== 左侧：帖子列表 ===== -->
                <div class="left-col">

                    <!-- 分类标签 -->
                    <div class="community-tabs">
                        <span class="active" data-filter="all">全部 <span class="count" id="countAll">(0)</span></span>
                        <span data-filter="latest">最新 <span class="count" id="countLatest">(0)</span></span>
                        <span data-filter="hot">热门 <span class="count" id="countHot">(0)</span></span>
                        <span data-filter="subject">学科 <span class="count" id="countSubject">(0)</span></span>
                        <span data-filter="level">学段 <span class="count" id="countLevel">(0)</span></span>
                        <div class="search-wrapper">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="搜索帖子..." id="searchKeyword" onkeydown="if(event.key==='Enter') loadPosts(1)">
                        </div>
                    </div>

                    <!-- 帖子列表 -->
                    <div class="post-list" id="postList">
                        <div style="text-align:center; padding:3rem; color:var(--text-light);">
                            <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
                            <p>加载中...</p>
                        </div>
                    </div>

                    <!-- 加载更多 -->
                    <div class="load-more" id="loadMoreBtn">
                        <i class="fas fa-chevron-down"></i> 加载更多
                    </div>

                </div>

                <!-- ===== 右侧边栏 ===== -->
                <div class="sidebar">

                    <!-- 创建帖子 -->
                    <div class="create-post-card">
                        <button class="create-btn" id="openPostModal">
                            <i class="fas fa-pen-fancy"></i> 发布帖子
                        </button>
                        <div class="hint">分享你的教学心得、案例或疑问</div>
                    </div>

                    <!-- 讨论群组 -->
                    <div class="group-card">
                        <div class="group-title"><i class="fas fa-users"></i> 讨论群组</div>
                        <div class="group-list">
                            <div class="group-item" onclick="showToast('初中PBL教研组（模拟）', 'warning')"><i class="fas fa-flask"></i> 初中PBL教研组 <span class="group-count">128</span></div>
                            <div class="group-item" onclick="showToast('小学科学联盟（模拟）', 'warning')"><i class="fas fa-leaf"></i> 小学科学联盟 <span class="group-count">96</span></div>
                            <div class="group-item" onclick="showToast('跨学科实践（模拟）', 'warning')"><i class="fas fa-globe"></i> 跨学科实践 <span class="group-count">74</span></div>
                            <div class="group-item" onclick="showToast('评价与量表（模拟）', 'warning')"><i class="fas fa-chart-bar"></i> 评价与量表 <span class="group-count">53</span></div>
                            <div class="group-item" onclick="showToast('AI + 教育（模拟）', 'warning')"><i class="fas fa-robot"></i> AI + 教育 <span class="group-count">41</span></div>
                            <div class="group-item" onclick="showToast('创建新群组（模拟）', 'warning')" style="color:var(--primary); font-weight:500;">
                                <i class="fas fa-plus-circle"></i> 创建新群组
                            </div>
                        </div>
                    </div>

                    <!-- 热门话题 -->
                    <div class="topic-card" style="background:var(--card-bg);border-radius:var(--radius);padding:1.2rem 1.4rem;border:1px solid var(--border);box-shadow:var(--shadow);">
                        <div class="topic-title" style="font-weight:600;font-size:0.95rem;color:var(--text-dark);display:flex;align-items:center;gap:0.4rem;margin-bottom:0.6rem;">
                            <i class="fas fa-fire" style="color:#f59e0b;"></i> 热门话题
                        </div>
                        <div class="topic-list" style="display:flex;flex-direction:column;gap:0.3rem;">
                            <div class="topic-item" style="display:flex;align-items:center;gap:0.5rem;padding:0.3rem 0.4rem;border-radius:6px;font-size:0.85rem;color:var(--text-mid);cursor:pointer;" onclick="searchTopic('驱动性问题')">
                                <span class="hash" style="color:var(--text-light);font-weight:300;">#</span> 如何设计驱动性问题 <span class="hot-icon" style="color:#f59e0b;font-size:0.65rem;margin-left:auto;"><i class="fas fa-fire"></i></span>
                            </div>
                            <div class="topic-item" style="display:flex;align-items:center;gap:0.5rem;padding:0.3rem 0.4rem;border-radius:6px;font-size:0.85rem;color:var(--text-mid);cursor:pointer;" onclick="searchTopic('评价量表')">
                                <span class="hash" style="color:var(--text-light);font-weight:300;">#</span> 跨学科评价量表 <span class="hot-icon" style="color:#f59e0b;font-size:0.65rem;margin-left:auto;opacity:0.7;"><i class="fas fa-fire"></i></span>
                            </div>
                            <div class="topic-item" style="display:flex;align-items:center;gap:0.5rem;padding:0.3rem 0.4rem;border-radius:6px;font-size:0.85rem;color:var(--text-mid);cursor:pointer;" onclick="searchTopic('课堂管理')">
                                <span class="hash" style="color:var(--text-light);font-weight:300;">#</span> PBL课堂管理技巧
                            </div>
                            <div class="topic-item" style="display:flex;align-items:center;gap:0.5rem;padding:0.3rem 0.4rem;border-radius:6px;font-size:0.85rem;color:var(--text-mid);cursor:pointer;" onclick="searchTopic('核心素养')">
                                <span class="hash" style="color:var(--text-light);font-weight:300;">#</span> 项目式学习与核心素养
                            </div>
                            <div class="topic-item" style="display:flex;align-items:center;gap:0.5rem;padding:0.3rem 0.4rem;border-radius:6px;font-size:0.85rem;color:var(--text-mid);cursor:pointer;" onclick="searchTopic('AI')">
                                <span class="hash" style="color:var(--text-light);font-weight:300;">#</span> AI赋能教学设计
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </section>

    </main>

    <!-- ===== 创建帖子弹窗 ===== -->
    <div class="modal-overlay" id="postModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-pen-fancy"></i> 发布帖子</h2>
                <button class="close-btn" id="closePostModalBtn">&times;</button>
            </div>
            <form id="postForm" onsubmit="return false;">
                <div class="form-group">
                    <label>标题 <span class="required">*</span></label>
                    <input type="text" id="postTitle" placeholder="例：如何设计跨学科驱动性问题？">
                </div>
                <div class="form-group">
                    <label>内容 <span class="required">*</span></label>
                    <textarea id="postContent" placeholder="分享你的观点、经验或问题..."></textarea>
                </div>
                <div class="form-group">
                    <label>标签（可选）</label>
                    <input type="text" id="postTags" placeholder="用逗号分隔，例：驱动性问题,跨学科,评价">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>学科</label>
                        <select id="postSubject">
                            <option value="">通用</option>
                            <option value="语文">语文</option>
                            <option value="数学">数学</option>
                            <option value="英语">英语</option>
                            <option value="科学">科学</option>
                            <option value="信息科技">信息科技</option>
                            <option value="艺术">艺术</option>
                            <option value="跨学科">跨学科</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>学段</label>
                        <select id="postGrade">
                            <option value="">通用</option>
                            <option value="小学">小学</option>
                            <option value="初中">初中</option>
                            <option value="高中">高中</option>
                        </select>
                    </div>
                </div>
                <div class="submit-row">
                    <button type="submit" class="btn-submit" id="submitPostBtn"><i class="fas fa-paper-plane"></i> 发布</button>
                    <button type="button" class="btn-cancel" id="cancelPostBtn">取消</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===== 评论弹窗 ===== -->
    <div class="modal-overlay" id="commentModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-comments" style="color:var(--primary);"></i> <span id="commentPostTitle">评论</span></h2>
                <button class="close-btn" id="closeCommentModalBtn">&times;</button>
            </div>
            <div id="commentList" style="max-height:350px; overflow-y:auto; margin-bottom:1rem;">
                <div style="text-align:center; padding:2rem; color:var(--text-light);">
                    <i class="fas fa-spinner fa-spin"></i> 加载评论中...
                </div>
            </div>
            <div style="border-top:1px solid var(--border); padding-top:1rem;">
                <div class="form-group" style="margin-bottom:0.5rem;">
                    <textarea id="commentContent" placeholder="写下你的评论..." style="width:100%; padding:0.6rem 1rem; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:0.95rem; background:var(--bg); color:var(--text-dark); outline:none; resize:vertical; min-height:60px; font-family:inherit;"></textarea>
                </div>
                <div style="display:flex; gap:0.8rem; justify-content:flex-end;">
                    <button class="btn-cancel" id="cancelCommentBtn" style="background:transparent; color:var(--text-mid); border:1.5px solid var(--border); padding:0.4rem 1.5rem; border-radius:40px; font-weight:500; font-size:0.9rem; cursor:pointer;">取消</button>
                    <button class="btn-submit" id="submitCommentBtn" style="background:var(--primary); color:#fff; border:none; padding:0.4rem 2rem; border-radius:40px; font-weight:600; font-size:0.9rem; cursor:pointer; transition:var(--transition);"><i class="fas fa-paper-plane"></i> 发布评论</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== Toast 容器 ===== -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- ===== 底部 ===== -->
    <footer class="footer">
        <div class="container">
            <div class="col">
                <strong>PBL HUB</strong>
                <span>项目式学习教师研修社区</span>
                <span><i class="fas fa-map-marker-alt"></i> 兰州市 · 教育创新中心</span>
            </div>
            <div class="col">
                <strong>关于我们</strong>
                <span><i class="fas fa-envelope"></i> contact@pblhub.edu</span>
                <span><i class="fas fa-users"></i> 成员：张老师、李老师、王老师</span>
                <span><i class="fas fa-info-circle"></i> 赋能教师PBL设计</span>
            </div>
            <div class="col">
                <strong>快速链接</strong>
                <a href="home.php"><i class="fas fa-home"></i> 首页</a>
                <a href="profile.php"><i class="fas fa-user"></i> 个人中心</a>
            </div>
        </div>
        <div class="bottom">
            © <?php echo date('Y'); ?> PBL HUB · 项目式学习中心
        </div>
    </footer>

    <!-- ============================================================ -->
    <!-- ======================== JavaScript =========================== -->
    <!-- ============================================================ -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        let currentPage = 1;
        let totalPages = 1;
        let currentFilter = 'all';
        let isLoadMore = false;
        let currentCommentPostId = null;

        // ============================================================
        // Toast 通知
        // ============================================================
        function showToast(message, type) {
            type = type || 'success';
            const container = document.getElementById('toastContainer');
            const icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle' };
            const toast = document.createElement('div');
            toast.className = 'toast ' + type;
            toast.innerHTML =
                `<span class="toast-icon"><i class="fas ${icons[type] || icons.success}"></i></span>
                <span>${message}</span>
                <button class="toast-close">&times;</button>`;
            container.appendChild(toast);
            toast.querySelector('.toast-close').addEventListener('click', () => { toast.remove(); });
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(40px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ============================================================
        // 加载统计数据
        // ============================================================
        function loadStats() {
            const data = new FormData();
            data.append('action', 'get_stats');

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('todayPosts').innerHTML = `<i class="far fa-file-alt"></i> 今日 ${data.data.today_posts} 帖`;
                        document.getElementById('onlineUsers').innerHTML = `<i class="far fa-user"></i> ${data.data.online} 在线`;
                    }
                })
                .catch(err => console.error('加载统计数据失败:', err));
        }

        // ============================================================
        // 加载帖子列表
        // ============================================================
        function loadPosts(page) {
            page = page || currentPage;
            const keyword = document.getElementById('searchKeyword').value.trim();

            const data = new FormData();
            data.append('action', 'get_posts');
            data.append('filter', currentFilter);
            data.append('keyword', keyword);
            data.append('page', page);

            const list = document.getElementById('postList');
            if (!isLoadMore) {
                list.innerHTML = `<div style="text-align:center;padding:3rem;color:var(--text-light);">
                    <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
                    <p>加载中...</p>
                </div>`;
            }

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        renderPosts(data.data.posts, page === 1);
                        totalPages = data.data.total_pages;
                        currentPage = data.data.page;
                        updateCounts(data.data.total);
                    } else {
                        showToast(data.message || '加载失败', 'warning');
                    }
                })
                .catch(err => {
                    showToast('网络错误，请重试', 'warning');
                    console.error(err);
                });
        }

        // ============================================================
        // 渲染帖子
        // ============================================================
        function renderPosts(posts, isFirstPage) {
            const list = document.getElementById('postList');

            if (!posts || posts.length === 0) {
                list.innerHTML = `
                    <div style="text-align:center;padding:3rem;color:var(--text-light);background:var(--card-bg);border-radius:var(--radius);border:1px solid var(--border);">
                        <i class="fas fa-inbox" style="font-size:2.5rem;display:block;margin-bottom:0.5rem;"></i>
                        <p>暂无帖子</p>
                        <p style="font-size:0.85rem;margin-top:0.3rem;">成为第一个发布帖子的人！</p>
                    </div>
                `;
                return;
            }

            if (isFirstPage) {
                list.innerHTML = '';
            }

            posts.forEach(p => {
                const avatar = p.real_name ? p.real_name[0] : (p.username ? p.username[0] : 'U');
                const authorName = p.real_name || p.username || '匿名用户';
                const time = p.created_at ? formatTime(p.created_at) : '未知时间';
                const tags = p.tags ? p.tags.split(',').map(t => t.trim()).filter(Boolean) : [];

                let badgeHtml = '';
                if (p.is_pinned) badgeHtml += `<span class="post-badge pinned">📌 置顶</span>`;
                if (p.is_pick) badgeHtml += `<span class="post-badge pick">精选</span>`;
                if (p.likes_count >= 10) badgeHtml += `<span class="post-badge hot">🔥 热门</span>`;

                const card = document.createElement('div');
                card.className = 'post-card';
                card.dataset.id = p.post_id;
                card.innerHTML = `
                    <div class="post-header">
                        <div class="post-avatar">${avatar}</div>
                        <span class="post-author">${escapeHtml(authorName)}</span>
                        <span class="post-meta">
                            <span>${time}</span>
                            <span class="dot">·</span>
                            <span>${escapeHtml(p.subject || '通用')} · ${escapeHtml(p.grade || '通用')}</span>
                        </span>
                        ${badgeHtml}
                    </div>
                    <div class="post-title"><a href="#">${escapeHtml(p.title)}</a></div>
                    <div class="post-summary">${escapeHtml(p.summary || p.content || '')}</div>
                    <div class="post-tags">
                        ${tags.map(t => `<span>${escapeHtml(t)}</span>`).join('')}
                    </div>
                    <div class="post-footer">
                        <span class="comment-btn" data-id="${p.post_id}">
                            <i class="far fa-comment"></i> <span class="count">${p.comments_count || 0}</span> 评论
                        </span>
                        <span class="like-btn" data-id="${p.post_id}">
                            <i class="far fa-heart"></i> <span class="count">${p.likes_count || 0}</span> 点赞
                        </span>
                        <span class="share-btn" data-id="${p.post_id}">
                            <i class="fas fa-retweet"></i> <span class="count">${p.shares_count || 0}</span> 转发
                        </span>
                    </div>
                `;
                list.appendChild(card);
            });

            // 绑定评论事件 - 打开评论弹窗
            document.querySelectorAll('.comment-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const postId = parseInt(this.dataset.id);
                    openCommentModal(postId);
                });
            });

            // 绑定点赞事件
            document.querySelectorAll('.like-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    toggleLike(parseInt(this.dataset.id), this);
                });
            });

            // 绑定转发事件
            document.querySelectorAll('.share-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const id = parseInt(this.dataset.id);
                    showToast('🔄 转发功能开发中...', 'warning');
                });
            });

            // 更新加载更多按钮
            const loadMoreBtn = document.getElementById('loadMoreBtn');
            if (currentPage >= totalPages) {
                loadMoreBtn.style.display = 'none';
            } else {
                loadMoreBtn.style.display = 'block';
                loadMoreBtn.innerHTML = `<i class="fas fa-chevron-down"></i> 加载更多`;
            }
        }

        // ============================================================
        // 点赞/取消点赞
        // ============================================================
        function toggleLike(postId, btnElement) {
            <?php if (!$isLoggedIn): ?>
                showToast('请先登录', 'warning');
                return;
            <?php endif; ?>

            const data = new FormData();
            data.append('action', 'toggle_like');
            data.append('post_id', postId);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // 更新按钮状态
                        const countSpan = btnElement.querySelector('.count');
                        let count = parseInt(countSpan.textContent) || 0;
                        const icon = btnElement.querySelector('i');
                        if (data.data.liked) {
                            count++;
                            icon.className = 'fas fa-heart';
                            btnElement.classList.add('liked');
                        } else {
                            count--;
                            icon.className = 'far fa-heart';
                            btnElement.classList.remove('liked');
                        }
                        countSpan.textContent = count;
                        showToast(data.message, 'success');
                    } else {
                        showToast(data.message || '操作失败', 'warning');
                    }
                })
                .catch(err => showToast('操作失败', 'warning'));
        }

        // ============================================================
        // 评论弹窗功能
        // ============================================================
        function openCommentModal(postId) {
            currentCommentPostId = postId;

            <?php if (!$isLoggedIn): ?>
                showToast('请先登录', 'warning');
                return;
            <?php endif; ?>

            document.getElementById('commentPostTitle').textContent = '加载中...';
            document.getElementById('commentModal').classList.add('show');
            document.body.style.overflow = 'hidden';

            // 加载评论
            const data = new FormData();
            data.append('action', 'get_comments');
            data.append('post_id', postId);

            const list = document.getElementById('commentList');
            list.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-light);">
                <i class="fas fa-spinner fa-spin"></i> 加载评论中...
            </div>`;

            // 先获取帖子标题
            const postData = new FormData();
            postData.append('action', 'get_post');
            postData.append('post_id', postId);

            fetch(window.location.href, { method: 'POST', body: postData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('commentPostTitle').textContent = '评论：' + data.data.post.title;
                    }
                })
                .catch(err => console.error(err));

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        renderComments(data.data.comments);
                    } else {
                        list.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-light);">
                            <i class="fas fa-inbox" style="font-size:2rem;display:block;margin-bottom:0.5rem;"></i>
                            <p>暂无评论</p>
                        </div>`;
                    }
                })
                .catch(err => {
                    list.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-light);">
                        <i class="fas fa-exclamation-circle" style="font-size:2rem;display:block;margin-bottom:0.5rem;color:#ef4444;"></i>
                        <p>加载失败</p>
                    </div>`;
                    console.error(err);
                });
        }

        function closeCommentModal() {
            document.getElementById('commentModal').classList.remove('show');
            document.body.style.overflow = '';
            document.getElementById('commentContent').value = '';
            currentCommentPostId = null;
        }

        function renderComments(comments) {
            const list = document.getElementById('commentList');
            if (!comments || comments.length === 0) {
                list.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-light);">
                    <i class="fas fa-inbox" style="font-size:2rem;display:block;margin-bottom:0.5rem;"></i>
                    <p>暂无评论，快来发表你的观点吧！</p>
                </div>`;
                return;
            }

            list.innerHTML = comments.map(c => {
                const authorName = c.real_name || c.username || '匿名用户';
                const avatar = authorName[0] || 'U';
                const time = c.created_at ? formatTime(c.created_at) : '未知';
                return `
                    <div class="comment-item">
                        <div class="c-avatar">${avatar}</div>
                        <div class="c-body">
                            <div>
                                <span class="c-author">${escapeHtml(authorName)}</span>
                                <span class="c-time">${time}</span>
                            </div>
                            <div class="c-content">${escapeHtml(c.content)}</div>
                            <div class="c-actions">
                                <span class="comment-like-btn" data-id="${c.id}" onclick="toggleCommentLike(${c.id}, this)">
                                    <i class="far fa-heart"></i> <span class="count">${c.likes_count || 0}</span> 赞
                                </span>
                                <span onclick="replyComment(${c.id})"><i class="far fa-comment"></i> 回复</span>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // ============================================================
        // 评论点赞
        // ============================================================
        function toggleCommentLike(commentId, btnElement) {
            <?php if (!$isLoggedIn): ?>
                showToast('请先登录', 'warning');
                return;
            <?php endif; ?>

            const data = new FormData();
            data.append('action', 'like_comment');
            data.append('comment_id', commentId);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const countSpan = btnElement.querySelector('.count');
                        let count = parseInt(countSpan.textContent) || 0;
                        const icon = btnElement.querySelector('i');
                        if (data.data.likes_count === 'increased') {
                            count++;
                            icon.className = 'fas fa-heart';
                            btnElement.classList.add('liked');
                        } else {
                            count--;
                            icon.className = 'far fa-heart';
                            btnElement.classList.remove('liked');
                        }
                        countSpan.textContent = count;
                        showToast(data.message, 'success');
                    } else {
                        showToast(data.message || '操作失败', 'warning');
                    }
                })
                .catch(err => showToast('操作失败', 'warning'));
        }

        // ============================================================
        // 回复评论
        // ============================================================
        function replyComment(commentId) {
            const content = document.getElementById('commentContent');
            content.focus();
            content.placeholder = '回复该评论...';
            content.dataset.parentId = commentId;
            showToast('💬 输入回复内容后点击发布', 'warning');
        }

        // ============================================================
        // 发布评论
        // ============================================================
        document.getElementById('submitCommentBtn').addEventListener('click', function() {
            <?php if (!$isLoggedIn): ?>
                showToast('请先登录', 'warning');
                return;
            <?php endif; ?>

            const content = document.getElementById('commentContent').value.trim();
            if (!content) {
                showToast('请输入评论内容', 'warning');
                return;
            }
            if (!currentCommentPostId) {
                showToast('帖子ID丢失，请重新打开', 'warning');
                return;
            }

            const parentId = parseInt(document.getElementById('commentContent').dataset.parentId) || 0;

            const data = new FormData();
            data.append('action', 'add_comment');
            data.append('post_id', currentCommentPostId);
            data.append('content', content);
            data.append('parent_id', parentId);

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 发布中...';

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-paper-plane"></i> 发布评论';
                    if (data.success) {
                        showToast('✅ 评论发布成功！', 'success');
                        document.getElementById('commentContent').value = '';
                        document.getElementById('commentContent').placeholder = '写下你的评论...';
                        document.getElementById('commentContent').dataset.parentId = '';
                        // 重新加载评论
                        const postId = currentCommentPostId;
                        const list = document.getElementById('commentList');
                        list.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-light);">
                            <i class="fas fa-spinner fa-spin"></i> 加载评论中...
                        </div>`;
                        const loadData = new FormData();
                        loadData.append('action', 'get_comments');
                        loadData.append('post_id', postId);
                        fetch(window.location.href, { method: 'POST', body: loadData })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    renderComments(data.data.comments);
                                }
                            });
                        // 更新帖子列表中的评论数
                        loadPosts(currentPage);
                    } else {
                        showToast(data.message || '发布失败', 'warning');
                    }
                })
                .catch(err => {
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-paper-plane"></i> 发布评论';
                    showToast('发布失败，请重试', 'warning');
                });
        });

        // ============================================================
        // 关闭评论弹窗
        // ============================================================
        document.getElementById('closeCommentModalBtn').addEventListener('click', closeCommentModal);
        document.getElementById('cancelCommentBtn').addEventListener('click', closeCommentModal);
        document.getElementById('commentModal').addEventListener('click', function(e) {
            if (e.target === this) closeCommentModal();
        });

        // ============================================================
        // 搜索话题
        // ============================================================
        function searchTopic(keyword) {
            document.getElementById('searchKeyword').value = keyword;
            loadPosts(1);
        }

        // ============================================================
        // 更新统计数字
        // ============================================================
        function updateCounts(total) {
            const counts = <?php echo json_encode($stats); ?>;
            document.getElementById('countAll').textContent = '(' + counts.total + ')';
            document.getElementById('countLatest').textContent = '(' + counts.total + ')';
            document.getElementById('countHot').textContent = '(' + counts.hot + ')';
            document.getElementById('countSubject').textContent = '(' + counts.subject + ')';
            document.getElementById('countLevel').textContent = '(' + counts.level + ')';
        }

        // ============================================================
        // 工具函数
        // ============================================================
        function escapeHtml(str) {
            if (!str) return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        function formatTime(dateStr) {
            const now = new Date();
            const past = new Date(dateStr);
            const diffMs = now - past;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);

            if (diffMins < 1) return '刚刚';
            if (diffMins < 60) return diffMins + '分钟前';
            if (diffHours < 24) return diffHours + '小时前';
            if (diffDays < 7) return diffDays + '天前';
            return past.toLocaleDateString('zh-CN');
        }

        // ============================================================
        // Modal 控制（发布帖子）
        // ============================================================
        const postModal = document.getElementById('postModal');
        const openPostBtn = document.getElementById('openPostModal');
        const closePostBtn = document.getElementById('closePostModalBtn');
        const cancelPostBtn = document.getElementById('cancelPostBtn');

        function openPostModalFn() {
            postModal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }

        function closePostModalFn() {
            postModal.classList.remove('show');
            document.body.style.overflow = '';
            document.getElementById('postForm').reset();
        }

        openPostBtn.addEventListener('click', openPostModalFn);
        closePostBtn.addEventListener('click', closePostModalFn);
        cancelPostBtn.addEventListener('click', closePostModalFn);
        postModal.addEventListener('click', function(e) {
            if (e.target === this) closePostModalFn();
        });

        // ============================================================
        // 发布帖子
        // ============================================================
        document.getElementById('submitPostBtn').addEventListener('click', function(e) {
            e.preventDefault();

            <?php if (!$isLoggedIn): ?>
                showToast('请先登录', 'warning');
                return;
            <?php endif; ?>

            const title = document.getElementById('postTitle').value.trim();
            const content = document.getElementById('postContent').value.trim();
            const tags = document.getElementById('postTags').value.trim();
            const subject = document.getElementById('postSubject').value;
            const grade = document.getElementById('postGrade').value;

            if (!title) { showToast('请输入标题', 'warning'); return; }
            if (!content) { showToast('请输入内容', 'warning'); return; }

            const data = new FormData();
            data.append('action', 'add_post');
            data.append('title', title);
            data.append('content', content);
            data.append('tags', tags);
            data.append('subject', subject);
            data.append('grade', grade);

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 发布中...';

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-paper-plane"></i> 发布';
                    if (data.success) {
                        showToast('✅ 帖子发布成功！', 'success');
                        closePostModalFn();
                        loadPosts(1);
                        loadStats();
                    } else {
                        showToast(data.message || '发布失败', 'warning');
                    }
                })
                .catch(err => {
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-paper-plane"></i> 发布';
                    showToast('发布失败，请重试', 'warning');
                });
        });

        // ============================================================
        // 分类切换
        // ============================================================
        document.querySelectorAll('.community-tabs span[data-filter]').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.community-tabs span[data-filter]').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                currentFilter = this.dataset.filter;
                loadPosts(1);
            });
        });

        // ============================================================
        // 加载更多
        // ============================================================
        document.getElementById('loadMoreBtn').addEventListener('click', function() {
            if (currentPage < totalPages) {
                isLoadMore = true;
                loadPosts(currentPage + 1);
                isLoadMore = false;
            }
        });

        // ============================================================
        // 初始化
        // ============================================================
        loadStats();
        loadPosts(1);
    });
    </script>

</body>
</html>