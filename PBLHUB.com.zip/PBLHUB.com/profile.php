<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 检查是否登录
requireLogin();

// 获取当前用户
$user = getCurrentUser();
if (!$user) {
    header('Location: index.php');
    exit;
}

function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

function getGenderText($gender) {
    $map = ['male' => '男', 'female' => '女', 'secret' => '保密'];
    return $map[$gender] ?? '保密';
}

// ============================================================
// 获取用户完整信息
// ============================================================
function getUserFullInfo($user_id) {
    global $conn;
    
    $sql = "SELECT u.*, e.nickname, e.birthday, e.province, e.city, e.education, 
                   e.teaching_years, e.research_direction, e.personal_intro
            FROM users u
            LEFT JOIN user_profile_extend e ON u.id = e.user_id
            WHERE u.id = $user_id";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

$userInfo = getUserFullInfo($user['id']);
if (!$userInfo) {
    $userInfo = $user;
}

// ============================================================
// 获取统计数据
// ============================================================
function getStats($user_id) {
    global $conn;
    $stats = ['courses' => 0, 'favorites' => 0, 'projects' => 0, 'activities' => 0, 'unread' => 0];
    
    $tableCheck1 = $conn->query("SHOW TABLES LIKE 'course_progress'");
    if ($tableCheck1 && $tableCheck1->num_rows > 0) {
        $result = $conn->query("SELECT COUNT(*) as total FROM course_progress WHERE user_id = $user_id");
        if ($result) $stats['courses'] = intval($result->fetch_assoc()['total'] ?? 0);
    }
    $tableCheck2 = $conn->query("SHOW TABLES LIKE 'course_favorites'");
    if ($tableCheck2 && $tableCheck2->num_rows > 0) {
        $result = $conn->query("SELECT COUNT(*) as total FROM course_favorites WHERE user_id = $user_id");
        if ($result) $stats['favorites'] = intval($result->fetch_assoc()['total'] ?? 0);
    }
    $tableCheck3 = $conn->query("SHOW TABLES LIKE 'activities'");
    if ($tableCheck3 && $tableCheck3->num_rows > 0) {
        $result = $conn->query("SELECT COUNT(*) as total FROM activities WHERE user_id = $user_id");
        if ($result) $stats['activities'] = intval($result->fetch_assoc()['total'] ?? 0);
    }
    $tableCheck4 = $conn->query("SHOW TABLES LIKE 'private_messages'");
    if ($tableCheck4 && $tableCheck4->num_rows > 0) {
        $result = $conn->query("SELECT COUNT(*) as total FROM private_messages WHERE receiver_id = $user_id AND is_read = 0");
        if ($result) $stats['unread'] = intval($result->fetch_assoc()['total'] ?? 0);
    }
    $result = $conn->query("SELECT COUNT(*) as total FROM projects WHERE author_id = $user_id");
    if ($result) $stats['projects'] = intval($result->fetch_assoc()['total'] ?? 0);
    return $stats;
}

$stats = getStats($user['id']);

// ============================================================
// 获取课程进度
// ============================================================
function getCourseProgress($user_id) {
    global $conn;
    $tableCheck = $conn->query("SHOW TABLES LIKE 'course_progress'");
    if (!$tableCheck || $tableCheck->num_rows === 0) return [];
    $sql = "SELECT cp.*, c.cTitle as course_title, c.instructor 
            FROM course_progress cp 
            LEFT JOIN courses c ON cp.course_id = c.cID
            WHERE cp.user_id = $user_id 
            ORDER BY cp.updated_at DESC";
    $result = $conn->query($sql);
    $progress = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $progress[] = $row;
        }
    }
    return $progress;
}
$courseProgress = getCourseProgress($user['id']);

// ============================================================
// 获取收藏
// ============================================================
function getFavorites($user_id) {
    global $conn;
    $tableCheck = $conn->query("SHOW TABLES LIKE 'course_favorites'");
    if (!$tableCheck || $tableCheck->num_rows === 0) return [];
    $sql = "SELECT cf.*, c.cTitle as course_title, c.instructor, c.level
            FROM course_favorites cf 
            LEFT JOIN courses c ON cf.course_id = c.cID
            WHERE cf.user_id = $user_id 
            ORDER BY cf.created_at DESC";
    $result = $conn->query($sql);
    $favorites = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $favorites[] = $row;
        }
    }
    return $favorites;
}
$favorites = getFavorites($user['id']);

// ============================================================
// 获取我的项目
// ============================================================
function getProjects($user_id) {
    global $conn;
    $sql = "SELECT p.*, u.username, u.real_name 
            FROM projects p 
            LEFT JOIN users u ON p.author_id = u.id
            WHERE p.author_id = $user_id 
            ORDER BY p.created_at DESC";
    $result = $conn->query($sql);
    $projects = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
    }
    return $projects;
}
$projects = getProjects($user['id']);

// ============================================================
// 获取动态
// ============================================================
function getActivities($user_id) {
    global $conn;
    $tableCheck = $conn->query("SHOW TABLES LIKE 'activities'");
    if (!$tableCheck || $tableCheck->num_rows === 0) return [];
    $sql = "SELECT * FROM activities 
            WHERE user_id = $user_id 
            ORDER BY created_at DESC 
            LIMIT 20";
    $result = $conn->query($sql);
    $activities = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $activities[] = $row;
        }
    }
    return $activities;
}
$activities = getActivities($user['id']);

// ============================================================
// 获取私信
// ============================================================
function getMessages($user_id) {
    global $conn;
    $tableCheck = $conn->query("SHOW TABLES LIKE 'private_messages'");
    if (!$tableCheck || $tableCheck->num_rows === 0) return ['messages' => [], 'unread' => 0];
    $sql = "SELECT pm.*, u.username, u.real_name 
            FROM private_messages pm 
            LEFT JOIN users u ON pm.sender_id = u.id
            WHERE pm.receiver_id = $user_id 
            ORDER BY pm.created_at DESC 
            LIMIT 20";
    $result = $conn->query($sql);
    $messages = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
    }
    $unreadResult = $conn->query("SELECT COUNT(*) as unread FROM private_messages WHERE receiver_id = $user_id AND is_read = 0");
    $unread = $unreadResult ? intval($unreadResult->fetch_assoc()['unread'] ?? 0) : 0;
    return ['messages' => $messages, 'unread' => $unread];
}
$msgResult = getMessages($user['id']);
$messages = $msgResult['messages'];
$unreadCount = $msgResult['unread'];

// ============================================================
// 工具函数
// ============================================================
function formatTime($dateStr) {
    if (!$dateStr) return '未知';
    $now = new DateTime();
    $past = new DateTime($dateStr);
    $diff = $now->diff($past);
    if ($diff->y > 0) return $diff->y . '年前';
    if ($diff->m > 0) return $diff->m . '个月前';
    if ($diff->d > 0) return $diff->d . '天前';
    if ($diff->h > 0) return $diff->h . '小时前';
    if ($diff->i > 0) return $diff->i . '分钟前';
    return '刚刚';
}

function formatDate($dateStr) {
    if (!$dateStr) return '未知';
    return date('Y-m-d', strtotime($dateStr));
}

// ============================================================
// 处理 AJAX 请求
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 更新个人信息 ----------
        // ---------- 更新个人信息 ----------
    if ($action === 'update_profile') {
        $real_name = sanitize($_POST['real_name'] ?? '');
        $school = sanitize($_POST['school'] ?? '');
        $subject = sanitize($_POST['subject'] ?? '');
        $bio = sanitize($_POST['bio'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $teaching_years = intval($_POST['teaching_years'] ?? 0);
        
        $sql = "UPDATE users SET 
                real_name = '$real_name',
                school = '$school',
                subject = '$subject',
                bio = '$bio',
                email = '$email',
                phone = '$phone'
                WHERE id = {$user['id']}";
        $conn->query($sql);
        
        // 更新 Session
        $_SESSION['real_name'] = $real_name;
        $_SESSION['school'] = $school;
        $_SESSION['subject'] = $subject;
        $_SESSION['bio'] = $bio;
        $_SESSION['email'] = $email;
        $_SESSION['phone'] = $phone;
        
        // 更新拓展表
        $tableCheck = $conn->query("SHOW TABLES LIKE 'user_profile_extend'");
        if ($tableCheck && $tableCheck->num_rows > 0) {
            $checkSql = "SELECT id FROM user_profile_extend WHERE user_id = {$user['id']}";
            $checkResult = $conn->query($checkSql);
            if ($checkResult && $checkResult->num_rows > 0) {
                $sql = "UPDATE user_profile_extend SET teaching_years = $teaching_years WHERE user_id = {$user['id']}";
            } else {
                $sql = "INSERT INTO user_profile_extend (user_id, teaching_years) VALUES ({$user['id']}, $teaching_years)";
            }
            $conn->query($sql);
        }
        jsonResponse(true, '个人信息更新成功');
        exit;
    }
    
    // ---------- 修改密码 ----------
    if ($action === 'change_password') {
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
            jsonResponse(false, '请填写完整信息');
        }
        if ($new_password !== $confirm_password) {
            jsonResponse(false, '两次输入的新密码不一致');
        }
        if (strlen($new_password) < 6) {
            jsonResponse(false, '新密码至少6位');
        }
        
        $sql = "SELECT password_hash FROM users WHERE id = {$user['id']}";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        if (!verifyPassword($old_password, $row['password_hash'])) {
            jsonResponse(false, '当前密码错误');
        }
        
        $new_hash = hashPassword($new_password);
        $sql = "UPDATE users SET password_hash = '$new_hash' WHERE id = {$user['id']}";
        if ($conn->query($sql)) {
            jsonResponse(true, '密码修改成功');
        } else {
            jsonResponse(false, '修改失败，请重试');
        }
        exit;
    }
    
    // ---------- 上传头像 ----------
    if ($action === 'upload_avatar') {
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            jsonResponse(false, '请选择头像文件');
        }
        $file = $_FILES['avatar'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowed_types)) {
            jsonResponse(false, '只支持 JPG、PNG、GIF、WEBP 格式');
        }
        if ($file['size'] > 2 * 1024 * 1024) {
            jsonResponse(false, '文件大小不能超过 2MB');
        }
        $upload_dir = __DIR__ . '/uploads/avatars/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'avatar_' . $user['id'] . '_' . time() . '.' . $ext;
        $filepath = $upload_dir . $filename;
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $avatar_url = '/uploads/avatars/' . $filename;
            $conn->query("UPDATE users SET avatar = '$avatar_url' WHERE id = {$user['id']}");
            $_SESSION['avatar'] = $avatar_url;
            jsonResponse(true, '头像上传成功', ['avatar' => $avatar_url]);
        } else {
            jsonResponse(false, '上传失败，请重试');
        }
        exit;
    }
    
    // ---------- 取消收藏 ----------
    if ($action === 'remove_favorite') {
        $course_id = intval($_POST['course_id'] ?? 0);
        if (!$course_id) jsonResponse(false, '课程ID不能为空');
        $sql = "DELETE FROM course_favorites WHERE user_id = {$user['id']} AND course_id = $course_id";
        if ($conn->query($sql)) {
            jsonResponse(true, '已取消收藏');
        } else {
            jsonResponse(false, '操作失败');
        }
        exit;
    }
    
    // ---------- 标记已读 ----------
    if ($action === 'mark_read') {
        $id = intval($_POST['id'] ?? 0);
        if ($id) {
            $conn->query("UPDATE private_messages SET is_read = 1 WHERE id = $id AND receiver_id = {$user['id']}");
        } else {
            $conn->query("UPDATE private_messages SET is_read = 1 WHERE receiver_id = {$user['id']}");
        }
        jsonResponse(true, '已标记已读');
        exit;
    }
    
    jsonResponse(false, '无效操作');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 个人中心</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; }
        :root {
            --primary: #2563eb; --primary-hover: #1d4ed8; --primary-light: #dbeafe;
            --bg: #f6f9fc; --card-bg: #ffffff; --text-dark: #0f172a;
            --text-mid: #475569; --text-light: #94a3b8; --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0,0,0,0.04); --shadow-hover: 0 12px 32px rgba(0,0,0,0.08);
            --radius: 20px; --radius-sm: 12px; --transition: 0.25s ease;
        }
        body { background: var(--bg); color: var(--text-dark); line-height: 1.6; min-height: 100vh; }
        .container { max-width: 1360px; margin: 0 auto; padding: 0 1.8rem; }

        .navbar {
            background: rgba(255,255,255,0.90); backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0,0,0,0.04); padding: 0.6rem 0;
            position: sticky; top: 0; z-index: 100; border-bottom: 1px solid var(--border);
        }
        .navbar .container {
            display: flex; align-items: center; justify-content: space-between;
            flex-wrap: wrap; gap: 0.6rem;
        }
        .logo {
            display: flex; align-items: center; gap: 0.5rem;
            font-size: 1.6rem; font-weight: 700; color: var(--primary);
            text-decoration: none; flex-shrink: 0;
        }
        .logo i { font-size: 2rem; }
        .logo span { font-weight: 300; color: var(--text-light); font-size: 0.85rem; }
        .nav-links {
            display: flex; gap: 1.8rem; align-items: center; flex-wrap: wrap;
            justify-content: center; flex: 1;
        }
        .nav-links a {
            text-decoration: none; color: var(--text-mid); font-weight: 500;
            font-size: 1rem; padding: 0.3rem 0;
            border-bottom: 2.5px solid transparent; transition: var(--transition);
            cursor: pointer;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active { color: var(--primary); border-bottom-color: var(--primary); }
        .nav-right {
            display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
        }
        .avatar {
            width: 36px; height: 36px; background: var(--primary-light);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--primary); font-weight: 600; font-size: 0.9rem; flex-shrink: 0;
        }
        .user-info { display: flex; flex-direction: column; line-height: 1.2; }
        .user-info .name { font-weight: 600; font-size: 0.9rem; color: var(--text-dark); }
        .user-info .role { font-size: 0.65rem; color: var(--text-light); }
        .logout-link {
            color: var(--text-light); font-size: 0.8rem; transition: var(--transition);
            display: flex; align-items: center; gap: 0.2rem; text-decoration: none;
            background: none; border: none; cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }
        .login-link {
            color: var(--primary); font-size: 0.9rem; font-weight: 600;
            text-decoration: none; padding: 0.4rem 1.2rem;
            border: 2px solid var(--primary); border-radius: 30px; transition: var(--transition);
        }
        .login-link:hover { background: var(--primary); color: #fff; }

        .notification-wrapper { position: relative; }
        .notification-btn {
            background: none; border: none; font-size: 1.2rem; color: var(--text-mid);
            cursor: pointer; position: relative; padding: 0.2rem 0.5rem;
            border-radius: 30px; transition: var(--transition);
        }
        .notification-btn:hover { background: var(--bg); color: var(--primary); }
        .notification-btn .badge {
            position: absolute; top: -6px; right: -6px; background: #ef4444;
            color: #fff; font-size: 0.6rem; font-weight: 700; padding: 0.1rem 0.4rem;
            border-radius: 50%; min-width: 18px; text-align: center; line-height: 1.2;
        }
        .notification-dropdown {
            display: none; position: absolute; top: 45px; right: 0;
            width: 360px; background: var(--card-bg); border-radius: var(--radius);
            box-shadow: var(--shadow-hover); border: 1px solid var(--border);
            z-index: 1000; padding: 0.5rem 0;
        }
        .notification-dropdown.show { display: block; animation: fadeIn 0.25s ease; }
        .notification-header {
            display: flex; justify-content: space-between; padding: 0.5rem 1rem;
            border-bottom: 1px solid var(--border); font-weight: 600; color: var(--text-dark);
        }
        .notification-header .mark-read {
            font-size: 0.75rem; font-weight: 400; color: var(--primary); cursor: pointer;
        }
        .notification-header .mark-read:hover { text-decoration: underline; }
        .notification-list { max-height: 320px; overflow-y: auto; }
        .notification-item {
            display: flex; align-items: center; gap: 0.8rem; padding: 0.6rem 1rem;
            border-bottom: 1px solid var(--border); transition: var(--transition);
        }
        .notification-item:last-child { border-bottom: none; }
        .notification-item:hover { background: var(--bg); }
        .notification-item .notif-avatar {
            width: 32px; height: 32px; border-radius: 50%; background: var(--primary-light);
            flex-shrink: 0; display: flex; align-items: center; justify-content: center;
            color: var(--primary); font-weight: 600; font-size: 0.8rem;
        }
        .notification-item .notif-content { flex: 1; display: flex; flex-direction: column; }
        .notification-item .notif-text { font-size: 0.85rem; color: var(--text-mid); }
        .notification-item .notif-text strong { color: var(--text-dark); }
        .notification-item .notif-time { font-size: 0.65rem; color: var(--text-light); }

        .page-section { padding: 1.5rem 0 2.5rem; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .profile-layout {
            display: grid; grid-template-columns: 260px 1fr; gap: 1.8rem;
            background: var(--card-bg); border-radius: var(--radius);
            border: 1px solid var(--border); overflow: hidden;
            box-shadow: var(--shadow); min-height: 600px;
        }

        .profile-sidebar {
            background: var(--bg); padding: 1.8rem 1.2rem 1.5rem;
            border-right: 1px solid var(--border); display: flex; flex-direction: column;
            gap: 0.6rem;
        }
        .profile-sidebar .user-avatar {
            text-align: center; padding-bottom: 1rem;
            border-bottom: 1px solid var(--border); margin-bottom: 0.6rem;
        }
        .profile-sidebar .user-avatar .avatar-big {
            width: 80px; height: 80px; background: var(--primary-light);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 2.6rem; color: var(--primary); margin: 0 auto 0.5rem;
            border: 3px solid #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.06);
            overflow: hidden;
        }
        .profile-sidebar .user-avatar .avatar-big img {
            width: 100%; height: 100%; object-fit: cover;
        }
        .profile-sidebar .user-avatar .uname { font-weight: 700; font-size: 1.1rem; color: var(--text-dark); }
        .profile-sidebar .user-avatar .urole { font-size: 0.8rem; color: var(--text-light); }

        .profile-sidebar .menu-item {
            display: flex; align-items: center; gap: 0.7rem; padding: 0.6rem 0.9rem;
            border-radius: var(--radius-sm); color: var(--text-mid); font-weight: 500;
            font-size: 0.9rem; cursor: pointer; transition: var(--transition);
            border: none; background: transparent; width: 100%; text-align: left;
        }
        .profile-sidebar .menu-item i { width: 1.4rem; font-size: 1rem; color: var(--text-light); transition: var(--transition); }
        .profile-sidebar .menu-item:hover { background: var(--primary-light); color: var(--primary); }
        .profile-sidebar .menu-item:hover i { color: var(--primary); }
        .profile-sidebar .menu-item.active { background: var(--primary-light); color: var(--primary); font-weight: 600; }
        .profile-sidebar .menu-item.active i { color: var(--primary); }
        .profile-sidebar .menu-divider { height: 1px; background: var(--border); margin: 0.3rem 0; }
        .profile-sidebar .menu-item.danger { color: #dc2626; }
        .profile-sidebar .menu-item.danger i { color: #dc2626; }
        .profile-sidebar .menu-item.danger:hover { background: #fee2e2; color: #b91c1c; }
        .profile-sidebar .menu-item.danger:hover i { color: #b91c1c; }

        .profile-content { padding: 1.8rem 2rem 2rem; overflow-y: auto; }
        .profile-content .panel { display: none; animation: fadeIn 0.3s ease; }
        .profile-content .panel.active { display: block; }
        .profile-content .panel-title {
            font-size: 1.3rem; font-weight: 700; color: var(--text-dark);
            margin-bottom: 1.2rem; display: flex; align-items: center; gap: 0.6rem;
        }
        .profile-content .panel-title i { color: var(--primary); }
        .profile-content .panel-title .badge-count {
            background: var(--primary-light); color: var(--primary);
            font-size: 0.7rem; font-weight: 600; padding: 0.1rem 0.7rem;
            border-radius: 30px; margin-left: 0.3rem;
        }

        .info-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem 2rem;
            background: var(--bg); border-radius: var(--radius-sm);
            padding: 1.5rem 1.8rem; border: 1px solid var(--border);
        }
        .info-grid .item { display: flex; flex-direction: column; gap: 0.1rem; }
        .info-grid .item .label { font-size: 0.75rem; color: var(--text-light); font-weight: 500; text-transform: uppercase; letter-spacing: 0.3px; }
        .info-grid .item .value { font-size: 1rem; font-weight: 500; color: var(--text-dark); }
        .info-grid .item .value .edit-hint {
            font-weight: 400; font-size: 0.8rem; color: var(--text-light);
            cursor: pointer; transition: var(--transition);
        }
        .info-grid .item .value .edit-hint:hover { color: var(--primary); }

        .record-list { display: flex; flex-direction: column; gap: 0.8rem; }
        .record-item {
            background: var(--bg); border-radius: var(--radius-sm); padding: 0.8rem 1.2rem;
            border: 1px solid var(--border); display: flex; align-items: center;
            gap: 1rem; flex-wrap: wrap; transition: var(--transition);
        }
        .record-item:hover { border-color: #bfdbfe; }
        .record-item .info { flex: 1; min-width: 150px; }
        .record-item .info .title { font-weight: 600; font-size: 0.95rem; color: var(--text-dark); }
        .record-item .info .meta { font-size: 0.8rem; color: var(--text-light); display: flex; gap: 0.8rem; flex-wrap: wrap; }
        .record-item .progress-wrap { display: flex; align-items: center; gap: 0.8rem; min-width: 140px; }
        .record-item .progress-wrap .bar { width: 100px; height: 6px; background: #e2e8f0; border-radius: 10px; overflow: hidden; flex-shrink: 0; }
        .record-item .progress-wrap .bar .fill { height: 100%; background: var(--primary); border-radius: 10px; transition: width 0.6s ease; }
        .record-item .progress-wrap .pct { font-size: 0.8rem; font-weight: 600; color: var(--primary); min-width: 40px; text-align: right; }
        .record-item .continue-btn {
            background: var(--primary); color: #fff; border: none;
            padding: 0.2rem 1.2rem; border-radius: 30px; font-size: 0.8rem;
            cursor: pointer; transition: var(--transition);
        }
        .record-item .continue-btn:hover { background: var(--primary-hover); }

        .fav-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
        .fav-item {
            background: var(--bg); border-radius: var(--radius-sm); padding: 0.8rem 1rem;
            border: 1px solid var(--border); transition: var(--transition);
            display: flex; flex-direction: column; gap: 0.3rem;
        }
        .fav-item:hover { border-color: #bfdbfe; transform: translateY(-2px); }
        .fav-item .fav-title { font-weight: 600; font-size: 0.95rem; color: var(--text-dark); }
        .fav-item .fav-meta { font-size: 0.8rem; color: var(--text-light); display: flex; gap: 0.6rem; flex-wrap: wrap; }
        .fav-item .fav-actions { display: flex; gap: 0.6rem; margin-top: 0.2rem; }
        .fav-item .fav-actions button {
            background: transparent; border: none; font-size: 0.75rem;
            color: var(--text-light); cursor: pointer; transition: var(--transition);
            padding: 0.1rem 0.4rem;
        }
        .fav-item .fav-actions button:hover { color: var(--primary); }
        .fav-item .fav-actions button.danger:hover { color: #dc2626; }

        .project-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1rem; }
        .project-item {
            background: var(--bg); border-radius: var(--radius-sm); padding: 0.8rem 1rem;
            border: 1px solid var(--border); transition: var(--transition);
        }
        .project-item:hover { border-color: #bfdbfe; transform: translateY(-2px); }
        .project-item .proj-title { font-weight: 600; font-size: 0.95rem; color: var(--text-dark); }
        .project-item .proj-meta { font-size: 0.8rem; color: var(--text-light); display: flex; gap: 0.6rem; flex-wrap: wrap; }
        .project-item .proj-status {
            font-size: 0.7rem; font-weight: 500; padding: 0.05rem 0.7rem;
            border-radius: 30px; display: inline-block; margin-top: 0.2rem;
        }
        .project-item .proj-status.draft { background: #fef3c7; color: #b45309; }
        .project-item .proj-status.published { background: #d1fae5; color: #059669; }
        .project-item .proj-status.archived { background: #e2e8f0; color: #64748b; }
        .project-item .proj-actions { display: flex; gap: 0.6rem; margin-top: 0.3rem; }
        .project-item .proj-actions button {
            background: transparent; border: none; font-size: 0.75rem;
            color: var(--text-light); cursor: pointer; transition: var(--transition);
            padding: 0.1rem 0.4rem;
        }
        .project-item .proj-actions button:hover { color: var(--primary); }

        .account-section {
            background: var(--bg); border-radius: var(--radius-sm);
            padding: 1.5rem 1.8rem; border: 1px solid var(--border);
            display: flex; flex-direction: column; gap: 1.2rem;
        }
        .account-section .row {
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 0.6rem; padding-bottom: 0.8rem;
            border-bottom: 1px solid var(--border);
        }
        .account-section .row:last-child { border-bottom: none; padding-bottom: 0; }
        .account-section .row .label { font-weight: 500; color: var(--text-dark); }
        .account-section .row .label i { margin-right: 0.5rem; color: var(--text-light); }
        .account-section .row .value { color: var(--text-mid); font-size: 0.95rem; }
        .account-section .row .action-btn {
            background: var(--primary-light); color: var(--primary); border: none;
            padding: 0.2rem 1.2rem; border-radius: 30px; font-size: 0.8rem;
            cursor: pointer; transition: var(--transition);
        }
        .account-section .row .action-btn:hover { background: var(--primary); color: #fff; }
        .account-section .row .action-btn.danger { background: #fee2e2; color: #dc2626; }
        .account-section .row .action-btn.danger:hover { background: #dc2626; color: #fff; }

        .activity-list { display: flex; flex-direction: column; gap: 0.75rem; }
        .activity-item {
            background: var(--bg); border-radius: var(--radius-sm); padding: 0.7rem 1.2rem;
            border-left: 4px solid var(--primary); border: 1px solid var(--border);
            border-left-width: 4px; transition: var(--transition);
            display: flex; align-items: center; gap: 0.8rem; flex-wrap: wrap;
        }
        .activity-item:hover { border-color: #bfdbfe; }
        .activity-item .act-icon {
            width: 32px; height: 32px; border-radius: 50%; background: var(--primary-light);
            display: flex; align-items: center; justify-content: center; color: var(--primary); flex-shrink: 0;
        }
        .activity-item .act-content { flex: 1; min-width: 160px; }
        .activity-item .act-content .act-text { font-size: 0.92rem; color: var(--text-dark); }
        .activity-item .act-content .act-text strong { color: var(--primary); }
        .activity-item .act-content .act-meta { font-size: 0.75rem; color: var(--text-light); display: flex; gap: 0.8rem; flex-wrap: wrap; margin-top: 0.1rem; }
        .activity-item .act-time { font-size: 0.75rem; color: var(--text-light); white-space: nowrap; }

        .empty-state-sm { text-align: center; padding: 2rem 0; color: var(--text-light); }
        .empty-state-sm i { font-size: 2.5rem; display: block; margin-bottom: 0.4rem; color: var(--border); }
        .empty-state-sm h4 { font-weight: 500; color: var(--text-mid); }

        .modal-overlay {
            display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.5);
            backdrop-filter: blur(6px); z-index: 200; align-items: center;
            justify-content: center; padding: 1.5rem;
        }
        .modal-overlay.show { display: flex; }
        .modal {
            background: var(--card-bg); border-radius: var(--radius);
            max-width: 600px; width: 92%; padding: 2rem 2.2rem;
            box-shadow: 0 24px 64px rgba(0,0,0,0.16); max-height: 90vh; overflow-y: auto;
            animation: slideUp 0.3s ease;
        }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px) scale(0.96); } to { opacity: 1; transform: translateY(0) scale(1); } }
        .modal .modal-header {
            display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;
        }
        .modal .modal-header h2 { font-size: 1.3rem; font-weight: 700; color: var(--text-dark); display: flex; align-items: center; gap: 0.6rem; }
        .modal .modal-header h2 i { color: var(--primary); }
        .modal .modal-header .close-btn {
            background: none; border: none; font-size: 1.6rem; color: var(--text-light);
            cursor: pointer; transition: var(--transition); padding: 0.2rem 0.5rem; border-radius: 8px;
        }
        .modal .modal-header .close-btn:hover { background: #f1f5f9; color: var(--text-dark); }
        .modal .form-group { margin-bottom: 1rem; }
        .modal .form-group label { display: block; font-weight: 600; font-size: 0.9rem; color: var(--text-dark); margin-bottom: 0.3rem; }
        .modal .form-group label .required { color: #ef4444; margin-left: 0.2rem; }
        .modal .form-group input, .modal .form-group select, .modal .form-group textarea {
            width: 100%; padding: 0.6rem 1rem; border: 1.5px solid var(--border);
            border-radius: var(--radius-sm); font-size: 0.95rem; transition: var(--transition);
            background: var(--bg); color: var(--text-dark); outline: none;
        }
        .modal .form-group input:focus, .modal .form-group select:focus, .modal .form-group textarea:focus {
            border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37,99,235,0.10); background: var(--card-bg);
        }
        .modal .form-group textarea { resize: vertical; min-height: 80px; }
        .modal .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .modal .submit-row {
            display: flex; gap: 1rem; margin-top: 1.2rem; padding-top: 1rem; border-top: 1px solid var(--border);
        }
        .modal .submit-row .btn-submit {
            background: var(--primary); color: #fff; border: none;
            padding: 0.6rem 2.4rem; border-radius: 40px; font-weight: 600; font-size: 0.95rem;
            cursor: pointer; transition: var(--transition); flex: 1;
        }
        .modal .submit-row .btn-submit:hover { background: var(--primary-hover); box-shadow: 0 6px 20px rgba(37,99,235,0.3); }
        .modal .submit-row .btn-cancel {
            background: transparent; color: var(--text-mid); border: 1.5px solid var(--border);
            padding: 0.6rem 2rem; border-radius: 40px; font-weight: 500; font-size: 0.95rem;
            cursor: pointer; transition: var(--transition);
        }
        .modal .submit-row .btn-cancel:hover { background: #f1f5f9; border-color: var(--text-light); }

        .footer {
            background: var(--card-bg); border-top: 1px solid var(--border);
            padding: 2rem 0; margin-top: 2rem;
        }
        .footer .container {
            display: flex; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem;
        }
        .footer .col {
            display: flex; flex-direction: column; gap: 0.3rem;
            font-size: 0.9rem; color: var(--text-mid);
        }
        .footer .col strong { color: var(--text-dark); font-weight: 600; }
        .footer .col i { margin-right: 0.4rem; color: var(--primary); width: 1.2rem; text-align: center; }
        .footer .col a { color: var(--text-mid); text-decoration: none; transition: var(--transition); cursor: pointer; }
        .footer .col a:hover { color: var(--primary); }
        .footer .bottom {
            text-align: center; margin-top: 1.2rem; font-size: 0.8rem;
            color: var(--text-light); border-top: 1px solid var(--border); padding-top: 1rem;
        }

        .toast-container {
            position: fixed; top: 5rem; right: 2rem; z-index: 300;
            display: flex; flex-direction: column; gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg); padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm); box-shadow: 0 12px 32px rgba(0,0,0,0.12);
            border-left: 4px solid var(--primary); display: flex; align-items: center;
            gap: 0.8rem; animation: slideIn 0.35s ease; min-width: 260px;
            font-size: 0.9rem; color: var(--text-dark); border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast.error { border-left-color: #ef4444; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast.error .toast-icon { color: #ef4444; }
        .toast .toast-close {
            margin-left: auto; background: none; border: none;
            color: var(--text-light); cursor: pointer; font-size: 1.1rem;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 1024px) {
            .navbar .container { flex-direction: column; gap: 0.5rem; }
            .nav-links { justify-content: center; }
            .profile-layout { grid-template-columns: 1fr; grid-template-rows: auto 1fr; }
            .profile-sidebar {
                border-right: none; border-bottom: 1px solid var(--border);
                flex-direction: row; flex-wrap: wrap; padding: 1rem 1.2rem; gap: 0.3rem;
            }
            .profile-sidebar .user-avatar { display: none; }
            .profile-sidebar .menu-item { padding: 0.4rem 0.8rem; font-size: 0.85rem; width: auto; }
            .profile-sidebar .menu-divider { display: none; }
            .profile-content { padding: 1.2rem; }
            .info-grid { grid-template-columns: 1fr; gap: 0.8rem; }
            .notification-dropdown { width: 320px; right: -20px; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .nav-right { width: 100%; justify-content: center; flex-wrap: wrap; }
            .fav-grid, .project-grid { grid-template-columns: 1fr 1fr; gap: 0.8rem; }
            .record-item { flex-direction: column; align-items: stretch; gap: 0.4rem; }
            .record-item .progress-wrap { min-width: auto; justify-content: space-between; }
            .record-item .progress-wrap .bar { flex: 1; }
            .account-section .row { flex-direction: column; align-items: flex-start; gap: 0.3rem; }
            .notification-dropdown { width: 300px; right: -10px; }
            .modal { padding: 1.5rem; }
            .modal .form-row { grid-template-columns: 1fr; }
            .modal .submit-row { flex-direction: column; }
            .modal .submit-row .btn-submit, .modal .submit-row .btn-cancel { width: 100%; text-align: center; }
            .toast-container { right: 1rem; left: 1rem; }
            .toast { min-width: auto; width: 100%; }
        }
        @media (max-width: 480px) {
            .nav-links { gap: 1rem; }
            .nav-links a { font-size: 0.85rem; }
            .fav-grid, .project-grid { grid-template-columns: 1fr; gap: 0.8rem; }
            .profile-content { padding: 0.8rem; }
            .profile-sidebar { padding: 0.6rem 0.8rem; gap: 0.2rem; }
            .profile-sidebar .menu-item { font-size: 0.75rem; padding: 0.25rem 0.5rem; }
            .profile-sidebar .menu-item i { font-size: 0.75rem; width: 1rem; }
            .info-grid { padding: 1rem; }
            .account-section { padding: 1rem; }
            .user-info .name { font-size: 0.8rem; }
            .avatar { width: 30px; height: 30px; font-size: 0.75rem; }
            .notification-dropdown { width: 280px; right: 0; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="container">
            <a href="home.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· 项目式学习中心</span>
            </a>
            <div class="nav-links">
                <a href="home.php">首页</a>
                <a href="resources.php">PBL资源库</a>
                <a href="courses.php">课程中心</a>
                <a href="community.php">教师社区</a>
                <a class="active" href="profile.php">个人中心</a>
            </div>
            <div class="nav-right">
                <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                <div class="user-info">
                    <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                    <span class="role"><?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                </div>
                <div class="notification-wrapper">
                    <button class="notification-btn" id="notificationBtn">
                        <i class="fas fa-bell"></i>
                        <span class="badge" id="unreadBadge"><?php echo $unreadCount; ?></span>
                    </button>
                    <div class="notification-dropdown" id="notificationDropdown">
                        <div class="notification-header">
                            <span>消息通知</span>
                            <span class="mark-read" id="markReadBtn">全部已读</span>
                        </div>
                        <div class="notification-list" id="messageList">
                            <?php if (empty($messages)): ?>
                                <div style="text-align:center;padding:1rem;color:var(--text-light);">暂无消息</div>
                            <?php else: ?>
                                <?php foreach ($messages as $m): ?>
                                <div class="notification-item" style="<?php echo !$m['is_read'] ? 'background:#f0f7ff;' : ''; ?>">
                                    <div class="notif-avatar"><?php echo htmlspecialchars($m['real_name'] ? mb_substr($m['real_name'], 0, 1) : ($m['username'] ? mb_substr($m['username'], 0, 1) : 'U')); ?></div>
                                    <div class="notif-content">
                                        <span class="notif-text"><strong><?php echo htmlspecialchars($m['real_name'] ?? $m['username'] ?? '未知用户'); ?></strong> <?php echo htmlspecialchars($m['content']); ?></span>
                                        <span class="notif-time"><?php echo formatTime($m['created_at']); ?></span>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
            </div>
        </div>
    </nav>

    <main class="container">
        <section class="page-section">
            <div class="profile-layout">
                <aside class="profile-sidebar">
                    <div class="user-avatar">
                        <div class="avatar-big" id="avatarBig">
                            <?php if (!empty($user['avatar'])): ?>
                                <img src="<?php echo htmlspecialchars($user['avatar']); ?>" alt="头像">
                            <?php else: ?>
                                <i class="fas fa-user-circle"></i>
                            <?php endif; ?>
                        </div>
                        <div class="uname"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></div>
                        <div class="urole"><?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></div>
                        <button class="btn-sm" id="uploadAvatarBtn" style="margin-top:0.5rem;padding:0.2rem 1rem;border-radius:30px;font-size:0.7rem;border:1px solid var(--border);background:var(--bg);cursor:pointer;">更换头像</button>
                        <input type="file" id="avatarInput" accept="image/*" style="display:none;">
                    </div>
                    <button class="menu-item active" data-panel="info"><i class="fas fa-id-card"></i> 个人信息</button>
                    <button class="menu-item" data-panel="records"><i class="fas fa-history"></i> 课程进度 <span class="badge-count"><?php echo $stats['courses']; ?></span></button>
                    <button class="menu-item" data-panel="fav-courses"><i class="fas fa-heart"></i> 我的收藏 <span class="badge-count"><?php echo $stats['favorites']; ?></span></button>
                    <button class="menu-item" data-panel="projects"><i class="fas fa-folder-open"></i> 我的项目 <span class="badge-count"><?php echo $stats['projects']; ?></span></button>
                    <button class="menu-item" data-panel="activity"><i class="fas fa-rss"></i> 学习动态 <span class="badge-count"><?php echo $stats['activities']; ?></span></button>
                    <div class="menu-divider"></div>
                    <button class="menu-item" data-panel="account"><i class="fas fa-cog"></i> 账号管理</button>
                    <button class="menu-item danger" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> 退出登录</button>
                </aside>
                <div class="profile-content">
                    <div class="panel active" id="panel-info">
                        <div class="panel-title"><i class="fas fa-id-card"></i> 个人信息 <span style="font-size:0.8rem;font-weight:400;color:var(--text-light);margin-left:0.5rem;">点击 <i class="fas fa-pen"></i> 编辑</span></div>
                        <div class="info-grid">
                            <div class="item"><span class="label">姓名</span><span class="value"><?php echo htmlspecialchars($userInfo['real_name'] ?? $userInfo['username'] ?? ''); ?> <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                            <div class="item"><span class="label">性别</span><span class="value"><?php echo htmlspecialchars(getGenderText($userInfo['gender'] ?? '')); ?></span></div>
                            <div class="item"><span class="label">学校</span><span class="value"><?php echo htmlspecialchars($userInfo['school'] ?? '未设置'); ?> <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                            <div class="item"><span class="label">学科</span><span class="value"><?php echo htmlspecialchars($userInfo['subject'] ?? '未设置'); ?> <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                            <div class="item"><span class="label">教龄</span><span class="value"><?php echo htmlspecialchars($userInfo['teaching_years'] ?? '0'); ?> 年 <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                            <div class="item"><span class="label">邮箱</span><span class="value"><?php echo htmlspecialchars($userInfo['email'] ?? '未设置'); ?> <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                            <div class="item"><span class="label">手机</span><span class="value"><?php echo htmlspecialchars($userInfo['phone'] ?? '未设置'); ?> <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                            <div class="item"><span class="label">角色</span><span class="value"><?php echo htmlspecialchars(getRoleName($userInfo['role'])); ?></span></div>
                            <div class="item" style="grid-column: 1 / -1;"><span class="label">个人简介</span><span class="value"><?php echo htmlspecialchars($userInfo['bio'] ?? $userInfo['personal_intro'] ?? '这个人很懒，还没有写简介'); ?> <span class="edit-hint" onclick="openEditProfile()"><i class="fas fa-pen"></i></span></span></div>
                        </div>
                    </div>
                    <div class="panel" id="panel-records">
                        <div class="panel-title"><i class="fas fa-history"></i> 课程进度 <span class="badge-count"><?php echo $stats['courses']; ?></span></div>
                        <div class="record-list">
                            <?php if (empty($courseProgress)): ?>
                                <div class="empty-state-sm"><i class="fas fa-book-open"></i><h4>暂无学习记录</h4><p>去课程中心学习吧</p></div>
                            <?php else: ?>
                                <?php foreach ($courseProgress as $r): ?>
                                <div class="record-item">
                                    <div class="info">
                                        <div class="title"><?php echo htmlspecialchars($r['course_title'] ?? '未命名课程'); ?></div>
                                        <div class="meta"><span><i class="fas fa-user"></i> <?php echo htmlspecialchars($r['instructor'] ?? '未知'); ?></span><span><i class="far fa-clock"></i> <?php echo formatTime($r['last_learn_time']); ?></span></div>
                                    </div>
                                    <div class="progress-wrap">
                                        <div class="bar"><div class="fill" style="width:<?php echo intval($r['progress'] ?? 0); ?>%;"></div></div>
                                        <span class="pct"><?php echo intval($r['progress'] ?? 0); ?>%</span>
                                    </div>
                                    <button class="continue-btn" onclick="window.location.href='course_play.php?cid=<?php echo $r['course_id']; ?>'">继续学习</button>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="panel" id="panel-fav-courses">
                        <div class="panel-title"><i class="fas fa-heart"></i> 我的收藏 <span class="badge-count"><?php echo $stats['favorites']; ?></span></div>
                        <div class="fav-grid">
                            <?php if (empty($favorites)): ?>
                                <div class="empty-state-sm" style="grid-column:1/-1;"><i class="fas fa-heart"></i><h4>暂无收藏</h4><p>去课程中心收藏喜欢的课程吧</p></div>
                            <?php else: ?>
                                <?php foreach ($favorites as $f): ?>
                                <div class="fav-item" data-id="<?php echo $f['course_id']; ?>">
                                    <div class="fav-title"><?php echo htmlspecialchars($f['course_title'] ?? '未命名课程'); ?></div>
                                    <div class="fav-meta"><span><i class="fas fa-user"></i> <?php echo htmlspecialchars($f['instructor'] ?? '未知'); ?></span><span><i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($f['level'] ?? '通用'); ?></span></div>
                                    <div class="fav-actions">
                                        <button onclick="window.location.href='course_play.php?cid=<?php echo $f['course_id']; ?>'"><i class="fas fa-eye"></i> 查看</button>
                                        <button class="danger" onclick="removeFavorite(<?php echo $f['course_id']; ?>)"><i class="fas fa-times"></i> 取消收藏</button>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="panel" id="panel-projects">
                        <div class="panel-title"><i class="fas fa-folder-open"></i> 我的项目 <span class="badge-count"><?php echo $stats['projects']; ?></span></div>
                        <div class="project-grid">
                            <?php if (empty($projects)): ?>
                                <div class="empty-state-sm" style="grid-column:1/-1;"><i class="fas fa-folder-open"></i><h4>暂无项目</h4><p>去资源库创建项目吧</p></div>
                            <?php else: ?>
                                <?php foreach ($projects as $p): ?>
                                <?php $statusMap = [0 => 'draft', 1 => 'published', 2 => 'archived']; ?>
                                <?php $statusLabel = [0 => '草稿', 1 => '已发布', 2 => '已归档']; ?>
                                <div class="project-item">
                                    <div class="proj-title"><?php echo htmlspecialchars($p['title']); ?></div>
                                    <div class="proj-meta"><span><i class="far fa-calendar-alt"></i> <?php echo formatDate($p['created_at']); ?></span><span class="proj-status <?php echo $statusMap[$p['status']] ?? 'draft'; ?>"><?php echo $statusLabel[$p['status']] ?? '草稿'; ?></span></div>
                                    <div class="proj-actions">
                                        <button onclick="showToast('编辑项目：<?php echo htmlspecialchars($p['title']); ?>', 'warning')"><i class="fas fa-edit"></i> 编辑</button>
                                        <button onclick="showToast('查看项目：<?php echo htmlspecialchars($p['title']); ?>', 'warning')"><i class="fas fa-eye"></i> 查看</button>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="panel" id="panel-activity">
                        <div class="panel-title"><i class="fas fa-rss"></i> 学习动态 <span class="badge-count"><?php echo $stats['activities']; ?></span></div>
                        <div class="activity-list">
                            <?php if (empty($activities)): ?>
                                <div class="empty-state-sm"><i class="fas fa-rss"></i><h4>暂无动态</h4><p>开始学习或收藏课程吧</p></div>
                            <?php else: ?>
                                <?php foreach ($activities as $a): ?>
                                <?php 
                                $iconMap = ['learn' => 'fa-play-circle', 'course_complete' => 'fa-check-circle', 'collect' => 'fa-heart', 'post' => 'fa-pen', 'comment' => 'fa-comment', 'like' => 'fa-thumbs-up', 'badge' => 'fa-award'];
                                $colorMap = ['learn' => '#2563eb', 'course_complete' => '#22c55e', 'collect' => '#dc2626', 'post' => '#f59e0b', 'comment' => '#8b5cf6', 'like' => '#ec4899', 'badge' => '#f59e0b'];
                                $labelMap = ['learn' => '学习了', 'course_complete' => '完成了', 'collect' => '收藏了', 'post' => '发布了', 'comment' => '评论了', 'like' => '赞了', 'badge' => '获得了'];
                                $icon = $iconMap[$a['action_type']] ?? 'fa-circle';
                                $color = $colorMap[$a['action_type']] ?? '#2563eb';
                                $label = $labelMap[$a['action_type']] ?? '操作了';
                                ?>
                                <div class="activity-item">
                                    <div class="act-icon" style="color:<?php echo $color; ?>; background:<?php echo $color; ?>22;"><i class="fas <?php echo $icon; ?>"></i></div>
                                    <div class="act-content"><div class="act-text"><?php echo $label; ?> <strong><?php echo htmlspecialchars($a['target_title'] ?? '未知内容'); ?></strong></div>
                                        <div class="act-meta"><span>类型：<?php echo htmlspecialchars($a['target_type']); ?></span></div>
                                    </div>
                                    <span class="act-time"><?php echo formatTime($a['created_at']); ?></span>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="panel" id="panel-account">
                        <div class="panel-title"><i class="fas fa-cog"></i> 账号管理</div>
                        <div class="account-section">
                            <div class="row"><div class="label"><i class="fas fa-user"></i> 账号信息</div><div class="value"><?php echo htmlspecialchars($user['username']); ?></div><button class="action-btn" onclick="openEditProfile()">编辑资料</button></div>
                            <div class="row"><div class="label"><i class="fas fa-envelope"></i> 绑定邮箱</div><div class="value"><?php echo htmlspecialchars($user['email'] ?? '未绑定'); ?></div><button class="action-btn" onclick="openEditProfile()">修改邮箱</button></div>
                            <div class="row"><div class="label"><i class="fas fa-phone"></i> 绑定手机</div><div class="value"><?php echo htmlspecialchars($user['phone'] ?? '未绑定'); ?></div><button class="action-btn" onclick="openEditProfile()">修改手机</button></div>
                            <div class="row"><div class="label"><i class="fas fa-lock"></i> 密码管理</div><div class="value">******</div><button class="action-btn" id="changePwdBtn">修改密码</button></div>
                            <div class="row"><div class="label"><i class="fas fa-image"></i> 头像设置</div><div class="value">已上传</div><button class="action-btn" id="changeAvatarBtn">更换头像</button></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- ===== 编辑个人信息弹窗 ===== -->
    <div class="modal-overlay" id="editProfileModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-edit"></i> 编辑个人信息</h2>
                <button class="close-btn" id="closeEditModal">&times;</button>
            </div>
            <form id="editProfileForm" onsubmit="return false;">
                <div class="form-row">
                    <div class="form-group"><label>真实姓名 <span class="required">*</span></label><input type="text" id="editRealName" placeholder="请输入真实姓名"></div>
                    <div class="form-group"><label>学校</label><input type="text" id="editSchool" placeholder="请输入学校名称"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>学科</label><input type="text" id="editSubject" placeholder="请输入任教学科"></div>
                    <div class="form-group"><label>教龄</label><input type="number" id="editTeachingYears" placeholder="请输入教龄" min="0"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>邮箱</label><input type="email" id="editEmail" placeholder="请输入邮箱"></div>
                    <div class="form-group"><label>手机号</label><input type="tel" id="editPhone" placeholder="请输入手机号"></div>
                </div>
                <div class="form-group"><label>个人简介</label><textarea id="editBio" placeholder="请输入个人简介"></textarea></div>
                <div class="submit-row">
                    <button type="submit" class="btn-submit" id="saveProfileBtn"><i class="fas fa-save"></i> 保存</button>
                    <button type="button" class="btn-cancel" id="cancelEditBtn">取消</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===== 修改密码弹窗 ===== -->
    <div class="modal-overlay" id="changePwdModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-lock"></i> 修改密码</h2>
                <button class="close-btn" id="closePwdModal">&times;</button>
            </div>
            <form id="changePwdForm" onsubmit="return false;">
                <div class="form-group"><label>当前密码 <span class="required">*</span></label><input type="password" id="oldPassword" placeholder="请输入当前密码"></div>
                <div class="form-group"><label>新密码 <span class="required">*</span></label><input type="password" id="newPassword" placeholder="请输入新密码（至少6位）"></div>
                <div class="form-group"><label>确认新密码 <span class="required">*</span></label><input type="password" id="confirmPassword" placeholder="请再次输入新密码"></div>
                <div class="submit-row">
                    <button type="submit" class="btn-submit" id="savePwdBtn"><i class="fas fa-save"></i> 确认修改</button>
                    <button type="button" class="btn-cancel" id="cancelPwdBtn">取消</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===== Toast 容器 ===== -->
    <div id="toastContainer"></div>

    <footer class="footer">
        <div class="container">
            <div class="col">
                <strong>PBL HUB</strong>
                <span>项目式学习教师研修社区</span>
                <span><i class="fas fa-map-marker-alt"></i> 兰州市 · 教育创新中心</span>
            </div>
            <div class="col">
                <strong>关于我们</strong>
                <span><i class="fas fa-envelope"></i> contact@pblhub.edu</span>
                <span><i class="fas fa-users"></i> 成员：张老师、李老师、王老师</span>
                <span><i class="fas fa-info-circle"></i> 赋能教师PBL设计</span>
            </div>
            <div class="col">
                <strong>快速链接</strong>
                <a href="home.php"><i class="fas fa-home"></i> 首页</a>
                <a href="profile.php"><i class="fas fa-user"></i> 个人中心</a>
            </div>
        </div>
        <div class="bottom">© <?php echo date('Y'); ?> PBL HUB · 项目式学习中心</div>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {

        // ============================================================
        // Toast 通知
        // ============================================================
        function showToast(message, type) {
            type = type || 'success';
            var container = document.getElementById('toastContainer');
            var icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
            var toast = document.createElement('div');
            toast.className = 'toast ' + type;
            toast.style.cssText = 'background:#fff;padding:0.8rem 1.6rem 0.8rem 1.2rem;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,0.12);border-left:4px solid ' + (type === 'success' ? '#22c55e' : type === 'warning' ? '#f59e0b' : '#ef4444') + ';display:flex;align-items:center;gap:0.8rem;animation:slideIn 0.35s ease;min-width:260px;font-size:0.9rem;color:#0f172a;border:1px solid #e9edf4;';
            toast.innerHTML =
                '<span style="font-size:1.2rem;color:' + (type === 'success' ? '#22c55e' : type === 'warning' ? '#f59e0b' : '#ef4444') + ';"><i class="fas ' + (icons[type] || icons.success) + '"></i></span>' +
                '<span>' + message + '</span>' +
                '<button style="margin-left:auto;background:none;border:none;color:#94a3b8;cursor:pointer;font-size:1.1rem;">&times;</button>';
            container.appendChild(toast);
            toast.querySelector('button').addEventListener('click', function() { toast.remove(); });
            setTimeout(function() { toast.style.opacity = '0'; toast.style.transform = 'translateX(40px)'; setTimeout(function() { toast.remove(); }, 300); }, 4000);
        }

        // ============================================================
        // 侧边栏切换
        // ============================================================
        var menuItems = document.querySelectorAll('.profile-sidebar .menu-item[data-panel]');
        for (var i = 0; i < menuItems.length; i++) {
            (function(item) {
                item.addEventListener('click', function() {
                    var target = this.dataset.panel;
                    var allMenus = document.querySelectorAll('.profile-sidebar .menu-item[data-panel]');
                    for (var j = 0; j < allMenus.length; j++) {
                        allMenus[j].classList.remove('active');
                    }
                    this.classList.add('active');
                    var panels = document.querySelectorAll('.profile-content .panel');
                    for (var k = 0; k < panels.length; k++) {
                        panels[k].classList.remove('active');
                    }
                    var panel = document.getElementById('panel-' + target);
                    if (panel) panel.classList.add('active');
                });
            })(menuItems[i]);
        }

        // ============================================================
        // 编辑个人信息
        // ============================================================
        function openEditProfile() {
            var modal = document.getElementById('editProfileModal');
            var info = <?php echo json_encode($userInfo); ?>;
            document.getElementById('editRealName').value = info.real_name || '';
            document.getElementById('editSchool').value = info.school || '';
            document.getElementById('editSubject').value = info.subject || '';
            document.getElementById('editTeachingYears').value = info.teaching_years || 0;
            document.getElementById('editEmail').value = info.email || '';
            document.getElementById('editPhone').value = info.phone || '';
            document.getElementById('editBio').value = info.bio || info.personal_intro || '';
            modal.classList.add('show');
        }
        window.openEditProfile = openEditProfile;

        function closeEditProfile() {
            document.getElementById('editProfileModal').classList.remove('show');
        }

        document.getElementById('closeEditModal').addEventListener('click', closeEditProfile);
        document.getElementById('cancelEditBtn').addEventListener('click', closeEditProfile);

        document.getElementById('saveProfileBtn').addEventListener('click', function() {
            var data = new FormData();
            data.append('action', 'update_profile');
            data.append('real_name', document.getElementById('editRealName').value.trim());
            data.append('school', document.getElementById('editSchool').value.trim());
            data.append('subject', document.getElementById('editSubject').value.trim());
            data.append('teaching_years', document.getElementById('editTeachingYears').value.trim());
            data.append('email', document.getElementById('editEmail').value.trim());
            data.append('phone', document.getElementById('editPhone').value.trim());
            data.append('bio', document.getElementById('editBio').value.trim());

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 保存中...';

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    document.getElementById('saveProfileBtn').disabled = false;
                    document.getElementById('saveProfileBtn').innerHTML = '<i class="fas fa-save"></i> 保存';
                    if (data.success) {
                        showToast('个人信息更新成功', 'success');
                        closeEditProfile();
                        setTimeout(function() { window.location.reload(); }, 1000);
                    } else {
                        showToast(data.message || '更新失败', 'error');
                    }
                })
                .catch(function(err) { showToast('更新失败', 'error'); });
        });

        // ============================================================
        // 修改密码
        // ============================================================
        document.getElementById('changePwdBtn').addEventListener('click', function() {
            document.getElementById('changePwdModal').classList.add('show');
            document.getElementById('oldPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        });

        function closePwdModal() {
            document.getElementById('changePwdModal').classList.remove('show');
        }

        document.getElementById('closePwdModal').addEventListener('click', closePwdModal);
        document.getElementById('cancelPwdBtn').addEventListener('click', closePwdModal);

        document.getElementById('savePwdBtn').addEventListener('click', function() {
            var oldPwd = document.getElementById('oldPassword').value.trim();
            var newPwd = document.getElementById('newPassword').value.trim();
            var confirmPwd = document.getElementById('confirmPassword').value.trim();

            if (!oldPwd || !newPwd || !confirmPwd) {
                showToast('请填写完整信息', 'warning');
                return;
            }
            if (newPwd.length < 6) {
                showToast('新密码至少6位', 'warning');
                return;
            }
            if (newPwd !== confirmPwd) {
                showToast('两次密码不一致', 'warning');
                return;
            }

            var data = new FormData();
            data.append('action', 'change_password');
            data.append('old_password', oldPwd);
            data.append('new_password', newPwd);
            data.append('confirm_password', confirmPwd);

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 修改中...';

            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    document.getElementById('savePwdBtn').disabled = false;
                    document.getElementById('savePwdBtn').innerHTML = '<i class="fas fa-save"></i> 确认修改';
                    if (data.success) {
                        showToast('密码修改成功', 'success');
                        closePwdModal();
                    } else {
                        showToast(data.message || '修改失败', 'error');
                    }
                })
                .catch(function(err) { showToast('修改失败', 'error'); });
        });

        // ============================================================
        // 上传头像
        // ============================================================
        document.getElementById('uploadAvatarBtn').addEventListener('click', function() {
            document.getElementById('avatarInput').click();
        });
        document.getElementById('changeAvatarBtn').addEventListener('click', function() {
            document.getElementById('avatarInput').click();
        });

        document.getElementById('avatarInput').addEventListener('change', function() {
            var file = this.files[0];
            if (!file) return;

            var formData = new FormData();
            formData.append('action', 'upload_avatar');
            formData.append('avatar', file);

            showToast('上传中...', 'warning');

            fetch(window.location.href, { method: 'POST', body: formData })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        showToast('头像上传成功', 'success');
                        var avatarBig = document.getElementById('avatarBig');
                        if (avatarBig) {
                            avatarBig.innerHTML = '<img src="' + data.data.avatar + '?t=' + Date.now() + '" alt="头像">';
                        }
                        setTimeout(function() { window.location.reload(); }, 500);
                    } else {
                        showToast(data.message || '上传失败', 'error');
                    }
                })
                .catch(function(err) { showToast('上传失败', 'error'); });
            this.value = '';
        });

        // ============================================================
        // 取消收藏
        // ============================================================
        function removeFavorite(courseId) {
            if (!confirm('确定要取消收藏该课程吗？')) return;
            var data = new FormData();
            data.append('action', 'remove_favorite');
            data.append('course_id', courseId);
            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        showToast('已取消收藏', 'success');
                        setTimeout(function() { window.location.reload(); }, 500);
                    } else {
                        showToast(data.message || '操作失败', 'error');
                    }
                })
                .catch(function(err) { showToast('操作失败', 'error'); });
        }
        window.removeFavorite = removeFavorite;

        // ============================================================
        // 通知下拉
        // ============================================================
        var notificationBtn = document.getElementById('notificationBtn');
        var notificationDropdown = document.getElementById('notificationDropdown');
        var markReadBtn = document.getElementById('markReadBtn');

        notificationBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            notificationDropdown.classList.toggle('show');
        });

        document.addEventListener('click', function(e) {
            if (!notificationDropdown.contains(e.target) && e.target !== notificationBtn && !notificationBtn.contains(e.target)) {
                notificationDropdown.classList.remove('show');
            }
        });

        markReadBtn.addEventListener('click', function() {
            var data = new FormData();
            data.append('action', 'mark_read');
            fetch(window.location.href, { method: 'POST', body: data })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        document.getElementById('unreadBadge').textContent = '0';
                        showToast('全部已读', 'success');
                        setTimeout(function() { window.location.reload(); }, 500);
                    }
                });
        });

        // ============================================================
        // 退出登录
        // ============================================================
        document.getElementById('logoutBtn').addEventListener('click', function() {
            if (confirm('确定要退出登录吗？')) {
                window.location.href = 'logout.php';
            }
        });

        // ============================================================
        // 暴露函数给全局
        // ============================================================
        window.showToast = showToast;
        window.removeFavorite = removeFavorite;
        window.openEditProfile = openEditProfile;

        console.log('✅ 个人中心加载完成');
    });
    </script>

</body>
</html>