<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';


// ===== 调试：检查数据库连接 =====
if ($conn->connect_error) {
    die("❌ 数据库连接失败: " . $conn->connect_error);
}

// ===== 调试：检查 projects 表是否存在 =====
$checkTable = $conn->query("SHOW TABLES LIKE 'projects'");
if ($checkTable->num_rows == 0) {
    die("❌ 表 projects 不存在，请在 SQLyog 中创建");
}

// ===== 调试：检查 projects 表有多少条数据 =====
$countResult = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status = 1");
$count = $countResult->fetch_assoc();
echo "<!-- 调试：projects 表中有 " . $count['total'] . " 条已发布数据 -->";



// 获取当前登录用户
$user = null;
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}

// 获取角色中文名
function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

// 获取头像首字母
function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// ============================================================
// 处理 AJAX 请求（增删改查）
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 获取项目列表 ----------
    if ($action === 'get_projects') {
        $level = sanitize($_POST['level'] ?? '');
        $subject = sanitize($_POST['subject'] ?? '');
        $keyword = sanitize($_POST['keyword'] ?? '');
        $sort = $_POST['sort'] ?? 'latest';
        $page = intval($_POST['page'] ?? 1);
        $limit = 12;
        $offset = ($page - 1) * $limit;
        
        $where = "WHERE status = 1";
        if ($level) $where .= " AND level = '$level'";
        if ($subject) $where .= " AND subject = '$subject'";
        if ($keyword) {
            $keyword = $conn->real_escape_string($keyword);
            $where .= " AND (title LIKE '%$keyword%' OR description LIKE '%$keyword%' OR subject LIKE '%$keyword%' OR tags LIKE '%$keyword%')";
        }
        
        $order = match($sort) {
            'hot' => 'ORDER BY views DESC, downloads DESC',
            'fav' => 'ORDER BY views DESC',
            default => 'ORDER BY sort_order DESC, created_at DESC'
        };
        
        // 获取总数
        $countSql = "SELECT COUNT(*) as total FROM projects $where";
        $countResult = $conn->query($countSql);
        $total = $countResult->fetch_assoc()['total'];
        
        // 获取数据
        $sql = "SELECT p.*, u.username, u.real_name 
                FROM projects p 
                LEFT JOIN users u ON p.author_id = u.id 
                $where 
                $order 
                LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);
        $projects = [];
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
        
        jsonResponse(true, '获取成功', [
            'projects' => $projects,
            'total' => intval($total),
            'page' => $page,
            'total_pages' => ceil($total / $limit)
        ]);
    }
    
    // ---------- 获取单个项目 ----------
    if ($action === 'get_project') {
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '项目ID不能为空');
        
        $sql = "SELECT p.*, u.username, u.real_name 
                FROM projects p 
                LEFT JOIN users u ON p.author_id = u.id 
                WHERE p.pID = $id";
        $result = $conn->query($sql);
        $project = $result->fetch_assoc();
        
        if (!$project) jsonResponse(false, '项目不存在');
        jsonResponse(true, '获取成功', ['project' => $project]);
    }
    
    // ---------- 新增项目 ----------
    if ($action === 'add_project') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $title = sanitize($_POST['title'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $level = sanitize($_POST['level'] ?? '');
        $subject = sanitize($_POST['subject'] ?? '');
        $tags = sanitize($_POST['tags'] ?? '');
        $icon = sanitize($_POST['icon'] ?? 'fa-seedling');
        $is_hot = intval($_POST['is_hot'] ?? 0);
        $is_new = intval($_POST['is_new'] ?? 1);
        $is_pick = intval($_POST['is_pick'] ?? 0);
        $sort_order = intval($_POST['sort_order'] ?? 0);
        
        if (empty($title)) jsonResponse(false, '请填写项目名称');
        if (empty($description)) jsonResponse(false, '请填写项目描述');
        if (empty($level)) jsonResponse(false, '请选择学段');
        if (empty($subject)) jsonResponse(false, '请选择学科');
        
        $sql = "INSERT INTO projects (title, description, level, subject, tags, icon, is_hot, is_new, is_pick, sort_order, author_id) 
                VALUES ('$title', '$description', '$level', '$subject', '$tags', '$icon', $is_hot, $is_new, $is_pick, $sort_order, {$user['id']})";
        
        if ($conn->query($sql)) {
            jsonResponse(true, '项目创建成功', ['id' => $conn->insert_id]);
        } else {
            jsonResponse(false, '创建失败：' . $conn->error);
        }
    }
    
    // ---------- 更新项目 ----------
    if ($action === 'update_project') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '项目ID不能为空');
        
        // 检查权限（只能编辑自己的项目，管理员可编辑所有）
        $checkSql = "SELECT author_id FROM projects WHERE pID = $id";
        $checkResult = $conn->query($checkSql);
        $check = $checkResult->fetch_assoc();
        if (!$check) jsonResponse(false, '项目不存在');
        if ($check['author_id'] != $user['id'] && ($user['role'] ?? '') != 'admin') {
            jsonResponse(false, '没有权限编辑此项目');
        }
        
        $title = sanitize($_POST['title'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $level = sanitize($_POST['level'] ?? '');
        $subject = sanitize($_POST['subject'] ?? '');
        $tags = sanitize($_POST['tags'] ?? '');
        $icon = sanitize($_POST['icon'] ?? 'fa-seedling');
        $is_hot = intval($_POST['is_hot'] ?? 0);
        $is_new = intval($_POST['is_new'] ?? 1);
        $is_pick = intval($_POST['is_pick'] ?? 0);
        $sort_order = intval($_POST['sort_order'] ?? 0);
        
        if (empty($title)) jsonResponse(false, '请填写项目名称');
        if (empty($description)) jsonResponse(false, '请填写项目描述');
        if (empty($level)) jsonResponse(false, '请选择学段');
        if (empty($subject)) jsonResponse(false, '请选择学科');
        
        $sql = "UPDATE projects SET 
                title = '$title',
                description = '$description',
                level = '$level',
                subject = '$subject',
                tags = '$tags',
                icon = '$icon',
                is_hot = $is_hot,
                is_new = $is_new,
                is_pick = $is_pick,
                sort_order = $sort_order,
                updated_at = NOW()
                WHERE pID = $id";
        
        if ($conn->query($sql)) {
            jsonResponse(true, '项目更新成功');
        } else {
            jsonResponse(false, '更新失败：' . $conn->error);
        }
    }
    
    // ---------- 删除项目 ----------
    if ($action === 'delete_project') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '项目ID不能为空');
        
        // 检查权限
        $checkSql = "SELECT author_id FROM projects WHERE pID = $id";
        $checkResult = $conn->query($checkSql);
        $check = $checkResult->fetch_assoc();
        if (!$check) jsonResponse(false, '项目不存在');
        if ($check['author_id'] != $user['id'] && ($user['role'] ?? '') != 'admin') {
            jsonResponse(false, '没有权限删除此项目');
        }
        
        $sql = "DELETE FROM projects WHERE pID = $id";
        if ($conn->query($sql)) {
            jsonResponse(true, '项目删除成功');
        } else {
            jsonResponse(false, '删除失败：' . $conn->error);
        }
    }
    
    // ---------- 浏览/下载计数 ----------
    if ($action === 'increment_views') {
        $id = intval($_POST['id'] ?? 0);
        if ($id) {
            $conn->query("UPDATE projects SET views = views + 1 WHERE pID = $id");
        }
        jsonResponse(true, 'ok');
    }
    
    if ($action === 'increment_downloads') {
        $id = intval($_POST['id'] ?? 0);
        if ($id) {
            $conn->query("UPDATE projects SET downloads = downloads + 1 WHERE pID = $id");
        }
        jsonResponse(true, 'ok');
    }
    
    jsonResponse(false, '无效操作');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · PBL资源库</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ===== 全局重置 & 变量 ===== */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; }
        :root {
            --primary: #2563eb; --primary-hover: #1d4ed8; --primary-light: #dbeafe;
            --bg: #f6f9fc; --card-bg: #ffffff; --text-dark: #0f172a;
            --text-mid: #475569; --text-light: #94a3b8; --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0,0,0,0.04); --shadow-hover: 0 12px 32px rgba(0,0,0,0.08);
            --radius: 20px; --radius-sm: 12px; --transition: 0.25s ease;
        }
        body { background: var(--bg); color: var(--text-dark); line-height: 1.6; min-height: 100vh; }
        .container { max-width: 1360px; margin: 0 auto; padding: 0 1.8rem; }

        /* ===== 导航栏 ===== */
        .navbar {
            background: rgba(255,255,255,0.90); backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0,0,0,0.04); padding: 0.6rem 0;
            position: sticky; top: 0; z-index: 100; border-bottom: 1px solid var(--border);
        }
        .navbar .container {
            display: flex; align-items: center; justify-content: space-between;
            flex-wrap: wrap; gap: 0.6rem;
        }
        .logo {
            display: flex; align-items: center; gap: 0.5rem;
            font-size: 1.6rem; font-weight: 700; color: var(--primary);
            text-decoration: none; flex-shrink: 0;
        }
        .logo i { font-size: 2rem; }
        .logo span { font-weight: 300; color: var(--text-light); font-size: 0.85rem; }
        .nav-links {
            display: flex; gap: 0.8rem; align-items: center; flex-wrap: wrap;
            justify-content: center; flex: 1;
        }
        .nav-links a {
            text-decoration: none; color: var(--text-mid); font-weight: 500;
            font-size: 0.95rem; padding: 0.3rem 0.8rem;
            border-bottom: 2.5px solid transparent; transition: var(--transition);
            cursor: pointer; white-space: nowrap;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active { color: var(--primary); border-bottom-color: var(--primary); }
        .nav-right {
            display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; flex-shrink: 0;
        }
        .avatar {
            width: 36px; height: 36px; background: var(--primary-light);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--primary); font-weight: 600; font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info { display: flex; flex-direction: column; line-height: 1.2; }
        .user-info .name { font-weight: 600; font-size: 0.9rem; color: var(--text-dark); }
        .user-info .role { font-size: 0.65rem; color: var(--text-light); }
        .logout-link {
            color: var(--text-light); font-size: 0.8rem; transition: var(--transition);
            display: flex; align-items: center; gap: 0.2rem; text-decoration: none;
            background: none; border: none; cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }
        .login-link {
            color: var(--primary); font-size: 0.9rem; font-weight: 600;
            text-decoration: none; padding: 0.4rem 1.2rem;
            border: 2px solid var(--primary); border-radius: 30px; transition: var(--transition);
        }
        .login-link:hover { background: var(--primary); color: #fff; }

        /* ===== 页面内容 ===== */
        .page-section { padding: 1.5rem 0 2.5rem; }
        .page-header {
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem;
        }
        .page-header h1 {
            font-size: 1.8rem; font-weight: 700; color: var(--text-dark);
            display: flex; align-items: center; gap: 0.6rem;
        }
        .page-header h1 i { color: var(--primary); }
        .page-header .stats {
            font-size: 0.9rem; color: var(--text-light);
            background: var(--card-bg); padding: 0.3rem 1.2rem;
            border-radius: 30px; border: 1px solid var(--border);
        }
        .btn-primary {
            background: var(--primary); color: #fff; padding: 0.5rem 1.5rem;
            border: none; border-radius: 30px; font-weight: 600; font-size: 0.9rem;
            cursor: pointer; transition: var(--transition); display: inline-flex;
            align-items: center; gap: 0.5rem;
        }
        .btn-primary:hover { background: var(--primary-hover); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(37,99,235,0.3); }
        .btn-secondary {
            background: var(--bg); color: var(--text-dark); padding: 0.5rem 1.5rem;
            border: 1px solid var(--border); border-radius: 30px; font-weight: 500;
            font-size: 0.9rem; cursor: pointer; transition: var(--transition);
            display: inline-flex; align-items: center; gap: 0.5rem;
        }
        .btn-secondary:hover { background: var(--card-bg); border-color: var(--primary); color: var(--primary); }
        .btn-danger {
            background: #ef4444; color: #fff; padding: 0.5rem 1.5rem;
            border: none; border-radius: 30px; font-weight: 600; font-size: 0.9rem;
            cursor: pointer; transition: var(--transition); display: inline-flex;
            align-items: center; gap: 0.5rem;
        }
        .btn-danger:hover { background: #dc2626; }

        /* ===== 筛选栏 ===== */
        .filter-bar {
            display: flex; flex-wrap: wrap; gap: 1rem; align-items: center;
            background: var(--card-bg); padding: 0.9rem 1.5rem;
            border-radius: var(--radius-sm); border: 1px solid var(--border);
            margin-bottom: 2rem; box-shadow: var(--shadow);
        }
        .filter-bar .filter-group {
            display: flex; align-items: center; gap: 0.6rem;
        }
        .filter-bar .filter-group .label {
            font-weight: 500; font-size: 0.85rem; color: var(--text-mid);
        }
        .filter-bar select, .filter-bar input {
            padding: 0.4rem 1.2rem 0.4rem 1rem;
            border-radius: 30px; border: 1px solid var(--border);
            background: var(--bg); font-size: 0.9rem; color: var(--text-dark);
            outline: none; cursor: pointer; transition: var(--transition);
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2394a3b8' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat; background-position: right 0.8rem center;
            padding-right: 2.2rem;
        }
        .filter-bar select:hover, .filter-bar input:hover { border-color: var(--primary); }
        .filter-bar select:focus, .filter-bar input:focus {
            border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37,99,235,0.12);
        }
        .filter-bar .search-input {
            display: flex; align-items: center; background: var(--bg);
            border-radius: 30px; padding: 0.2rem 1rem 0.2rem 1.2rem;
            border: 1px solid var(--border); transition: var(--transition);
            flex: 1; min-width: 180px;
        }
        .filter-bar .search-input:focus-within {
            border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37,99,235,0.10);
            background: var(--card-bg);
        }
        .filter-bar .search-input input {
            border: none; background: transparent; padding: 0.4rem 0.5rem;
            width: 100%; font-size: 0.9rem; outline: none; color: var(--text-dark);
        }
        .filter-bar .search-input input::placeholder { color: var(--text-light); }
        .filter-bar .search-input i { color: var(--text-light); font-size: 0.9rem; }

        /* ===== 卡片网格 ===== */
        .card-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.5rem; margin-bottom: 2rem;
        }
        .card {
            background: var(--card-bg); border-radius: var(--radius);
            padding: 1.3rem 1.3rem 1.5rem; box-shadow: var(--shadow);
            border: 1px solid var(--border); transition: var(--transition);
            cursor: default; position: relative;
        }
        .card:hover {
            transform: translateY(-4px); box-shadow: var(--shadow-hover);
            border-color: #bfdbfe;
        }
        .card .icon { font-size: 2rem; color: var(--primary); margin-bottom: 0.4rem; }
        .card h4 { font-weight: 600; font-size: 1.05rem; color: var(--text-dark); }
        .card .meta {
            font-size: 0.78rem; color: var(--text-mid); margin-bottom: 0.6rem;
            display: flex; gap: 0.5rem; flex-wrap: wrap;
        }
        .card .meta span {
            background: var(--bg); padding: 0.05rem 0.6rem; border-radius: 30px; font-size: 0.7rem;
        }
        .card .desc {
            font-size: 0.85rem; color: var(--text-mid); margin-bottom: 0.6rem;
            line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .card .tags {
            display: flex; gap: 0.3rem; flex-wrap: wrap; margin-bottom: 0.5rem;
        }
        .card .tags span {
            background: var(--primary-light); color: var(--primary);
            padding: 0.05rem 0.6rem; border-radius: 30px; font-size: 0.65rem;
        }
        .card .card-footer {
            display: flex; justify-content: space-between; align-items: center;
            margin-top: 0.3rem; padding-top: 0.6rem; border-top: 1px solid var(--border);
        }
        .card .actions {
            display: flex; gap: 0.8rem; font-size: 0.78rem; color: var(--text-light);
        }
        .card .actions span { cursor: pointer; transition: var(--transition); }
        .card .actions span:hover { color: var(--primary); }
        .card .actions i { margin-right: 0.15rem; }
        .card .tag {
            font-size: 0.6rem; font-weight: 600; padding: 0.1rem 0.7rem;
            border-radius: 30px; display: inline-block;
        }
        .tag-hot { background: #fee2e2; color: #dc2626; }
        .tag-new { background: #d1fae5; color: #059669; }
        .tag-pick { background: #fef3c7; color: #d97706; }
        .tag-default { background: var(--primary-light); color: var(--primary); }

        /* ===== 分页 ===== */
        .pagination {
            display: flex; justify-content: center; gap: 0.4rem; margin-top: 1.5rem;
            flex-wrap: wrap;
        }
        .pagination span {
            padding: 0.4rem 0.9rem; border-radius: 8px; background: var(--card-bg);
            border: 1px solid var(--border); color: var(--text-mid);
            font-size: 0.9rem; cursor: pointer; transition: var(--transition);
            min-width: 36px; text-align: center;
        }
        .pagination span.active {
            background: var(--primary); color: #fff; border-color: var(--primary);
        }
        .pagination span:hover:not(.active) { border-color: var(--primary); color: var(--primary); }
        .pagination span.disabled { opacity: 0.4; cursor: not-allowed; }

        /* ===== Modal ===== */
        .modal-overlay {
            display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.4);
            backdrop-filter: blur(4px); z-index: 200; align-items: center;
            justify-content: center; padding: 1.5rem;
        }
        .modal-overlay.active { display: flex; }
        .modal {
            background: var(--card-bg); border-radius: var(--radius);
            max-width: 700px; width: 100%; max-height: 90vh; overflow-y: auto;
            padding: 2.2rem 2.8rem; box-shadow: 0 24px 60px rgba(0,0,0,0.2);
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .modal-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border);
        }
        .modal-header h2 {
            font-size: 1.4rem; font-weight: 700; color: var(--text-dark);
            display: flex; align-items: center; gap: 0.6rem;
        }
        .modal-header h2 i { color: var(--primary); }
        .modal-close {
            background: none; border: none; font-size: 1.5rem;
            color: var(--text-light); cursor: pointer; transition: var(--transition);
        }
        .modal-close:hover { color: var(--text-dark); }
        .form-group { margin-bottom: 1.2rem; }
        .form-group label {
            display: block; font-weight: 600; font-size: 0.88rem;
            color: var(--text-dark); margin-bottom: 0.3rem;
        }
        .form-group label .required { color: #ef4444; margin-left: 0.2rem; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 0.6rem 1rem; border: 1.5px solid var(--border);
            border-radius: var(--radius-sm); font-size: 0.92rem;
            background: var(--bg); color: var(--text-dark); transition: var(--transition);
            outline: none; font-family: inherit;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37,99,235,0.10);
            background: var(--card-bg);
        }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .form-group .hint { font-size: 0.78rem; color: var(--text-light); margin-top: 0.2rem; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; }
        .form-actions {
            display: flex; gap: 1rem; margin-top: 1.8rem;
            padding-top: 1.2rem; border-top: 1px solid var(--border);
        }

        /* ===== Toast ===== */
        .toast-container {
            position: fixed; top: 5rem; right: 2rem; z-index: 300;
            display: flex; flex-direction: column; gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg); padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm); box-shadow: 0 12px 32px rgba(0,0,0,0.12);
            border-left: 4px solid var(--primary); display: flex; align-items: center;
            gap: 0.8rem; animation: slideIn 0.35s ease; min-width: 280px;
            font-size: 0.9rem; color: var(--text-dark); border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast.error { border-left-color: #ef4444; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast.error .toast-icon { color: #ef4444; }
        .toast .toast-close {
            margin-left: auto; background: none; border: none;
            color: var(--text-light); cursor: pointer; font-size: 1.1rem;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* ===== 底部 ===== */
        .footer {
            background: var(--card-bg); border-top: 1px solid var(--border);
            padding: 2rem 0; margin-top: 2rem;
        }
        .footer .container {
            display: flex; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem;
        }
        .footer .col {
            display: flex; flex-direction: column; gap: 0.3rem;
            font-size: 0.9rem; color: var(--text-mid);
        }
        .footer .col strong { color: var(--text-dark); font-weight: 600; }
        .footer .col i { margin-right: 0.4rem; color: var(--primary); width: 1.2rem; text-align: center; }
        .footer .col a { color: var(--text-mid); text-decoration: none; transition: var(--transition); cursor: pointer; }
        .footer .col a:hover { color: var(--primary); }
        .footer .bottom {
            text-align: center; margin-top: 1.2rem; font-size: 0.8rem;
            color: var(--text-light); border-top: 1px solid var(--border); padding-top: 1rem;
        }

        /* ===== 空状态 ===== */
        .empty-state {
            grid-column: 1 / -1; text-align: center; padding: 3rem 0;
            color: var(--text-light);
        }
        .empty-state i { font-size: 2.5rem; display: block; margin-bottom: 0.5rem; color: var(--primary-light); }

        /* ===== 响应式 ===== */
        @media (max-width: 1024px) {
            .navbar .container { flex-direction: column; gap: 0.5rem; }
            .nav-links { gap: 0.4rem; }
            .nav-links a { font-size: 0.85rem; padding: 0.2rem 0.6rem; }
            .modal { padding: 1.8rem; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .nav-right { width: 100%; justify-content: center; flex-wrap: wrap; }
            .card-grid { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 1rem; }
            .filter-bar { flex-direction: column; align-items: stretch; gap: 0.8rem; padding: 1rem; }
            .form-row { grid-template-columns: 1fr; }
            .modal { padding: 1.2rem; margin: 0.5rem; }
            .page-header { flex-direction: column; align-items: flex-start; }
            .form-actions { flex-direction: column; }
            .form-actions .btn-primary, .form-actions .btn-secondary { width: 100%; justify-content: center; }
            .toast-container { right: 1rem; left: 1rem; }
            .toast { min-width: auto; width: 100%; }
        }
        @media (max-width: 480px) {
            .nav-links { gap: 0.2rem; }
            .nav-links a { font-size: 0.75rem; padding: 0.15rem 0.4rem; }
            .card-grid { grid-template-columns: 1fr 1fr; gap: 0.8rem; }
            .card { padding: 1rem; }
            .card h4 { font-size: 0.9rem; }
            .card .desc { font-size: 0.78rem; -webkit-line-clamp: 2; }
            .card .actions { font-size: 0.7rem; gap: 0.5rem; }
            .page-header h1 { font-size: 1.3rem; }
        }
    </style>
</head>
<body>

    <!-- ===== 导航栏 ===== -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· 项目式学习中心</span>
            </a>
            <div class="nav-links">
                <a href="home.php">首页</a>
                <a href="resources.php" class="active">PBL资源库</a>
                <a href="courses.php">课程中心</a>
                <a href="design.php">项目设计</a>
                <a href="community.php">教师社区</a>
                <a href="profile.php">个人中心</a>
            </div>
            <div class="nav-right">
                <?php if ($isLoggedIn && $user): ?>
                    <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                    <div class="user-info">
                        <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                        <span class="role"><?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                    </div>
                    <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="login.php" class="login-link"><i class="fas fa-sign-in-alt"></i> 登录</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- ===== 主内容 ===== -->
    <main class="container">
        <section class="page-section">
            <div class="page-header">
                <h1><i class="fas fa-folder-open"></i> PBL资源库</h1>
                <div style="display:flex;gap:0.8rem;flex-wrap:wrap;align-items:center;">
                    <span class="stats"><i class="far fa-file-alt"></i> 共 <span id="totalCount">0</span> 个项目</span>
                    <?php if ($isLoggedIn): ?>
                        <button class="btn-primary" id="addProjectBtn"><i class="fas fa-plus"></i> 发布项目</button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 筛选栏 -->
            <div class="filter-bar">
                <div class="filter-group"><span class="label">学段</span>
                    <select id="filterLevel">
                        <option value="">全部学段</option>
                        <option value="小学">小学</option>
                        <option value="初中">初中</option>
                        <option value="高中">高中</option>
                    </select>
                </div>
                <div class="filter-group"><span class="label">学科</span>
                    <select id="filterSubject">
                        <option value="">全部学科</option>
                        <option value="语文">语文</option><option value="数学">数学</option>
                        <option value="英语">英语</option><option value="科学">科学</option>
                        <option value="信息科技">信息科技</option>
                        <option value="艺术">艺术</option><option value="地理">地理</option>
                        <option value="生物">生物</option><option value="化学">化学</option>
                        <option value="物理">物理</option><option value="跨学科">跨学科</option>
                    </select>
                </div>
                <div class="filter-group"><span class="label">排序</span>
                    <select id="filterSort">
                        <option value="latest">最新发布</option>
                        <option value="hot">最热门</option>
                        <option value="fav">收藏最多</option>
                    </select>
                </div>
                <div class="search-input">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchKeyword" placeholder="搜索项目名称、学科...">
                </div>
            </div>

            <!-- 卡片网格 -->
            <div class="card-grid" id="projectGrid"></div>

            <!-- 分页 -->
            <div class="pagination" id="pagination"></div>
        </section>
    </main>

    <!-- ===== Modal 新增/编辑 ===== -->
    <div class="modal-overlay" id="projectModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-copy"></i> <span id="modalTitle">发布项目</span></h2>
                <button class="modal-close" id="modalClose">&times;</button>
            </div>
            <form id="projectForm" onsubmit="return false;">
                <input type="hidden" id="editId" value="">
                <div class="form-group">
                    <label>项目名称 <span class="required">*</span></label>
                    <input type="text" id="formTitle" placeholder="请输入项目名称">
                </div>
                <div class="form-group">
                    <label>项目描述 <span class="required">*</span></label>
                    <textarea id="formDesc" placeholder="请描述项目背景、预期目标、涉及的知识领域等"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>学段 <span class="required">*</span></label>
                        <select id="formLevel">
                            <option value="">请选择学段</option>
                            <option value="小学">小学</option>
                            <option value="初中">初中</option>
                            <option value="高中">高中</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>学科 <span class="required">*</span></label>
                        <select id="formSubject">
                            <option value="">请选择学科</option>
                            <option value="语文">语文</option><option value="数学">数学</option>
                            <option value="英语">英语</option><option value="科学">科学</option>
                            <option value="信息科技">信息科技</option>
                            <option value="艺术">艺术</option><option value="地理">地理</option>
                            <option value="生物">生物</option><option value="化学">化学</option>
                            <option value="物理">物理</option><option value="跨学科">跨学科</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>标签（逗号分隔）</label>
                        <input type="text" id="formTags" placeholder="例如：跨学科, 实践, 创新">
                        <div class="hint">输入标签用逗号分隔</div>
                    </div>
                    <div class="form-group">
                        <label>图标</label>
                        <select id="formIcon">
                            <option value="fa-seedling">🌱 幼苗</option>
                            <option value="fa-robot">🤖 机器人</option>
                            <option value="fa-city">🏙️ 城市</option>
                            <option value="fa-palette">🎨 调色板</option>
                            <option value="fa-water">💧 水</option>
                            <option value="fa-calculator">🧮 计算器</option>
                            <option value="fa-leaf">🍃 叶子</option>
                            <option value="fa-cogs">⚙️ 齿轮</option>
                            <option value="fa-microscope">🔬 显微镜</option>
                            <option value="fa-globe">🌐 地球</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>热门</label>
                        <select id="formHot">
                            <option value="0">否</option>
                            <option value="1">是</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>精选</label>
                        <select id="formPick">
                            <option value="0">否</option>
                            <option value="1">是</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>排序权重（越大越靠前）</label>
                    <input type="number" id="formSort" value="0">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="formSubmit"><i class="fas fa-save"></i> 保存</button>
                    <button type="button" class="btn-secondary" id="formCancel">取消</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===== Toast容器 ===== -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- ===== 底部 ===== -->
    <footer class="footer">
        <div class="container">
            <div class="col"><strong>PBL HUB</strong><span>项目式学习教师研修社区</span><span><i class="fas fa-map-marker-alt"></i> 兰州市 · 教育创新中心</span></div>
            <div class="col"><strong>关于我们</strong><span><i class="fas fa-envelope"></i> contact@pblhub.edu</span><span><i class="fas fa-users"></i> 成员：张老师、李老师、王老师</span></div>
            <div class="col"><strong>快速链接</strong><a href="home.php"><i class="fas fa-home"></i> 首页</a><a href="profile.php"><i class="fas fa-user"></i> 个人中心</a></div>
        </div>
        <div class="bottom">© <?php echo date('Y'); ?> PBL HUB · 项目式学习中心</div>
    </footer>

    <!-- ============================================================ -->
    <!-- ======================== JavaScript =========================== -->
    <!-- ============================================================ -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // ============================================================
        // 状态
        // ============================================================
        let currentPage = 1;
        let totalPages = 1;
        let isEditMode = false;

        // ============================================================
        // DOM 引用
        // ============================================================
        const grid = document.getElementById('projectGrid');
        const pagination = document.getElementById('pagination');
        const totalCount = document.getElementById('totalCount');
        const modal = document.getElementById('projectModal');
        const modalTitle = document.getElementById('modalTitle');
        const editId = document.getElementById('editId');
        const formTitle = document.getElementById('formTitle');
        const formDesc = document.getElementById('formDesc');
        const formLevel = document.getElementById('formLevel');
        const formSubject = document.getElementById('formSubject');
        const formTags = document.getElementById('formTags');
        const formIcon = document.getElementById('formIcon');
        const formHot = document.getElementById('formHot');
        const formPick = document.getElementById('formPick');
        const formSort = document.getElementById('formSort');

        // ============================================================
        // Toast
        // ============================================================
        function showToast(message, type) {
            type = type || 'success';
            const container = document.getElementById('toastContainer');
            const icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
            const toast = document.createElement('div');
            toast.className = 'toast ' + type;
            toast.innerHTML =
                `<span class="toast-icon"><i class="fas ${icons[type] || icons.success}"></i></span>
                <span>${message}</span>
                <button class="toast-close">&times;</button>`;
            container.appendChild(toast);
            toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(40px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ============================================================
        // 加载项目列表
        // ============================================================
        function loadProjects(page) {
            page = page || currentPage;
            const level = document.getElementById('filterLevel').value;
            const subject = document.getElementById('filterSubject').value;
            const keyword = document.getElementById('searchKeyword').value.trim();
            const sort = document.getElementById('filterSort').value;

            const data = new FormData();
            data.append('action', 'get_projects');
            data.append('level', level);
            data.append('subject', subject);
            data.append('keyword', keyword);
            data.append('sort', sort);
            data.append('page', page);

            fetch(window.location.href, {
                method: 'POST',
                body: data
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    renderProjects(data.data.projects);
                    renderPagination(data.data.page, data.data.total_pages);
                    totalCount.textContent = data.data.total;
                    currentPage = data.data.page;
                    totalPages = data.data.total_pages;
                } else {
                    showToast(data.message || '加载失败', 'error');
                }
            })
            .catch(err => {
                showToast('网络错误，请重试', 'error');
                console.error(err);
            });
        }

        // ============================================================
        // 渲染项目卡片
        // ============================================================
        function renderProjects(projects) {
            if (!projects || projects.length === 0) {
                grid.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>暂无项目</p>
                        <p style="font-size:0.85rem;">点击"发布项目"创建第一个PBL资源</p>
                    </div>
                `;
                return;
            }

            grid.innerHTML = projects.map(p => {
                const tagMap = {
                    'hot': p.is_hot ? '<span class="tag tag-hot">🔥 热门</span>' : '',
                    'new': p.is_new ? '<span class="tag tag-new">✨ 最新</span>' : '',
                    'pick': p.is_pick ? '<span class="tag tag-pick">⭐ 精选</span>' : ''
                };
                const tagHtml = Object.values(tagMap).filter(Boolean).join(' ');
                const tags = p.tags ? p.tags.split(',').map(t => t.trim()).filter(Boolean) : [];

                return `
                    <div class="card" data-id="${p.pID}">
                        <div class="icon"><i class="fas ${p.icon || 'fa-seedling'}"></i></div>
                        <h4>${escapeHtml(p.title)}</h4>
                        <div class="meta">
                            <span>${escapeHtml(p.level) || '未分类'} · ${escapeHtml(p.subject) || '未分类'}</span>
                        </div>
                        <div class="desc">${escapeHtml(p.description || '暂无描述')}</div>
                        <div class="tags">
                            ${tags.map(t => `<span>${escapeHtml(t)}</span>`).join('')}
                        </div>
                        <div style="display:flex;gap:0.8rem;font-size:0.7rem;color:var(--text-light);margin-bottom:0.4rem;">
                            <span><i class="far fa-eye"></i> ${p.views || 0}</span>
                            <span><i class="fas fa-download"></i> ${p.downloads || 0}</span>
                            <span><i class="far fa-user"></i> ${escapeHtml(p.real_name || p.username || '未知')}</span>
                        </div>
                        <div class="card-footer">
                            <div class="actions">
                                <span class="action-view" data-id="${p.pID}"><i class="far fa-eye"></i> 预览</span>
                                <span class="action-edit" data-id="${p.pID}"><i class="far fa-edit"></i> 编辑</span>
                                <span class="action-delete" data-id="${p.pID}"><i class="far fa-trash-alt"></i> 删除</span>
                            </div>
                            <div>${tagHtml}</div>
                        </div>
                    </div>
                `;
            }).join('');

            // 绑定事件
            document.querySelectorAll('.action-view').forEach(el => {
                el.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const id = this.dataset.id;
                    viewProject(id);
                });
            });
            document.querySelectorAll('.action-edit').forEach(el => {
                el.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const id = this.dataset.id;
                    openEditModal(id);
                });
            });
            document.querySelectorAll('.action-delete').forEach(el => {
                el.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const id = this.dataset.id;
                    deleteProject(id);
                });
            });
        }

        // ============================================================
        // 渲染分页
        // ============================================================
        function renderPagination(page, total) {
            if (total <= 1) {
                pagination.innerHTML = '';
                return;
            }
            let html = '';
            html += `<span class="${page <= 1 ? 'disabled' : ''}" data-page="${page - 1}"><i class="fas fa-chevron-left"></i></span>`;
            for (let i = 1; i <= total; i++) {
                html += `<span class="${i === page ? 'active' : ''}" data-page="${i}">${i}</span>`;
            }
            html += `<span class="${page >= total ? 'disabled' : ''}" data-page="${page + 1}"><i class="fas fa-chevron-right"></i></span>`;
            pagination.innerHTML = html;

            pagination.querySelectorAll('span[data-page]').forEach(el => {
                el.addEventListener('click', function() {
                    const p = parseInt(this.dataset.page);
                    if (p >= 1 && p <= total && p !== currentPage) {
                        loadProjects(p);
                    }
                });
            });
        }

        // ============================================================
        // 防XSS
        // ============================================================
        function escapeHtml(str) {
            if (!str) return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        // ============================================================
        // 预览项目
        // ============================================================
        function viewProject(id) {
            const data = new FormData();
            data.append('action', 'get_project');
            data.append('id', id);

            // 增加浏览次数
            const viewData = new FormData();
            viewData.append('action', 'increment_views');
            viewData.append('id', id);
            fetch(window.location.href, { method: 'POST', body: viewData });

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const p = data.data.project;
                        showToast(`📖 ${p.title}\n${p.description || '暂无描述'}`, 'success');
                    } else {
                        showToast(data.message || '加载失败', 'error');
                    }
                })
                .catch(err => showToast('加载失败', 'error'));
        }

        // ============================================================
        // 删除项目
        // ============================================================
        function deleteProject(id) {
            if (!confirm('确定要删除这个项目吗？此操作不可恢复！')) return;

            const data = new FormData();
            data.append('action', 'delete_project');
            data.append('id', id);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast(data.message, 'success');
                        loadProjects(1);
                    } else {
                        showToast(data.message || '删除失败', 'error');
                    }
                })
                .catch(err => showToast('删除失败', 'error'));
        }

        // ============================================================
        // 打开新增Modal
        // ============================================================
        document.getElementById('addProjectBtn').addEventListener('click', function() {
            isEditMode = false;
            editId.value = '';
            modalTitle.textContent = '发布项目';
            formTitle.value = '';
            formDesc.value = '';
            formLevel.value = '';
            formSubject.value = '';
            formTags.value = '';
            formIcon.value = 'fa-seedling';
            formHot.value = '0';
            formPick.value = '0';
            formSort.value = '0';
            modal.classList.add('active');
        });

        // ============================================================
        // 打开编辑Modal
        // ============================================================
        function openEditModal(id) {
            const data = new FormData();
            data.append('action', 'get_project');
            data.append('id', id);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const p = data.data.project;
                        isEditMode = true;
                        editId.value = p.pID;
                        modalTitle.textContent = '编辑项目';
                        formTitle.value = p.title || '';
                        formDesc.value = p.description || '';
                        formLevel.value = p.level || '';
                        formSubject.value = p.subject || '';
                        formTags.value = p.tags || '';
                        formIcon.value = p.icon || 'fa-seedling';
                        formHot.value = p.is_hot || '0';
                        formPick.value = p.is_pick || '0';
                        formSort.value = p.sort_order || '0';
                        modal.classList.add('active');
                    } else {
                        showToast(data.message || '加载失败', 'error');
                    }
                })
                .catch(err => showToast('加载失败', 'error'));
        }

        // ============================================================
        // Modal 关闭
        // ============================================================
        function closeModal() {
            modal.classList.remove('active');
        }
        document.getElementById('modalClose').addEventListener('click', closeModal);
        document.getElementById('formCancel').addEventListener('click', closeModal);
        modal.addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });

        // ============================================================
        // 保存项目
        // ============================================================
        document.getElementById('formSubmit').addEventListener('click', function() {
            const id = editId.value;
            const title = formTitle.value.trim();
            const description = formDesc.value.trim();
            const level = formLevel.value;
            const subject = formSubject.value;
            const tags = formTags.value.trim();
            const icon = formIcon.value;
            const is_hot = parseInt(formHot.value);
            const is_pick = parseInt(formPick.value);
            const sort_order = parseInt(formSort.value) || 0;

            if (!title) { showToast('请输入项目名称', 'error'); return; }
            if (!description) { showToast('请输入项目描述', 'error'); return; }
            if (!level) { showToast('请选择学段', 'error'); return; }
            if (!subject) { showToast('请选择学科', 'error'); return; }

            const data = new FormData();
            data.append('action', id ? 'update_project' : 'add_project');
            data.append('id', id);
            data.append('title', title);
            data.append('description', description);
            data.append('level', level);
            data.append('subject', subject);
            data.append('tags', tags);
            data.append('icon', icon);
            data.append('is_hot', is_hot);
            data.append('is_pick', is_pick);
            data.append('sort_order', sort_order);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast(data.message, 'success');
                        closeModal();
                        loadProjects(1);
                    } else {
                        showToast(data.message || '保存失败', 'error');
                    }
                })
                .catch(err => showToast('保存失败', 'error'));
        });

        // ============================================================
        // 筛选事件
        // ============================================================
        document.getElementById('filterLevel').addEventListener('change', () => loadProjects(1));
        document.getElementById('filterSubject').addEventListener('change', () => loadProjects(1));
        document.getElementById('filterSort').addEventListener('change', () => loadProjects(1));
        document.getElementById('searchKeyword').addEventListener('input', debounce(() => loadProjects(1), 400));

        function debounce(fn, delay) {
            let timer;
            return function() {
                clearTimeout(timer);
                timer = setTimeout(fn, delay);
            };
        }

        // ============================================================
        // 初始化
        // ============================================================
        loadProjects(1);
    });
    </script>

</body>
</html>