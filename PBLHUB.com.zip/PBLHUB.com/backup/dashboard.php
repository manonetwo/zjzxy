<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

requireLogin();

$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 首页</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #eef5ff 0%, #cfe3ff 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: rgba(255,255,255,0.95);
            border-radius: 2rem;
            padding: 2.5rem;
            box-shadow: 0 25px 45px -12px rgba(0,20,50,0.25);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #eef3fc;
            padding-bottom: 1.2rem;
            margin-bottom: 1.8rem;
            flex-wrap: wrap;
            gap: 0.8rem;
        }
        .header h1 {
            color: #0a2b4e;
            font-size: 1.8rem;
            font-weight: 800;
        }
        .header h1 span {
            background: linear-gradient(135deg, #1a4c7a, #2c7be5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .user-area {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .user-badge {
            background: #eef3fc;
            padding: 0.5rem 1.2rem;
            border-radius: 2rem;
            font-size: 0.9rem;
            font-weight: 500;
            color: #1a4c7a;
        }
        .logout-btn {
            background: #d9534f;
            color: white;
            border: none;
            padding: 0.5rem 1.4rem;
            border-radius: 2rem;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.85rem;
            transition: 0.2s;
            text-decoration: none;
            display: inline-block;
        }
        .logout-btn:hover {
            background: #c9302c;
            transform: translateY(-1px);
        }
        .welcome {
            font-size: 1.4rem;
            color: #0a2b4e;
            font-weight: 600;
            margin-bottom: 0.3rem;
        }
        .meta {
            color: #6c86a3;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.2rem;
            margin-top: 1.5rem;
        }
        .feature-card {
            background: #f8fafc;
            padding: 1.5rem 1.2rem;
            border-radius: 1.2rem;
            border: 1px solid #e8edf5;
            transition: 0.2s;
            cursor: default;
        }
        .feature-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }
        .feature-card .icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        .feature-card h3 {
            color: #0a2b4e;
            font-size: 1rem;
            margin-bottom: 0.3rem;
        }
        .feature-card p {
            color: #6c86a3;
            font-size: 0.85rem;
            margin: 0;
        }
        @media (max-width: 600px) {
            .container { padding: 1.5rem; }
            .header h1 { font-size: 1.4rem; }
            .features-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📚 <span>PBL HUB</span></h1>
            <div class="user-area">
                <span class="user-badge">👋 <?php echo htmlspecialchars($user['username'] ?? '用户'); ?></span>
                <a href="logout.php" class="logout-btn">退出登录</a>
            </div>
        </div>
        
        <div class="welcome">欢迎回来，<?php echo htmlspecialchars($user['username'] ?? '用户'); ?>！</div>
        <div class="meta">
            <?php if (!empty($user['email'])): ?>
                📧 <?php echo htmlspecialchars($user['email']); ?>
            <?php endif; ?>
            <?php if (!empty($user['phone'])): ?>
                ｜ 📱 <?php echo htmlspecialchars($user['phone']); ?>
            <?php endif; ?>
            ｜ 加入于 <?php echo date('Y-m-d', strtotime($user['created_at'] ?? 'now')); ?>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="icon">📖</div>
                <h3>我的项目</h3>
                <p>查看你参与的所有项目</p>
            </div>
            <div class="feature-card">
                <div class="icon">🤝</div>
                <h3>协作空间</h3>
                <p>与团队成员实时协作</p>
            </div>
            <div class="feature-card">
                <div class="icon">📊</div>
                <h3>学习进度</h3>
                <p>追踪你的学习成长轨迹</p>
            </div>
            <div class="feature-card">
                <div class="icon">🏆</div>
                <h3>成果展示</h3>
                <p>展示你的项目成果</p>
            </div>
        </div>
    </div>
</body>
</html>