<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';

// 模拟 POST 请求
$_POST['action'] = 'get_projects';
$_POST['page'] = 1;

// 直接执行 resources.php 中的逻辑
$action = $_POST['action'];

if ($action === 'get_projects') {
    $page = intval($_POST['page'] ?? 1);
    $limit = 12;
    $offset = ($page - 1) * $limit;
    
    $countSql = "SELECT COUNT(*) as total FROM projects WHERE status = 1";
    $countResult = $conn->query($countSql);
    $total = 0;
    if ($countResult) {
        $row = $countResult->fetch_assoc();
        $total = intval($row['total'] ?? 0);
    }
    
   $sql = "SELECT p.*, 
        (SELECT username FROM users WHERE id = p.author_id) as username,
        (SELECT real_name FROM users WHERE id = p.author_id) as real_name
        FROM projects p 
        WHERE status = 1 
        ORDER BY p.created_at DESC 
        LIMIT $limit OFFSET $offset";
    $result = $conn->query($sql);
    $projects = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'data' => [
            'projects' => $projects,
            'total' => $total,
            'page' => $page,
            'total_pages' => $total > 0 ? ceil($total / $limit) : 1
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}