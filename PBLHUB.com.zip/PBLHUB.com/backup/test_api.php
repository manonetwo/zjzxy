<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';

// ============================================================
// 调试：检查连接
// ============================================================
if ($conn->connect_error) {
    die("❌ 数据库连接失败: " . $conn->connect_error);
}
echo "✅ 数据库连接成功<br>";

// ============================================================
// 调试：直接执行简单查询
// ============================================================
$sql = "SELECT COUNT(*) as total FROM projects";
$result = $conn->query($sql);
if ($result === false) {
    die("❌ 查询失败: " . $conn->error);
}
$row = $result->fetch_assoc();
echo "📊 总记录数: " . $row['total'] . "<br>";

// ============================================================
// 调试：查询所有数据（不加 WHERE）
// ============================================================
$sql = "SELECT p.*, u.username, u.real_name 
        FROM projects p 
        LEFT JOIN users u ON p.author_id = u.id";
$result = $conn->query($sql);
if ($result === false) {
    die("❌ 查询失败: " . $conn->error);
}

$projects = [];
while ($row = $result->fetch_assoc()) {
    $projects[] = $row;
}

echo "📊 查询到 " . count($projects) . " 条数据<br>";

// ============================================================
// 输出 JSON
// ============================================================
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'data' => [
        'projects' => $projects,
        'total' => count($projects)
    ]
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);