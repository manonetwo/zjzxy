<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 获取当前用户
$user = null;
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}

function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// 获取课程ID
$course_id = intval($_GET['cid'] ?? 0);
if (!$course_id) {
    header('Location: courses.php');
    exit;
}

// 查询课程信息
$sql = "SELECT c.*, u.username, u.real_name 
        FROM courses c 
        LEFT JOIN users u ON c.uploader_id = u.id 
        WHERE c.cID = $course_id";
$result = $conn->query($sql);
$course = $result ? $result->fetch_assoc() : null;

if (!$course) {
    header('Location: courses.php');
    exit;
}

// 查询章节列表
$sql = "SELECT * FROM course_lessons WHERE course_id = $course_id ORDER BY sort_order ASC";
$result = $conn->query($sql);
$lessons = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $lessons[] = $row;
    }
}

// 获取第一个章节作为默认播放
$firstLesson = !empty($lessons) ? $lessons[0] : null;

// 获取用户学习进度（如果有登录）
$userProgress = 0;
if ($isLoggedIn) {
    $progressResult = $conn->query("SELECT progress FROM course_progress WHERE user_id = {$user['id']} AND course_id = $course_id");
    if ($progressResult && $progressResult->num_rows > 0) {
        $row = $progressResult->fetch_assoc();
        $userProgress = floatval($row['progress']);
    }
}

// 计算总时长
$totalDuration = 0;
foreach ($lessons as $l) {
    $totalDuration += intval($l['duration']);
}

// 格式化时长
function formatDuration($seconds) {
    if ($seconds <= 0) return '00:00';
    $mins = floor($seconds / 60);
    $secs = $seconds % 60;
    return sprintf('%02d:%02d', $mins, $secs);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · <?php echo htmlspecialchars($course['cTitle']); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; }
        :root {
            --primary: #2563eb; --primary-hover: #1d4ed8; --primary-light: #dbeafe;
            --bg: #f6f9fc; --card-bg: #ffffff; --text-dark: #0f172a;
            --text-mid: #475569; --text-light: #94a3b8; --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0,0,0,0.04); --shadow-hover: 0 12px 32px rgba(0,0,0,0.08);
            --radius: 20px; --radius-sm: 12px; --transition: 0.25s ease;
            --green: #22c55e; --green-light: #dcfce7;
        }
        body { background: var(--bg); color: var(--text-dark); line-height: 1.6; min-height: 100vh; }
        .container { max-width: 1360px; margin: 0 auto; padding: 0 1.8rem; }

        .navbar {
            background: rgba(255,255,255,0.90); backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0,0,0,0.04); padding: 0.6rem 0;
            position: sticky; top: 0; z-index: 100; border-bottom: 1px solid var(--border);
        }
        .navbar .container {
            display: flex; align-items: center; justify-content: space-between;
            flex-wrap: wrap; gap: 0.6rem;
        }
        .logo {
            display: flex; align-items: center; gap: 0.5rem;
            font-size: 1.6rem; font-weight: 700; color: var(--primary);
            text-decoration: none;
        }
        .logo i { font-size: 2rem; }
        .logo span { font-weight: 300; color: var(--text-light); font-size: 0.85rem; }
        .nav-links {
            display: flex; gap: 2rem; align-items: center; flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none; color: var(--text-mid); font-weight: 500;
            font-size: 1rem; padding: 0.3rem 0;
            border-bottom: 2.5px solid transparent; transition: var(--transition);
            cursor: pointer;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active { color: var(--primary); border-bottom-color: var(--primary); }
        .nav-right {
            display: flex; align-items: center; gap: 1.2rem; flex-wrap: wrap;
        }

        .avatar {
            width: 36px; height: 36px; background: var(--primary-light);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: var(--primary); font-weight: 600; font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info { display: flex; flex-direction: column; line-height: 1.2; }
        .user-info .name { font-weight: 600; font-size: 0.9rem; color: var(--text-dark); }
        .user-info .role { font-size: 0.65rem; color: var(--text-light); }
        .logout-link {
            color: var(--text-light); font-size: 0.8rem; transition: var(--transition);
            display: flex; align-items: center; gap: 0.2rem; text-decoration: none;
            background: none; border: none; cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }
        .login-link {
            color: var(--primary); font-size: 0.9rem; font-weight: 600;
            text-decoration: none; padding: 0.4rem 1.2rem;
            border: 2px solid var(--primary); border-radius: 30px; transition: var(--transition);
        }
        .login-link:hover { background: var(--primary); color: #fff; }

        .breadcrumb {
            display: flex; align-items: center; gap: 0.5rem;
            font-size: 0.85rem; color: var(--text-light);
            padding: 0.8rem 0 1.2rem 0;
        }
        .breadcrumb a { color: var(--text-mid); text-decoration: none; transition: var(--transition); }
        .breadcrumb a:hover { color: var(--primary); }
        .breadcrumb .separator { color: var(--text-light); }
        .breadcrumb .current { color: var(--text-dark); font-weight: 500; }

        .learning-layout {
            display: grid;
            grid-template-columns: 1fr 360px;
            gap: 1.8rem;
            margin-bottom: 2rem;
        }

        .video-section {
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            overflow: hidden;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
        }

        .video-player {
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            background: #0f172a;
            position: relative;
        }
        .video-wrapper {
            aspect-ratio: 16 / 9;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            flex-shrink: 0;
            background: #0f172a;
            overflow: hidden;
        }
        .video-wrapper video {
            width: 100%;
            height: 100%;
            object-fit: contain;
            background: #0f172a;
        }
        .video-wrapper .video-placeholder {
            color: rgba(255,255,255,0.3);
            font-size: 5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            position: absolute;
        }
        .video-wrapper .video-placeholder span {
            font-size: 0.9rem;
            font-weight: 500;
            color: rgba(255,255,255,0.5);
        }
        .video-wrapper .play-btn-overlay {
            position: absolute;
            width: 80px;
            height: 80px;
            background: rgba(37,99,235,0.85);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 2.2rem;
            cursor: pointer;
            transition: var(--transition);
            border: 2px solid rgba(255,255,255,0.2);
            z-index: 10;
        }
        .video-wrapper .play-btn-overlay:hover {
            transform: scale(1.08);
            background: rgba(37,99,235,1);
        }

        .video-info {
            padding: 1.2rem 1.5rem 1.5rem;
            flex-shrink: 0;
            background: var(--card-bg);
        }
        .video-info .title-row {
            display: flex; justify-content: space-between; align-items: flex-start;
            gap: 1rem; flex-wrap: wrap;
        }
        .video-info .title-row h2 {
            font-size: 1.3rem; font-weight: 700; color: var(--text-dark); flex: 1;
        }
        .video-info .title-row .actions {
            display: flex; gap: 0.6rem; flex-wrap: wrap;
        }
        .video-info .title-row .actions button {
            padding: 0.3rem 1rem; border-radius: 30px; font-size: 0.8rem;
            font-weight: 600; border: 1px solid var(--border);
            background: var(--bg); color: var(--text-mid);
            cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 0.3rem;
        }
        .video-info .title-row .actions button:hover {
            border-color: var(--primary); color: var(--primary); background: var(--primary-light);
        }
        .video-info .meta-row {
            display: flex; gap: 1.2rem; flex-wrap: wrap; margin-top: 0.6rem;
            font-size: 0.85rem; color: var(--text-mid);
        }
        .video-info .meta-row span i { margin-right: 0.3rem; color: var(--text-light); }
        .video-info .meta-row .tag {
            background: var(--primary-light); color: var(--primary);
            padding: 0.05rem 0.8rem; border-radius: 30px; font-size: 0.7rem; font-weight: 600;
        }
        .video-info .desc {
            margin-top: 0.8rem; font-size: 0.9rem; color: var(--text-mid);
            line-height: 1.7; padding-top: 0.8rem; border-top: 1px solid var(--border);
        }

        .sidebar-section { display: flex; flex-direction: column; }
        .course-sidebar {
            background: var(--card-bg); border-radius: var(--radius);
            border: 1px solid var(--border); overflow: hidden;
            box-shadow: var(--shadow); flex: 1; display: flex; flex-direction: column;
        }
        .sidebar-header {
            padding: 1rem 1.2rem 0.6rem; border-bottom: 1px solid var(--border);
            flex-shrink: 0;
        }
        .sidebar-header h3 {
            font-size: 1rem; font-weight: 700; color: var(--text-dark);
            display: flex; align-items: center; gap: 0.5rem;
        }
        .sidebar-header h3 .count { font-weight: 400; font-size: 0.8rem; color: var(--text-light); }
        .sidebar-header .progress-summary {
            display: flex; justify-content: space-between; align-items: center;
            font-size: 0.78rem; color: var(--text-mid); margin-top: 0.3rem;
        }
        .sidebar-header .progress-summary .bar-wrap {
            flex: 1; height: 4px; background: var(--border);
            border-radius: 4px; margin: 0 0.8rem 0 0.6rem;
        }
        .sidebar-header .progress-summary .bar-wrap .fill {
            height: 100%; background: var(--primary); border-radius: 4px;
            width: <?php echo $userProgress; ?>%;
        }
        .sidebar-header .progress-summary .pct {
            font-weight: 600; color: var(--primary); flex-shrink: 0;
        }

        .chapter-list {
            padding: 0.4rem 0.6rem 0.8rem;
            flex: 1; overflow-y: auto; max-height: 500px;
        }
        .chapter-list::-webkit-scrollbar { width: 4px; }
        .chapter-list::-webkit-scrollbar-track { background: var(--bg); border-radius: 4px; }
        .chapter-list::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

        .chapter-item {
            display: flex; align-items: center; gap: 0.8rem;
            padding: 0.5rem 0.6rem; border-radius: var(--radius-sm);
            cursor: pointer; transition: var(--transition);
            border-left: 3px solid transparent;
        }
        .chapter-item:hover { background: var(--bg); }
        .chapter-item.active { background: var(--primary-light); border-left-color: var(--primary); }
        .chapter-item.active .ch-title { color: var(--primary); font-weight: 600; }
        .chapter-item .ch-index {
            width: 28px; height: 28px; border-radius: 50%;
            background: var(--bg); display: flex; align-items: center; justify-content: center;
            font-size: 0.7rem; font-weight: 600; color: var(--text-mid);
            flex-shrink: 0; border: 1px solid var(--border);
        }
        .chapter-item.active .ch-index { background: var(--primary); color: #fff; border-color: var(--primary); }
        .chapter-item .ch-info { flex: 1; min-width: 0; }
        .chapter-item .ch-title {
            font-size: 0.85rem; font-weight: 500; color: var(--text-dark);
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .chapter-item .ch-meta {
            font-size: 0.7rem; color: var(--text-light);
            display: flex; gap: 0.6rem; align-items: center;
        }
        .chapter-item .ch-duration {
            font-size: 0.7rem; color: var(--text-light); flex-shrink: 0;
        }
        .chapter-item .ch-status {
            font-size: 0.6rem; font-weight: 600; padding: 0.05rem 0.6rem;
            border-radius: 30px; flex-shrink: 0;
        }
        .ch-status.done { background: var(--green-light); color: var(--green); }
        .ch-status.current { background: var(--primary-light); color: var(--primary); }
        .ch-status.locked { background: var(--bg); color: var(--text-light); }

        .footer {
            background: var(--card-bg); border-top: 1px solid var(--border);
            padding: 2rem 0; margin-top: 2rem;
        }
        .footer .container {
            display: flex; justify-content: space-between; flex-wrap: wrap; gap: 1.5rem;
        }
        .footer .col {
            display: flex; flex-direction: column; gap: 0.3rem;
            font-size: 0.9rem; color: var(--text-mid);
        }
        .footer .col strong { color: var(--text-dark); font-weight: 600; }
        .footer .col i { margin-right: 0.4rem; color: var(--primary); width: 1.2rem; text-align: center; }
        .footer .col a { color: var(--text-mid); text-decoration: none; transition: var(--transition); }
        .footer .col a:hover { color: var(--primary); }
        .footer .bottom {
            text-align: center; margin-top: 1.2rem; font-size: 0.8rem;
            color: var(--text-light); border-top: 1px solid var(--border); padding-top: 1rem;
        }

        @media (max-width: 1024px) {
            .navbar .container { flex-direction: column; gap: 0.5rem; }
            .nav-links { justify-content: center; }
            .learning-layout { grid-template-columns: 1fr; }
            .chapter-list { max-height: 400px; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .nav-right { width: 100%; justify-content: center; flex-wrap: wrap; }
            .nav-links { gap: 1rem; }
            .nav-links a { font-size: 0.85rem; }
            .video-wrapper .play-btn-overlay { width: 60px; height: 60px; font-size: 1.6rem; }
            .chapter-list { max-height: 350px; }
        }
        @media (max-width: 480px) {
            .nav-links a { font-size: 0.75rem; }
            .video-wrapper .video-placeholder { font-size: 3rem; }
            .video-info { padding: 0.8rem 1rem 1.2rem; }
            .video-info .title-row h2 { font-size: 1.05rem; }
            .avatar { width: 30px; height: 30px; font-size: 0.75rem; }
            .user-info .name { font-size: 0.8rem; }
            .chapter-list { max-height: 300px; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="container">
            <a href="home.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· 项目式学习中心</span>
            </a>
            <div class="nav-links">
                <a href="home.php">首页</a>
                <a href="resources.php">PBL资源库</a>
                <a href="courses.php" class="active">课程中心</a>
                <a href="community.php">教师社区</a>
                <a href="profile.php">个人中心</a>
            </div>
            <div class="nav-right">
                <?php if ($isLoggedIn && $user): ?>
                    <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                    <div class="user-info">
                        <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                        <span class="role"><?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                    </div>
                    <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="index.php" class="login-link"><i class="fas fa-sign-in-alt"></i> 登录</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="container">

        <div class="breadcrumb">
            <a href="home.php">首页</a>
            <span class="separator">/</span>
            <a href="courses.php">课程中心</a>
            <span class="separator">/</span>
            <span class="current"><?php echo htmlspecialchars($course['cTitle']); ?></span>
        </div>

        <div class="learning-layout">

            <div class="video-section">

                <div class="video-player" id="videoPlayer">
                    <div class="video-wrapper" id="videoWrapper">
                        <?php if ($firstLesson && !empty($firstLesson['video_url'])): ?>
                            <video id="mainVideo" controls style="width:100%;height:100%;">
                                <source src="<?php echo htmlspecialchars($firstLesson['video_url']); ?>" type="video/mp4">
                                您的浏览器不支持视频播放
                            </video>
                        <?php else: ?>
                            <div class="video-placeholder">
                                <i class="fas fa-play-circle"></i>
                                <span>暂无视频，请上传课程视频</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="video-info">
                    <div class="title-row">
                        <h2 id="lessonTitle"><?php echo htmlspecialchars($firstLesson['title'] ?? $course['cTitle']); ?></h2>
                        <div class="actions">
                            <button id="favoriteBtn"><i class="far fa-star"></i> 收藏</button>
                            <button id="shareBtn"><i class="fas fa-share-alt"></i> 分享</button>
                        </div>
                    </div>
                    <div class="meta-row">
                        <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($course['real_name'] ?? $course['username'] ?? '未知'); ?></span>
                        <span><i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($course['level'] ?? '不限'); ?></span>
                        <span><i class="fas fa-book"></i> <?php echo htmlspecialchars($course['subject'] ?? '不限'); ?></span>
                        <span><i class="far fa-clock"></i> 共 <?php echo count($lessons); ?> 课时</span>
                        <span><i class="fas fa-users"></i> <?php echo $course['learners'] ?? 0; ?> 人学习</span>
                        <span class="tag"><?php echo getStatusLabel($course['status']); ?></span>
                    </div>
                    <div class="desc"><?php echo htmlspecialchars($course['description'] ?? '暂无课程描述'); ?></div>
                </div>
            </div>

            <div class="sidebar-section">
                <div class="course-sidebar">
                    <div class="sidebar-header">
                        <h3>课程目录 <span class="count">(<?php echo count($lessons); ?> 课时)</span></h3>
                        <div class="progress-summary">
                            <span>学习进度</span>
                            <div class="bar-wrap"><div class="fill" style="width:<?php echo $userProgress; ?>%;"></div></div>
                            <span class="pct"><?php echo round($userProgress); ?>%</span>
                        </div>
                    </div>
                    <div class="chapter-list" id="chapterList">
                        <?php foreach ($lessons as $index => $lesson): ?>
                        <div class="chapter-item <?php echo $index === 0 ? 'active' : ''; ?>" data-id="<?php echo $lesson['id']; ?>" data-video="<?php echo htmlspecialchars($lesson['video_url']); ?>" data-title="<?php echo htmlspecialchars($lesson['title']); ?>">
                            <div class="ch-index"><?php echo str_pad($index + 1, 2, '0', STR_PAD_LEFT); ?></div>
                            <div class="ch-info">
                                <div class="ch-title"><?php echo htmlspecialchars($lesson['title']); ?></div>
                                <div class="ch-meta">
                                    <?php if ($index === 0): ?>
                                        <span class="ch-status current">当前</span>
                                    <?php endif; ?>
                                    <span><?php echo formatDuration($lesson['duration']); ?></span>
                                </div>
                            </div>
                            <div class="ch-duration"><i class="far fa-clock"></i> <?php echo formatDuration($lesson['duration']); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

        </div>

    </main>

    <footer class="footer">
        <div class="container">
            <div class="col">
                <strong>PBL HUB</strong>
                <span>项目式学习教师研修社区</span>
                <span><i class="fas fa-map-marker-alt"></i> 兰州市 · 教育创新中心</span>
            </div>
            <div class="col">
                <strong>关于我们</strong>
                <span><i class="fas fa-envelope"></i> contact@pblhub.edu</span>
                <span><i class="fas fa-users"></i> 成员：张老师、李老师、王老师</span>
            </div>
            <div class="col">
                <strong>快速链接</strong>
                <a href="home.php"><i class="fas fa-home"></i> 首页</a>
                <a href="profile.php"><i class="fas fa-user"></i> 个人中心</a>
            </div>
        </div>
        <div class="bottom">© <?php echo date('Y'); ?> PBL HUB · 项目式学习中心</div>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {

        const chapterItems = document.querySelectorAll('.chapter-item');
        const mainVideo = document.getElementById('mainVideo');
        const lessonTitle = document.getElementById('lessonTitle');

        // 点击章节切换视频
        chapterItems.forEach(function(item) {
            item.addEventListener('click', function() {
                const videoUrl = this.dataset.video;
                const title = this.dataset.title;

                // 更新激活状态
                chapterItems.forEach(function(el) { el.classList.remove('active'); });
                this.classList.add('active');

                // 更新视频标题
                lessonTitle.textContent = title;

                // 更新视频源
                if (mainVideo && videoUrl) {
                    mainVideo.src = videoUrl;
                    mainVideo.load();
                    mainVideo.play().catch(function(e) { console.log('自动播放被阻止'); });
                }
            });
        });

        // 收藏按钮
        let isFavorited = false;
        document.getElementById('favoriteBtn').addEventListener('click', function() {
            isFavorited = !isFavorited;
            this.classList.toggle('favorited');
            this.innerHTML = isFavorited ?
                '<i class="fas fa-star"></i> 已收藏' :
                '<i class="far fa-star"></i> 收藏';
            if (isFavorited) {
                alert('❤️ 已收藏课程');
            } else {
                alert('已取消收藏');
            }
        });

        // 分享按钮
        document.getElementById('shareBtn').addEventListener('click', function() {
            alert('🔗 分享链接已复制（模拟）\nhttps://pblhub.edu.cn/course/<?php echo $course_id; ?>');
        });

        // 自动播放第一个视频
        if (mainVideo && mainVideo.src) {
            mainVideo.play().catch(function(e) { console.log('自动播放被阻止，请点击播放'); });
        }

    });
    </script>

</body>
</html>