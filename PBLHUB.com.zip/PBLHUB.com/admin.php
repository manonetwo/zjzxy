<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 检查是否登录
requireLogin();

// 获取当前用户
$user = getCurrentUser();

// 检查角色：只有 admin 和 expert 可以访问
$allowedRoles = ['admin', 'expert'];
if (!in_array($user['role'] ?? '', $allowedRoles)) {
    header('Location: home.php');
    exit;
}

// 获取角色中文名
function getRoleName($role) {
    $map = ['admin' => '管理员', 'expert' => '专家', 'student' => '学生'];
    return $map[$role] ?? $role;
}

function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// 获取用户角色标签样式
function getRoleBadgeClass($role) {
    $map = ['admin' => 'admin-badge', 'expert' => 'expert-badge', 'student' => 'student-badge'];
    return $map[$role] ?? '';
}

// ============================================================
// 处理 AJAX 请求（统计数据和待审核列表）
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // ---------- 获取统计数据 ----------
    if ($action === 'get_stats') {
        // 查询总数
        $userCount = 0;
        $courseCount = 0;
        $projectCount = 0;
        $postCount = 0;
        $pendingCount = 0;
        
        $result = $conn->query("SELECT COUNT(*) as total FROM users");
        if ($result) { $row = $result->fetch_assoc(); $userCount = intval($row['total'] ?? 0); }
        
        $result = $conn->query("SELECT COUNT(*) as total FROM courses");
        if ($result) { $row = $result->fetch_assoc(); $courseCount = intval($row['total'] ?? 0); }
        
        $result = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status = 1");
        if ($result) { $row = $result->fetch_assoc(); $projectCount = intval($row['total'] ?? 0); }
        
        $result = $conn->query("SELECT COUNT(*) as total FROM posts");
        if ($result) { $row = $result->fetch_assoc(); $postCount = intval($row['total'] ?? 0); }
        
        $result = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status = 0");
        if ($result) { $row = $result->fetch_assoc(); $pendingCount = intval($row['total'] ?? 0); }
        
        jsonResponse(true, '获取成功', [
            'userCount' => $userCount,
            'courseCount' => $courseCount,
            'projectCount' => $projectCount,
            'postCount' => $postCount,
            'pendingCount' => $pendingCount
        ]);
    }
    
    // ---------- 获取待审核列表 ----------
    if ($action === 'get_pending') {
        $sql = "SELECT p.*, u.username, u.real_name 
                FROM projects p 
                LEFT JOIN users u ON p.author_id = u.id 
                WHERE p.status = 0 
                ORDER BY p.created_at DESC 
                LIMIT 10";
        $result = $conn->query($sql);
        $pending = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $pending[] = $row;
            }
        }
        jsonResponse(true, '获取成功', ['pending' => $pending]);
    }
    
    // ---------- 审核操作 ----------
    if ($action === 'approve_project') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '项目ID不能为空');
        
        $sql = "UPDATE projects SET status = 1, updated_at = NOW() WHERE pID = $id";
        if ($conn->query($sql)) {
            jsonResponse(true, '审核通过');
        } else {
            jsonResponse(false, '操作失败：' . $conn->error);
        }
    }
    
    if ($action === 'reject_project') {
        if (!$isLoggedIn) jsonResponse(false, '请先登录');
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(false, '项目ID不能为空');
        
        $sql = "DELETE FROM projects WHERE pID = $id";
        if ($conn->query($sql)) {
            jsonResponse(true, '已驳回并删除');
        } else {
            jsonResponse(false, '操作失败：' . $conn->error);
        }
    }
    
    jsonResponse(false, '无效操作');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 管理控制台</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --primary-light: #dbeafe;
            --primary-bg: #f0f7ff;
            --bg: #f6f9fc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-mid: #475569;
            --text-light: #94a3b8;
            --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 12px 32px rgba(0, 0, 0, 0.08);
            --radius: 20px;
            --radius-sm: 12px;
            --transition: 0.25s ease;
            --admin-accent: #7c3aed;
            --admin-accent-light: #ede9fe;
        }

        body {
            background: var(--bg);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1440px;
            margin: 0 auto;
            padding: 0 1.8rem;
        }

        /* ===== 导航栏 ===== */
        .navbar {
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            padding: 0.6rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 2px solid var(--admin-accent);
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.6rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            flex-shrink: 0;
        }
        .logo i { font-size: 2rem; }
        .logo span {
            font-weight: 300;
            color: var(--text-light);
            font-size: 0.85rem;
            margin-left: 0.1rem;
        }

        .nav-links {
            display: flex;
            gap: 0.8rem;
            align-items: center;
            flex-wrap: wrap;
            justify-content: center;
            flex: 1;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-mid);
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.3rem 0.8rem;
            border-bottom: 2.5px solid transparent;
            transition: var(--transition);
            cursor: pointer;
            white-space: nowrap;
        }
        .nav-links a:hover { color: var(--primary); }
        .nav-links a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            flex-shrink: 0;
        }

        .avatar {
            width: 36px;
            height: 36px;
            background: var(--admin-accent-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--admin-accent);
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-info .name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .user-info .role {
            font-size: 0.65rem;
            color: var(--admin-accent);
            font-weight: 500;
        }
        .logout-link {
            color: var(--text-light);
            font-size: 0.8rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.2rem;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
        }
        .logout-link:hover { color: #ef4444; }

        /* ===== 管理员主布局 ===== */
        .admin-layout {
            display: grid;
            grid-template-columns: 240px 1fr;
            gap: 2rem;
            padding: 1.5rem 0 2.5rem;
            min-height: 70vh;
        }

        /* ===== 左侧管理侧栏 ===== */
        .admin-sidebar {
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            padding: 1.2rem 0.6rem;
            height: fit-content;
            position: sticky;
            top: 5.5rem;
        }
        .admin-sidebar .sidebar-title {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-light);
            padding: 0.4rem 1rem 0.6rem;
            font-weight: 600;
        }
        .admin-sidebar .menu-item {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.6rem 1rem;
            border-radius: var(--radius-sm);
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            font-size: 0.9rem;
            margin: 0.1rem 0;
        }
        .admin-sidebar .menu-item i {
            width: 1.4rem;
            text-align: center;
            font-size: 1rem;
            color: var(--text-light);
        }
        .admin-sidebar .menu-item:hover {
            background: var(--primary-bg);
            color: var(--primary);
        }
        .admin-sidebar .menu-item:hover i { color: var(--primary); }
        .admin-sidebar .menu-item.active {
            background: var(--primary-light);
            color: var(--primary);
            font-weight: 600;
        }
        .admin-sidebar .menu-item.active i { color: var(--primary); }
        .admin-sidebar .menu-item .badge {
            margin-left: auto;
            background: #fee2e2;
            color: #dc2626;
            font-size: 0.6rem;
            padding: 0.1rem 0.6rem;
            border-radius: 30px;
            font-weight: 600;
        }
        .admin-sidebar .menu-item .badge.success {
            background: #d1fae5;
            color: #059669;
        }
        .admin-sidebar .menu-item .badge.warning {
            background: #fef3c7;
            color: #d97706;
        }
        .admin-sidebar .divider {
            height: 1px;
            background: var(--border);
            margin: 0.6rem 1rem;
        }

        /* ===== 右侧主内容 ===== */
        .admin-main {
            display: flex;
            flex-direction: column;
            gap: 1.8rem;
        }

        /* 统计卡片 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 1rem;
        }
        .stat-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.2rem 1.4rem;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
        }
        .stat-card .stat-label {
            font-size: 0.8rem;
            color: var(--text-light);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }
        .stat-card .stat-number {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--text-dark);
            line-height: 1.2;
            margin-top: 0.2rem;
        }
        .stat-card .stat-icon {
            float: right;
            font-size: 2rem;
            color: var(--primary-light);
            opacity: 0.6;
        }
        .stat-card .stat-icon.purple { color: var(--admin-accent-light); }

        /* 内容卡片 */
        .admin-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        .admin-card .card-header {
            padding: 1.2rem 1.8rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.6rem;
        }
        .admin-card .card-header h3 {
            font-size: 1.05rem;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .admin-card .card-header h3 i { color: var(--primary); }
        .admin-card .card-header .actions {
            display: flex;
            gap: 0.6rem;
            align-items: center;
        }
        .admin-card .card-header .actions .btn-sm {
            padding: 0.25rem 1rem;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 500;
            border: 1px solid var(--border);
            background: var(--bg);
            color: var(--text-mid);
            cursor: pointer;
            transition: var(--transition);
        }
        .admin-card .card-header .actions .btn-sm:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--primary-light);
        }
        .admin-card .card-header .actions .btn-sm.primary {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }
        .admin-card .card-header .actions .btn-sm.primary:hover {
            background: var(--primary-hover);
        }
        .admin-card .card-body {
            padding: 1.2rem 1.8rem 1.8rem;
        }

        /* 待审核列表 */
        .review-list {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
        }
        .review-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.6rem 0.8rem;
            border-radius: var(--radius-sm);
            background: var(--bg);
            border: 1px solid var(--border);
            transition: var(--transition);
            flex-wrap: wrap;
        }
        .review-item:hover {
            border-color: var(--primary-light);
            background: var(--primary-bg);
        }
        .review-item .info {
            flex: 1;
            min-width: 150px;
        }
        .review-item .info .title {
            font-weight: 600;
            font-size: 0.92rem;
            color: var(--text-dark);
        }
        .review-item .info .meta {
            font-size: 0.78rem;
            color: var(--text-light);
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .review-item .info .meta i { margin-right: 0.2rem; }
        .review-item .actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        .review-item .actions button {
            padding: 0.2rem 1rem;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: var(--transition);
        }
        .review-item .actions .btn-approve {
            background: #d1fae5;
            color: #059669;
        }
        .review-item .actions .btn-approve:hover {
            background: #059669;
            color: #fff;
        }
        .review-item .actions .btn-reject {
            background: #fee2e2;
            color: #dc2626;
        }
        .review-item .actions .btn-reject:hover {
            background: #dc2626;
            color: #fff;
        }
        .review-item .actions .btn-detail {
            background: var(--primary-light);
            color: var(--primary);
        }
        .review-item .actions .btn-detail:hover {
            background: var(--primary);
            color: #fff;
        }
        .review-item .badge-type {
            font-size: 0.6rem;
            padding: 0.1rem 0.6rem;
            border-radius: 30px;
            background: #fef3c7;
            color: #d97706;
            font-weight: 600;
        }

        /* ===== Toast ===== */
        .toast-container {
            position: fixed;
            top: 5rem;
            right: 2rem;
            z-index: 300;
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }
        .toast {
            background: var(--card-bg);
            padding: 0.8rem 1.6rem 0.8rem 1.2rem;
            border-radius: var(--radius-sm);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
            border-left: 4px solid var(--primary);
            display: flex;
            align-items: center;
            gap: 0.8rem;
            animation: slideIn 0.35s ease;
            min-width: 260px;
            font-size: 0.9rem;
            color: var(--text-dark);
            border: 1px solid var(--border);
        }
        .toast.success { border-left-color: #22c55e; }
        .toast.warning { border-left-color: #f59e0b; }
        .toast.error { border-left-color: #ef4444; }
        .toast .toast-icon { font-size: 1.2rem; }
        .toast.success .toast-icon { color: #22c55e; }
        .toast.warning .toast-icon { color: #f59e0b; }
        .toast.error .toast-icon { color: #ef4444; }
        .toast .toast-close {
            margin-left: auto;
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1.1rem;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* ===== 响应式 ===== */
        @media (max-width: 1024px) {
            .admin-layout { grid-template-columns: 1fr; }
            .admin-sidebar { position: static; display: flex; flex-wrap: wrap; gap: 0.2rem; padding: 0.8rem; }
            .admin-sidebar .sidebar-title { display: none; }
            .admin-sidebar .menu-item { padding: 0.4rem 0.8rem; font-size: 0.8rem; }
            .admin-sidebar .divider { display: none; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 1.2rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 0.6rem; }
            .stat-card .stat-number { font-size: 1.6rem; }
            .review-item { flex-direction: column; align-items: stretch; }
            .review-item .actions { justify-content: flex-end; }
            .nav-links a { font-size: 0.8rem; padding: 0.2rem 0.5rem; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .stat-card .stat-number { font-size: 1.2rem; }
            .admin-card .card-header { flex-direction: column; align-items: stretch; }
            .admin-card .card-header .actions { justify-content: flex-start; }
        }

        .empty-state {
            text-align: center;
            padding: 2rem 0;
            color: var(--text-light);
        }
        .empty-state i {
            font-size: 2.5rem;
            display: block;
            margin-bottom: 0.5rem;
            color: var(--primary-light);
        }
    </style>
</head>
<body>

    <!-- ===== 导航栏 ===== -->
    <nav class="navbar">
        <div class="container">
            <a href="admin.php" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· <?php echo $user['role'] === 'admin' ? '管理员' : '专家'; ?></span>
            </a>
            <div class="nav-links">
                <a class="active" href="admin.php">总控台</a>
                <a href="resources.php">资源库</a>
                <a href="courses.php">课程</a>
                <a href="community.php">社区</a>
            </div>
            <div class="nav-right">
                <div class="avatar"><?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?></div>
                <div class="user-info">
                    <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                    <span class="role"><i class="fas fa-<?php echo $user['role'] === 'admin' ? 'crown' : 'user-tie'; ?>"></i> <?php echo htmlspecialchars(getRoleName($user['role'] ?? 'student')); ?></span>
                </div>
                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
            </div>
        </div>
    </nav>

    <!-- ===== 主容器 ===== -->
    <main class="container">
        <div class="admin-layout">

            <!-- ===== 左侧管理菜单 ===== -->
            <aside class="admin-sidebar">
                <div class="sidebar-title">导航</div>
                <div class="menu-item active" data-page="overview"><i class="fas fa-gauge-high"></i> 总览</div>
                <div class="menu-item" onclick="location.href='admin_pending.php'"><i class="fas fa-clock-rotate-left"></i> 待审核 <span class="badge" id="pendingBadge">0</span></div>
                <div class="menu-item" onclick="location.href='admin_content.php'"></i> 内容管理</div>
                <div class="menu-item" data-page="users"><i class="fas fa-users"></i> 用户管理</div>
                <div class="divider"></div>
                <div class="menu-item" data-page="settings"><i class="fas fa-gear"></i> 系统设置</div>
                <div class="menu-item" data-page="home"><i class="fas fa-arrow-left"></i> 返回前台</div>
            </aside>

            <!-- ===== 右侧主内容 ===== -->
            <div class="admin-main">

                <!-- 统计卡片 -->
                <section class="stats-grid" id="statsGrid">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-users"></i></div>
                        <div class="stat-label"><i class="far fa-user"></i> 总用户</div>
                        <div class="stat-number" id="statUsers">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon purple"><i class="fas fa-graduation-cap"></i></div>
                        <div class="stat-label"><i class="far fa-file-alt"></i> 课程总数</div>
                        <div class="stat-number" id="statCourses">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-folder-open"></i></div>
                        <div class="stat-label"><i class="far fa-copy"></i> PBL案例</div>
                        <div class="stat-number" id="statProjects">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon purple"><i class="fas fa-comments"></i></div>
                        <div class="stat-label"><i class="far fa-message"></i> 社区帖子</div>
                        <div class="stat-number" id="statPosts">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-clock"></i></div>
                        <div class="stat-label"><i class="far fa-hourglass"></i> 待审核</div>
                        <div class="stat-number" id="statPending">0</div>
                    </div>
                </section>

                <!-- 待审核列表 -->
                <div class="admin-card">
                    <div class="card-header">
                        <h3><i class="fas fa-clock-rotate-left"></i> 待审核内容</h3>
                        <div class="actions">
                            <button class="btn-sm primary" id="refreshPendingBtn"><i class="fas fa-sync"></i> 刷新</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="review-list" id="pendingList">
                            <div class="empty-state">
                                <i class="fas fa-check-circle"></i>
                                <p>暂无待审核内容</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div><!-- end admin-main -->
        </div><!-- end admin-layout -->
    </main>

    <!-- ===== Toast 容器 ===== -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- ============================================================ -->
    <!-- ======================== JavaScript =========================== -->
    <!-- ============================================================ -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {

        // ============================================================
        // Toast 通知
        // ============================================================
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const icons = { success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML =
                `<span class="toast-icon"><i class="fas ${icons[type] || icons.success}"></i></span>
                <span>${message}</span>
                <button class="toast-close">&times;</button>`;
            container.appendChild(toast);
            toast.querySelector('.toast-close').addEventListener('click', () => { toast.remove(); });
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(40px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ============================================================
        // 加载统计数据
        // ============================================================
        function loadStats() {
            const data = new FormData();
            data.append('action', 'get_stats');

            fetch(window.location.href, {
                method: 'POST',
                body: data
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('statUsers').textContent = data.data.userCount;
                    document.getElementById('statCourses').textContent = data.data.courseCount;
                    document.getElementById('statProjects').textContent = data.data.projectCount;
                    document.getElementById('statPosts').textContent = data.data.postCount;
                    document.getElementById('statPending').textContent = data.data.pendingCount;
                    document.getElementById('pendingBadge').textContent = data.data.pendingCount;
                }
            })
            .catch(err => console.error('加载统计数据失败:', err));
        }

        // ============================================================
        // 加载待审核列表
        // ============================================================
        function loadPending() {
            const data = new FormData();
            data.append('action', 'get_pending');

            fetch(window.location.href, {
                method: 'POST',
                body: data
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    renderPending(data.data.pending);
                }
            })
            .catch(err => console.error('加载待审核列表失败:', err));
        }

        // ============================================================
        // 渲染待审核列表
        // ============================================================
        function renderPending(pending) {
            const container = document.getElementById('pendingList');

            if (!pending || pending.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-check-circle"></i>
                        <p>暂无待审核内容</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = pending.map(p => {
                const authorName = p.real_name || p.username || '未知用户';
                const timeAgo = p.created_at ? timeSince(p.created_at) : '未知时间';

                return `
                    <div class="review-item" data-id="${p.pID}">
                        <span class="badge-type">项目</span>
                        <div class="info">
                            <div class="title">${escapeHtml(p.title)}</div>
                            <div class="meta">
                                <i class="far fa-user"></i> ${escapeHtml(authorName)}
                                <i class="far fa-clock"></i> ${timeAgo}
                                <span>${escapeHtml(p.level || '未分类')} · ${escapeHtml(p.subject || '未分类')}</span>
                            </div>
                        </div>
                        <div class="actions">
                            <button class="btn-detail" onclick="viewProject(${p.pID})"><i class="fas fa-eye"></i> 预览</button>
                            <button class="btn-approve" onclick="approveProject(${p.pID})"><i class="fas fa-check"></i> 通过</button>
                            <button class="btn-reject" onclick="rejectProject(${p.pID})"><i class="fas fa-times"></i> 驳回</button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // ============================================================
        // 审核操作
        // ============================================================
        function approveProject(id) {
            if (!confirm('确定要通过这个项目吗？')) return;

            const data = new FormData();
            data.append('action', 'approve_project');
            data.append('id', id);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast('✅ 审核通过', 'success');
                        loadStats();
                        loadPending();
                    } else {
                        showToast(data.message || '操作失败', 'error');
                    }
                })
                .catch(err => showToast('操作失败', 'error'));
        }

        function rejectProject(id) {
            if (!confirm('确定要驳回并删除这个项目吗？')) return;

            const data = new FormData();
            data.append('action', 'reject_project');
            data.append('id', id);

            fetch(window.location.href, { method: 'POST', body: data })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showToast('✅ 已驳回', 'success');
                        loadStats();
                        loadPending();
                    } else {
                        showToast(data.message || '操作失败', 'error');
                    }
                })
                .catch(err => showToast('操作失败', 'error'));
        }

        function viewProject(id) {
            showToast('👁️ 预览项目（模拟）', 'warning');
        }

        // ============================================================
        // 工具函数
        // ============================================================
        function escapeHtml(str) {
            if (!str) return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        function timeSince(dateString) {
            const now = new Date();
            const past = new Date(dateString);
            const diffMs = now - past;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);

            if (diffMins < 1) return '刚刚';
            if (diffMins < 60) return diffMins + '分钟前';
            if (diffHours < 24) return diffHours + '小时前';
            if (diffDays < 7) return diffDays + '天前';
            return past.toLocaleDateString('zh-CN');
        }

        // ============================================================
        // 侧栏菜单点击
        // ============================================================
        document.querySelectorAll('.admin-sidebar .menu-item').forEach(item => {
            item.addEventListener('click', function() {
                const page = this.dataset.page;
                document.querySelectorAll('.admin-sidebar .menu-item').forEach(m => m.classList.remove('active'));
                this.classList.add('active');

                if (page === 'home') {
                    window.location.href = 'home.php';
                } else if (page === 'pending') {
                    showToast('📋 加载待审核列表', 'success');
                    loadPending();
                } else if (page === 'overview') {
                    showToast('📊 刷新总览数据', 'success');
                    loadStats();
                } else {
                    showToast(`🔍 进入「${this.textContent.trim()}」模块`, 'success');
                }
            });
        });

        // ============================================================
        // 刷新按钮
        // ============================================================
        document.getElementById('refreshPendingBtn').addEventListener('click', function() {
            loadPending();
            showToast('🔄 已刷新', 'success');
        });

        // ============================================================
        // 退出登录
        // ============================================================
        document.querySelector('.logout-link')?.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'logout.php';
        });

        // ============================================================
        // 初始化
        // ============================================================
        loadStats();
        loadPending();

        setTimeout(() => {
            showToast('👋 欢迎回来！', 'success');
        }, 600);

    });
    </script>

</body>
</html>