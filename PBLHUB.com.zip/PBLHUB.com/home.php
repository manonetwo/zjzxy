<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

// 获取当前登录用户信息
$user = null;
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}

// 获取角色对应的中文名称
function getRoleName($role) {
    $map = [
        'admin' => '管理员',
        'expert' => '专家',
        'student' => '学生'
    ];
    return $map[$role] ?? $role;
}

// 获取角色对应的样式类
function getRoleClass($role) {
    $map = [
        'admin' => 'badge-admin',
        'expert' => 'badge-expert',
        'student' => 'badge-student'
    ];
    return $map[$role] ?? '';
}

// 获取用户名首字母（用于头像）
function getAvatarLetter($name) {
    if (empty($name)) return 'U';
    return mb_substr($name, 0, 1, 'UTF-8');
}

// 轮播图数据（从数据库读取或硬编码）
$slides = [
    [
        'badge' => '<i class="fas fa-star" style="margin-right:0.3rem;"></i> 精选案例',
        'title' => '用项目式学习<br>点亮真实课堂',
        'desc' => '探索优秀PBL案例，获取教学设计灵感，与全国教师共同成长。',
        'btn' => '<i class="fas fa-rocket"></i> 浏览案例',
        'icon1' => 'fa-image',
        'icon2' => 'fa-project-diagram',
        'icon3' => 'fa-users',
        'bg' => 'linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%)',
        'link' => 'resources.php'
    ],
    [
        'badge' => '<i class="fas fa-folder-open" style="margin-right:0.3rem;"></i> 资源中心',
        'title' => '跨学科项目<br>案例库',
        'desc' => '覆盖小学到高中各学科，海量优质PBL项目资源，一键获取。',
        'btn' => '<i class="fas fa-search"></i> 查看资源',
        'icon1' => 'fa-book',
        'icon2' => 'fa-folder-open',
        'icon3' => 'fa-file-alt',
        'bg' => 'linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%)',
        'link' => 'resources.php'
    ],
    [
        'badge' => '<i class="fas fa-comments" style="margin-right:0.3rem;"></i> 智慧共享',
        'title' => '教师社区<br>协作成长',
        'desc' => '与全国教师交流PBL实践经验，参与研讨活动，共同进步。',
        'btn' => '<i class="fas fa-user-plus"></i> 加入社区',
        'icon1' => 'fa-comments',
        'icon2' => 'fa-users',
        'icon3' => 'fa-handshake',
        'bg' => 'linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)',
        'link' => 'community.php'
    ],
    [
        'badge' => '<i class="fas fa-robot" style="margin-right:0.3rem;"></i> AI 赋能',
        'title' => '智能设计<br>PBL项目',
        'desc' => 'AI助手帮你快速生成项目框架、设计驱动问题、规划评估方案。',
        'btn' => '<i class="fas fa-magic"></i> 体验AI',
        'icon1' => 'fa-robot',
        'icon2' => 'fa-brain',
        'icon3' => 'fa-magic',
        'bg' => 'linear-gradient(135deg, #f5f3ff 0%, #ede9fe 100%)',
        'link' => 'ai.php'
    ]
];

// 案例推荐数据（从数据库读取，这里暂时硬编码，后续对接数据库）
$caseCards = [
    [
        'icon' => 'fa-seedling',
        'title' => '校园生态种植',
        'desc' => '初中生物 · 跨学科',
        'tag' => 'hot',
        'tag_text' => '热门'
    ],
    [
        'icon' => 'fa-robot',
        'title' => 'AI 垃圾分类助手',
        'desc' => '小学科学 · 信息科技',
        'tag' => 'default',
        'tag_text' => '精选'
    ],
    [
        'icon' => 'fa-city',
        'title' => '社区可持续发展',
        'desc' => '高中地理 · 社会实践',
        'tag' => 'new',
        'tag_text' => '最新'
    ],
    [
        'icon' => 'fa-palette',
        'title' => '校园文化设计',
        'desc' => '初中美术 · 语文',
        'tag' => 'default',
        'tag_text' => '收藏高'
    ]
];

// 核心功能数据
$features = [
    ['icon' => 'fa-folder-open', 'title' => '案例库', 'desc' => '海量PBL项目'],
    ['icon' => 'fa-graduation-cap', 'title' => '课程中心', 'desc' => '系统学习'],
    ['icon' => 'fa-comments', 'title' => '教师社区', 'desc' => '交流互助'],
    ['icon' => 'fa-robot', 'title' => 'AI助手', 'desc' => '智能设计'],
    ['icon' => 'fa-chart-line', 'title' => '学习记录', 'desc' => '进度可视化'],
    ['icon' => 'fa-trophy', 'title' => '成果激励', 'desc' => '成长体系']
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBL HUB · 项目式学习中心 — 首页</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ===== 全局重置 & 变量 ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --primary-light: #dbeafe;
            --primary-bg: #f0f7ff;
            --bg: #f6f9fc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-mid: #475569;
            --text-light: #94a3b8;
            --border: #e9edf4;
            --shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 12px 32px rgba(0, 0, 0, 0.08);
            --radius: 20px;
            --radius-sm: 12px;
            --transition: 0.25s ease;
        }

        body {
            background: var(--bg);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1360px;
            margin: 0 auto;
            padding: 0 1.8rem;
        }

        /* ===== 导航栏 ===== */
        .navbar {
            background: rgba(255, 255, 255, 0.90);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            padding: 0.6rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid var(--border);
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.6rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }
        .logo i {
            font-size: 2rem;
        }
        .logo span {
            font-weight: 300;
            color: var(--text-light);
            font-size: 0.85rem;
            margin-left: 0.1rem;
        }

        .nav-links {
            display: flex;
            gap: 1.8rem;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-mid);
            font-weight: 500;
            font-size: 1rem;
            padding: 0.3rem 0;
            border-bottom: 2.5px solid transparent;
            transition: var(--transition);
            cursor: pointer;
            position: relative;
        }
        .nav-links a:hover {
            color: var(--primary);
        }
        .nav-links a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        /* 身份选择器 - 动态角色 */
        .identity-selector {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            background: #f1f5f9;
            padding: 0.25rem 0.9rem 0.25rem 1.1rem;
            border-radius: 30px;
            border: 1px solid var(--border);
            cursor: default;
            font-size: 0.85rem;
            color: var(--text-dark);
            transition: var(--transition);
        }
        .identity-selector:hover {
            border-color: var(--primary);
            background: #f8fafc;
        }
        .identity-selector i.fa-chevron-down {
            font-size: 0.65rem;
            color: var(--text-light);
            margin-left: 0.1rem;
        }
        .identity-selector .badge {
            background: var(--primary-light);
            color: var(--primary);
            font-size: 0.6rem;
            padding: 0.1rem 0.6rem;
            border-radius: 30px;
            font-weight: 600;
            margin-left: 0.2rem;
        }

        /* 角色标签样式 */
        .badge-admin {
            background: #fef3c7 !important;
            color: #d97706 !important;
        }
        .badge-expert {
            background: #dbeafe !important;
            color: #2563eb !important;
        }
        .badge-student {
            background: #d1fae5 !important;
            color: #059669 !important;
        }

        .avatar {
            width: 36px;
            height: 36px;
            background: var(--primary-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
            cursor: default;
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-info .name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }
        .user-info .role {
            font-size: 0.65rem;
            color: var(--text-light);
        }
        .logout-link {
            color: var(--text-light);
            font-size: 0.8rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.2rem;
            text-decoration: none;
            cursor: pointer;
            background: none;
            border: none;
        }
        .logout-link:hover {
            color: #ef4444;
        }
        .login-link {
            color: var(--primary);
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            padding: 0.4rem 1.2rem;
            border: 2px solid var(--primary);
            border-radius: 30px;
            transition: var(--transition);
        }
        .login-link:hover {
            background: var(--primary);
            color: #fff;
        }

        /* ===== 页面板块容器 ===== */
        .page-section {
            display: block;
            animation: fadeIn 0.35s ease;
            padding: 1.5rem 0 2.5rem;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== 通用组件 ===== */
        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .section-title i {
            color: var(--primary);
        }
        .section-title .more {
            margin-left: auto;
            font-size: 0.9rem;
            font-weight: 400;
            color: var(--text-light);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.3rem;
            text-decoration: none;
        }
        .section-title .more:hover {
            color: var(--primary);
        }

        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 1.3rem 1.3rem 1.5rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            transition: var(--transition);
        }
        .card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
            border-color: #bfdbfe;
        }
        .card .icon {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 0.4rem;
        }
        .card h4 {
            font-weight: 600;
            font-size: 1.05rem;
            color: var(--text-dark);
        }
        .card p {
            font-size: 0.85rem;
            color: var(--text-mid);
            margin: 0.2rem 0 0.6rem;
        }
        .card .actions {
            display: flex;
            gap: 0.9rem;
            font-size: 0.8rem;
            color: var(--text-light);
            margin-top: 0.4rem;
            flex-wrap: wrap;
        }
        .card .actions span {
            cursor: pointer;
            transition: var(--transition);
        }
        .card .actions span:hover {
            color: var(--primary);
        }
        .card .actions i {
            margin-right: 0.2rem;
        }
        .card .tag {
            background: var(--primary-light);
            color: var(--primary);
            font-size: 0.65rem;
            font-weight: 500;
            padding: 0.15rem 0.7rem;
            border-radius: 30px;
            display: inline-block;
            margin-top: 0.4rem;
        }
        .card .tag.hot {
            background: #fee2e2;
            color: #dc2626;
        }
        .card .tag.new {
            background: #d1fae5;
            color: #059669;
        }

        /* ===== 首页专属 ===== */

        /* ---- 轮播图 ---- */
        .hero-carousel {
            border-radius: var(--radius);
            overflow: hidden;
            background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%);
            box-shadow: var(--shadow);
            position: relative;
            aspect-ratio: 16 / 5.5;
            min-height: 220px;
            display: flex;
            align-items: center;
            padding: 0 3.5rem;
            margin-bottom: 2.8rem;
            transition: var(--transition);
        }
        .hero-carousel:hover {
            box-shadow: var(--shadow-hover);
        }
        .hero-carousel .content {
            display: flex;
            justify-content: space-between;
            width: 100%;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .hero-carousel .text {
            max-width: 55%;
        }
        .hero-carousel .text .badge {
            display: inline-block;
            background: rgba(37, 99, 235, 0.12);
            color: var(--primary);
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.15rem 1rem;
            border-radius: 30px;
            margin-bottom: 0.4rem;
            letter-spacing: 0.3px;
        }
        .hero-carousel .text h2 {
            font-size: clamp(1.8rem, 3.8vw, 2.9rem);
            font-weight: 700;
            color: var(--text-dark);
            line-height: 1.2;
        }
        .hero-carousel .text p {
            color: var(--text-mid);
            margin: 0.5rem 0 1.2rem;
            font-size: 1.05rem;
            max-width: 90%;
        }
        .hero-carousel .btn-primary {
            background: var(--primary);
            color: #fff;
            padding: 0.55rem 2rem;
            border-radius: 40px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 6px 18px rgba(37, 99, 235, 0.28);
            cursor: pointer;
            transition: var(--transition);
            border: none;
            font-size: 0.95rem;
            text-decoration: none;
        }
        .hero-carousel .btn-primary:hover {
            background: var(--primary-hover);
            box-shadow: 0 8px 24px rgba(37, 99, 235, 0.35);
            transform: translateY(-2px);
        }
        .hero-carousel .images {
            display: flex;
            gap: 1rem;
            font-size: 3.8rem;
            color: var(--primary);
            opacity: 0.35;
            user-select: none;
        }
        .hero-carousel .images i {
            transition: var(--transition);
        }
        .hero-carousel .images i:hover {
            opacity: 0.8;
            transform: scale(1.05);
        }
        .hero-carousel .dots {
            position: absolute;
            bottom: 1.2rem;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 0.6rem;
        }
        .hero-carousel .dots span {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #94a3b8;
            display: inline-block;
            transition: var(--transition);
            cursor: pointer;
        }
        .hero-carousel .dots span.active {
            background: var(--primary);
            width: 28px;
            border-radius: 12px;
        }
        .hero-carousel .dots span:hover {
            background: var(--primary);
            opacity: 0.7;
        }

        /* ---- 核心功能 ---- */
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1.2rem;
            margin-bottom: 2.8rem;
        }
        .feature-item {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 1.3rem 0.8rem;
            text-align: center;
            border: 1px solid var(--border);
            transition: var(--transition);
            box-shadow: var(--shadow);
            cursor: pointer;
        }
        .feature-item:hover {
            transform: translateY(-4px);
            border-color: #bfdbfe;
            box-shadow: var(--shadow-hover);
        }
        .feature-item i {
            font-size: 2.2rem;
            color: var(--primary);
            margin-bottom: 0.4rem;
            display: block;
        }
        .feature-item h4 {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-dark);
        }
        .feature-item p {
            font-size: 0.8rem;
            color: var(--text-light);
            margin-top: 0.1rem;
        }

        /* ---- 案例推荐 ---- */
        .case-highlight {
            margin-bottom: 1.5rem;
        }

        /* ===== 底部 ===== */
        .footer {
            background: var(--card-bg);
            border-top: 1px solid var(--border);
            padding: 2rem 0;
            margin-top: 2rem;
        }
        .footer .container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1.5rem;
        }
        .footer .col {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
            font-size: 0.9rem;
            color: var(--text-mid);
        }
        .footer .col strong {
            color: var(--text-dark);
            font-weight: 600;
        }
        .footer .col i {
            margin-right: 0.4rem;
            color: var(--primary);
            width: 1.2rem;
            text-align: center;
        }
        .footer .col a {
            color: var(--text-mid);
            text-decoration: none;
            transition: var(--transition);
        }
        .footer .col a:hover {
            color: var(--primary);
        }
        .footer .bottom {
            text-align: center;
            margin-top: 1.2rem;
            font-size: 0.8rem;
            color: var(--text-light);
            border-top: 1px solid var(--border);
            padding-top: 1rem;
        }

        /* ===== 响应式 ===== */
        @media (max-width: 1024px) {
            .navbar .container {
                flex-direction: column;
                gap: 0.5rem;
            }
            .nav-links {
                justify-content: center;
            }
            .hero-carousel {
                padding: 1.8rem;
                aspect-ratio: auto;
                min-height: 200px;
            }
            .hero-carousel .text {
                max-width: 100%;
            }
            .hero-carousel .text p {
                max-width: 100%;
            }
            .hero-carousel .images {
                display: none;
            }
        }

        @media (max-width: 768px) {
            .container {
                padding: 0 1.2rem;
            }
            .nav-right {
                width: 100%;
                justify-content: center;
                flex-wrap: wrap;
            }
            .card-grid {
                grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
                gap: 1rem;
            }
            .feature-grid {
                grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
                gap: 0.8rem;
            }
            .hero-carousel .text h2 {
                font-size: 1.6rem;
            }
            .hero-carousel .dots {
                bottom: 0.8rem;
            }
        }

        @media (max-width: 480px) {
            .nav-links {
                gap: 1rem;
                font-size: 0.9rem;
            }
            .nav-links a {
                font-size: 0.85rem;
            }
            .card-grid {
                grid-template-columns: 1fr 1fr;
            }
            .feature-grid {
                grid-template-columns: 1fr 1fr 1fr;
            }
            .feature-item {
                padding: 0.8rem 0.4rem;
            }
            .feature-item i {
                font-size: 1.6rem;
            }
            .feature-item h4 {
                font-size: 0.8rem;
            }
            .feature-item p {
                font-size: 0.7rem;
            }
            .hero-carousel {
                padding: 1.2rem;
                min-height: 160px;
            }
            .hero-carousel .text h2 {
                font-size: 1.3rem;
            }
            .hero-carousel .text p {
                font-size: 0.85rem;
                margin: 0.3rem 0 0.8rem;
            }
            .hero-carousel .btn-primary {
                font-size: 0.8rem;
                padding: 0.4rem 1.4rem;
            }
            .section-title {
                font-size: 1.2rem;
            }
            .identity-selector {
                font-size: 0.75rem;
                padding: 0.2rem 0.6rem;
            }
            .user-info .name {
                font-size: 0.8rem;
            }
            .avatar {
                width: 30px;
                height: 30px;
                font-size: 0.75rem;
            }
        }
    </style>
</head>
<body>

    <!-- ===== 导航栏 ===== -->
    <nav class="navbar">
        <div class="container">
            <a href="/" class="logo">
                <i class="fas fa-chalkboard-teacher"></i>
                PBL HUB <span>· 项目式学习中心</span>
            </a>
            <div class="nav-links">
                <a class="active" href="/">首页</a>
                <a href="resources.php">PBL资源库</a>
                <a href="courses.php">课程中心</a>
                <a href="community.php">教师社区</a>
                <a href="profile.php">个人中心</a>
            </div>
            <div class="nav-right">
                <?php if ($isLoggedIn && $user): ?>
                    <!-- 已登录状态 -->
                    <div class="identity-selector">
                        <i class="fas fa-user-tag"></i> 
                        <?php echo getRoleName($user['role'] ?? 'student'); ?>
                        <i class="fas fa-chevron-down"></i>
                        <span class="badge <?php echo getRoleClass($user['role'] ?? 'student'); ?>">
                            <?php echo getRoleName($user['role'] ?? 'student'); ?>
                        </span>
                    </div>
                    <div class="avatar">
                        <?php echo htmlspecialchars(getAvatarLetter($user['real_name'] ?? $user['username'] ?? 'U')); ?>
                    </div>
                    <div class="user-info">
                        <span class="name"><?php echo htmlspecialchars($user['real_name'] ?? $user['username'] ?? '用户'); ?></span>
                        <span class="role">
                            <?php 
                                $roleInfo = [];
                                if (!empty($user['school'])) $roleInfo[] = $user['school'];
                                if (!empty($user['subject'])) $roleInfo[] = $user['subject'];
                                echo htmlspecialchars(implode(' · ', $roleInfo)) ?: '欢迎回来';
                            ?>
                        </span>
                    </div>
                    <a href="/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <!-- 未登录状态 -->
                    <a href="/login.php" class="login-link"><i class="fas fa-sign-in-alt"></i> 登录</a>
                    <a href="/login.php?action=register" class="login-link" style="background:var(--primary);color:#fff;border-color:var(--primary);">注册</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- ===== 主容器 ===== -->
    <main class="container">

        <!-- ============================================================ -->
        <!-- ======================== 首页 =============================== -->
        <!-- ============================================================ -->
        <section id="page-home" class="page-section">

            <!-- ---- 轮播图 ---- -->
            <div class="hero-carousel" id="heroCarousel">
                <div class="content" id="carouselContent">
                    <!-- PHP动态生成轮播内容，由JS控制渲染 -->
                </div>
                <div class="dots" id="carouselDots">
                    <!-- 由JS动态生成 -->
                </div>
            </div>

            <!-- ---- 核心功能 ---- -->
            <div class="section-title">
                <i class="fas fa-th-large"></i>&nbsp;&nbsp;核心功能
            </div>
            <div class="feature-grid">
                <?php foreach ($features as $feature): ?>
                <div class="feature-item" onclick="location.href='/pages/<?php echo strtolower($feature['title']); ?>.php'">
                    <i class="fas <?php echo $feature['icon']; ?>"></i>
                    <h4><?php echo htmlspecialchars($feature['title']); ?></h4>
                    <p><?php echo htmlspecialchars($feature['desc']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- ---- 案例推荐 ---- -->
            <div class="section-title">
                <i class="fas fa-star"></i>&nbsp;&nbsp;案例推荐
                <a href="/pages/resources.php" class="more">查看更多 <i class="fas fa-chevron-right"></i></a>
            </div>
            <div class="card-grid case-highlight">
                <?php foreach ($caseCards as $card): ?>
                <div class="card">
                    <div class="icon"><i class="fas <?php echo $card['icon']; ?>"></i></div>
                    <h4><?php echo htmlspecialchars($card['title']); ?></h4>
                    <p><?php echo htmlspecialchars($card['desc']); ?></p>
                    <div class="actions">
                        <span><i class="far fa-eye"></i> 预览</span>
                        <span><i class="far fa-star"></i> 收藏</span>
                    </div>
                    <span class="tag <?php echo $card['tag']; ?>"><?php echo htmlspecialchars($card['tag_text']); ?></span>
                </div>
                <?php endforeach; ?>
            </div>

        </section>

    </main>

    <!-- ===== 底部 ===== -->
    <footer class="footer">
        <div class="container">
            <div class="col">
                <strong><i class="fas fa-chalkboard-teacher" style="color:var(--primary);"></i> PBL HUB</strong>
                <span><i class="fas fa-map-marker-alt"></i>项目式学习教师研修社区</span>
                <span><i class="fas fa-university"></i> 西北师范大学 · 教育技术学院</span>
            </div>
            <div class="col">
                <strong><i class="fas fa-info-circle"></i> 关于我们</strong>
                <span><i class="fas fa-envelope"></i> contact@pblhub.edu</span>
                <span><i class="fas fa-users"></i> 成员：李连泽、赛文杰、张娜、张守梅、张曼</span>
                <span><i class="fas fa-graduation-cap"></i> 教师PBL学习平台</span>
            </div>
            <div class="col">
                <strong><i class="fas fa-link"></i> 快速链接</strong>
                <a href="/"><i class="fas fa-home"></i> 首页</a>
                <a href="/pages/profile.php"><i class="fas fa-user"></i> 个人中心</a>
                <a href="/pages/about.php"><i class="fas fa-info-circle"></i> 关于我们</a>
            </div>
        </div>
        <div class="bottom">
            © <?php echo date('Y'); ?> PBL HUB · 项目式学习中心
        </div>
    </footer>

    <!-- ===== JavaScript 轮播图 (2秒切换) ===== -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // ---------- 轮播图核心逻辑 ----------
        const carousel = document.getElementById('heroCarousel');
        const content = document.getElementById('carouselContent');
        const dotsContainer = document.getElementById('carouselDots');

        // 轮播数据（从PHP传递过来的数据）
        const slides = <?php echo json_encode($slides); ?>;

        // 动态生成指示点
        dotsContainer.innerHTML = slides.map((_, i) => 
            `<span data-index="${i}" class="${i === 0 ? 'active' : ''}"></span>`
        ).join('');

        const dots = document.querySelectorAll('#carouselDots span');

        let currentSlide = 0;
        let autoTimer = null;
        const INTERVAL = 2000;

        // 渲染指定索引的轮播内容
        function renderSlide(index) {
            const slide = slides[index];
            // 更新轮播背景
            carousel.style.background = slide.bg;
            // 更新轮播主体内容
            content.innerHTML = `
                <div class="text">
                    <div class="badge">${slide.badge}</div>
                    <h2>${slide.title}</h2>
                    <p>${slide.desc}</p>
                    <a href="${slide.link || '#'}" class="btn-primary">${slide.btn}</a>
                </div>
                <div class="images">
                    <i class="fas ${slide.icon1}"></i>
                    <i class="fas ${slide.icon2}"></i>
                    <i class="fas ${slide.icon3}"></i>
                </div>
            `;
            // 更新指示器状态
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
            currentSlide = index;
        }

        // 切换到下一张
        function nextSlide() {
            const nextIndex = (currentSlide + 1) % slides.length;
            renderSlide(nextIndex);
        }

        // 启动自动轮播
        function startAutoPlay() {
            if (autoTimer) clearInterval(autoTimer);
            autoTimer = setInterval(nextSlide, INTERVAL);
        }

        // 停止自动轮播
        function stopAutoPlay() {
            if (autoTimer) {
                clearInterval(autoTimer);
                autoTimer = null;
            }
        }

        // 重置自动轮播
        function resetAutoPlay() {
            stopAutoPlay();
            startAutoPlay();
        }

        // 手动点击指示器切换
        dots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                if (currentSlide === index) return;
                renderSlide(index);
                resetAutoPlay();
            });
        });

        // 鼠标悬停暂停，离开恢复
        carousel.addEventListener('mouseenter', stopAutoPlay);
        carousel.addEventListener('mouseleave', startAutoPlay);

        // 触摸设备适配
        carousel.addEventListener('touchstart', stopAutoPlay, { passive: true });
        carousel.addEventListener('touchend', startAutoPlay, { passive: true });

        // 初始化并启动
        renderSlide(0);
        startAutoPlay();
    });
    </script>

</body>
</html>