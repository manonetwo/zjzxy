<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';

requireLogin();

$user = getCurrentUser();
if (!$user) {
    die("❌ 用户未登录");
}

// 测试查询
echo "<h2>=== 个人中心数据测试 ===</h2>";

echo "<h3>1. 用户信息:</h3>";
$sql = "SELECT u.*, e.nickname, e.birthday, e.province, e.city, e.education, 
               e.teaching_years, e.research_direction, e.personal_intro
        FROM users u
        LEFT JOIN user_profile_extend e ON u.id = e.user_id
        WHERE u.id = {$user['id']}";
$result = $conn->query($sql);
$userInfo = $result ? $result->fetch_assoc() : null;
echo "<pre>";
print_r($userInfo);
echo "</pre>";

echo "<h3>2. 课程进度:</h3>";
$sql = "SELECT cp.*, c.cTitle as course_title, c.instructor 
        FROM course_progress cp
        LEFT JOIN courses c ON cp.course_id = c.cID
        WHERE cp.user_id = {$user['id']}";
$result = $conn->query($sql);
$progress = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $progress[] = $row;
    }
}
echo "<pre>";
print_r($progress);
echo "</pre>";

echo "<h3>3. 课程收藏:</h3>";
$sql = "SELECT cf.*, c.cTitle as course_title, c.instructor, c.level
        FROM course_favorites cf
        LEFT JOIN courses c ON cf.course_id = c.cID
        WHERE cf.user_id = {$user['id']}";
$result = $conn->query($sql);
$favorites = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $favorites[] = $row;
    }
}
echo "<pre>";
print_r($favorites);
echo "</pre>";

echo "<h3>4. 我的项目:</h3>";
$sql = "SELECT p.*, u.username, u.real_name 
        FROM projects p
        LEFT JOIN users u ON p.author_id = u.id
        WHERE p.author_id = {$user['id']}";
$result = $conn->query($sql);
$projects = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $projects[] = $row;
    }
}
echo "<pre>";
print_r($projects);
echo "</pre>";

echo "<h3>5. 动态:</h3>";
$sql = "SELECT * FROM activities WHERE user_id = {$user['id']} ORDER BY created_at DESC LIMIT 10";
$result = $conn->query($sql);
$activities = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $activities[] = $row;
    }
}
echo "<pre>";
print_r($activities);
echo "</pre>";

echo "<h3>6. 私信:</h3>";
$sql = "SELECT pm.*, u.username, u.real_name 
        FROM private_messages pm
        LEFT JOIN users u ON pm.sender_id = u.id
        WHERE pm.receiver_id = {$user['id']}
        ORDER BY pm.created_at DESC
        LIMIT 10";
$result = $conn->query($sql);
$messages = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
}
echo "<pre>";
print_r($messages);
echo "</pre>";

echo "<h2>✅ 数据测试完成</h2>";
?>